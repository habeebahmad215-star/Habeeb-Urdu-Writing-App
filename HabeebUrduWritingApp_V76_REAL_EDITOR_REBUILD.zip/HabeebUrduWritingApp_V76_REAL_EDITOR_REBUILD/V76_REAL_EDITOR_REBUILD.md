# V76 Real Editor Rebuild Direction

This version stops adding tiny decorative patches to the broken V75 behavior.

## Core corrections in this build
- Page scaling now repositions the physical paper layout around its transformed center.
- The stage dimensions and transformed page bounds use the same zoom coordinate model.
- Reset Zoom is a labeled control (`↺ Reset Zoom`) rather than an ambiguous icon.
- Lock/Unlock is a labeled page-front control (`🔓 Lock Page` / `🔒 Unlock Page`).
- The page controls are positioned over the visible page, not at a distant editor edge.
- Lock freezes page movement while leaving object editing available.

## Next verification focus
The core canvas must be tested before claiming all advanced tools are production-ready: page fit, pinch zoom, reset, lock, object move, resize handles and selection bounds.

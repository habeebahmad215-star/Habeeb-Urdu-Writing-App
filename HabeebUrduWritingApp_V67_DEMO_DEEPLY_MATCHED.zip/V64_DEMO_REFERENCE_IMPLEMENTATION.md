# V64 Demo Reference Implementation

The supplied demo recording was reviewed across the full workflow.

Implemented/retained core workflow:
- Home / new design flow
- Language and document setup
- Editable page canvas
- Add Text opens an immediately selected editable box on the page
- Long-press text selection and keyboard workflow
- Compact selection box and compact resize/rotate handles
- Small icon + label tools, matching the compact reference principle
- Layers / object manager / lock / show-hide / front-back
- Move and alignment controls
- Duplicate and delete objects
- Text size, font, color, opacity, real shadow, real gradient, and stroke box controls
- Background color/transparency, page size, borders, multiple pages
- Shapes/elements/images already supported by the app
- Save design, JSON open/save, PDF export/preview/print workflow retained
- Undo/redo retained

Visual differentiation from the demo/reference:
- New deep-teal / emerald accent palette
- Teal selection outline and save accent
- Existing app branding retained
- No exact asset or logo copying

Explicitly not added:
- Audio tools
- Video tools
- AI image generation tools

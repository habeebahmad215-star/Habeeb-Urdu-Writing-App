V65 build workflow fix

Cause of the error:
The previous workflow treated a valid Android project located at the repository root as an error and then searched for a ZIP file. Therefore it could show "No ZIP file found" even though settings.gradle was already present.

Fix:
The workflow now first accepts any existing settings.gradle, including one at the repository root. Only when no Android project exists does it search for a ZIP and extract it.

Important for GitHub:
Remove/disable any old workflow that contains a step named "Find project ZIP" or uses an old ZIP-only build script. Otherwise GitHub may continue running that old workflow and show its failure separately.

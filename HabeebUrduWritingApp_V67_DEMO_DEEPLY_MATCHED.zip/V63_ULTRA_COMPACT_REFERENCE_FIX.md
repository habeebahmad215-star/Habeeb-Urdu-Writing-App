# V63 Ultra Compact Reference Fix

Corrected after comparing the V62 runtime screenshot against the user's original compact reference:

- Selection/object tool cards reduced from 150x116dp to 86x68dp.
- Icons reduced from 30sp to 22sp.
- Labels reduced from 15sp to 10sp.
- Tool row height reduced from 136dp to 80dp.
- Two-row selection toolbar reduced from 286dp to 168dp total.
- Add Text object reduced from 260x150dp to 150x70dp.
- Selection frame handles and rotate control reduced to match the smaller object.
- Fallback selection dimensions also reduced to 150x70dp.

Goal: keep substantially more of the page visible and match the compact old screenshot rather than enlarging the controls.

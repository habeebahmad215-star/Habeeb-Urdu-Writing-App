# V62 REFERENCE SELECTION + TOOLBAR FIX

This revision corrects the visible mismatch identified from the two supplied screenshots:

- Enlarged contextual tool cards to reference-style proportions.
- Clear icon-above-label presentation for every contextual tool.
- Two dark contextual rows for selected text and text formatting.
- Purple selection frame with visible corner, side and rotate-style handles.
- Add Text now inserts an empty editable text box, selects it immediately and opens the keyboard.
- Selected text box exposes Move, Delete, Duplicate and More controls first.
- No Audio, Video or AI Image option was added.

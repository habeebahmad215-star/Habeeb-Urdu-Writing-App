# V75 Build Error Fix

## GitHub Actions error fixed

V74 failed at:

`MainActivity.java:228: error: cannot find symbol`

The code called `saveUndo()` from `SelectionFrame`, but no method named `saveUndo()` exists in `MainActivity`.

### Fix

The invalid call was replaced with:

`saveCurrentPageState();`

This keeps the page/object state synchronized after a selection-frame move or resize and removes the Java compiler error.

The V75 GitHub Actions workflow artifact name was also updated to V75.

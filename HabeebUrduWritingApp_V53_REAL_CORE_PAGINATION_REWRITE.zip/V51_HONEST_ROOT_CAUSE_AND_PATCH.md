V51 ROOT-CAUSE PATCH

This patch was made after inspecting V50 source code directly.

Confirmed V50 problems found in source:
1. Pagination was driven mainly by a delayed TextWatcher callback and could miss the final measured layout after a large paste/reflow.
2. Restored/page-layout changes did not use a persistent layout-change scheduling path.
3. V50 claimed pasted paragraph spacing was normalized, but the source still accepted/preserved line-height style spans and did not remove external LineHeightSpan paragraph formatting.

V51 changes:
- Adds repeated post-layout pagination scheduling after text changes and size/layout changes.
- Rechecks restored pages.
- Removes imported LineHeightSpan, LeadingMarginSpan and AlignmentSpan paragraph formatting while retaining the app's own manual RelativeLineSpacingSpan.
- Uses a safer pagination split and schedules pagination again after moving overflow to the next page.

IMPORTANT: This environment did not contain Gradle/gradlew, so an actual APK compilation could not be run here. This source package must be built in the user's Android build environment before calling it verified.

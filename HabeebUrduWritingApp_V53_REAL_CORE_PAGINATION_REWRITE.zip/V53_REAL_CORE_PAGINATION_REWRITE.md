# V53 Real Core Pagination Rewrite

## Root cause fixed
The prior V49-V52 builds measured overflow through EditText's runtime layout. After restore,
EditText could internally scroll or have mismatched right/bottom margins, so the measured layout
was not the same rectangle as the visible paper. The result was clipped text and inconsistent
page boundaries.

V53 changes the source architecture in four places:
1. Full-page editor overflow is measured with StaticLayout against the exact paper safe rectangle.
2. Full-page editors are non-scrolling so overflow cannot hide below the viewport.
3. Restored full-page editors always rebuild all four safe margins; right/bottom margins are no
   longer lost during page state serialization.
4. Android's native Paste command is intercepted and converted to plain text before insertion,
   preventing external line-height/font-size spans from entering the document.

## Font behavior
A collapsed cursor clears stale formatting selection state. Choosing a font with no highlighted
text therefore sets the typing/default font. Choosing a font with highlighted text still applies
it only to that selection. Rich font spans continue to be serialized and sliced when text moves
to a continuation page.

## Remaining verification requirement
This is a source-level core rewrite. It should be built and tested on an Android device/emulator
with the exact imported Urdu fonts used by the user before release to Play Store.

# V52 Systematic Root-Cause Audit

## What was compared
V49, V50 and V51 were compared at source level. All three retained the same core page editor architecture and the same asynchronous pagination weakness. V50/V51 added delayed checks, but did not replace the unreliable overflow decision.

## Root causes fixed in V52
1. Pagination now checks the actual bottom of the last laid-out line instead of relying on `Layout.getHeight()`, which can be viewport-sized for a scrolling EditText.
2. Pagination scheduling calls the splitter directly after several completed-layout checkpoints instead of recursively bouncing through `ensureActiveTextFitsPage()`.
3. The full-page editor no longer receives an extra internal 24dp padding on every pagination pass; that padding made the measured editable height inconsistent with the visible page safe area.
4. Leading page-edge spaces are removed without deleting paragraph breaks.
5. Pasted plain text is protected against inherited metric/paragraph spans from the insertion point, including line-height, relative size, absolute size, alignment and margin spans.
6. The document still starts with exactly one page. Extra pages are created only when a real laid-out line exceeds the safe editor height.

## Important verification status
The source was statically audited after patching. This archive does not include a locally produced APK because the uploaded project has no Gradle wrapper and the local environment does not provide an Android SDK/Gradle build runtime. The included GitHub Actions workflow can compile it with Gradle 8.9 and Java 17.

## Focused test sequence
- Create a new document: it must show Page 1 of 1.
- Type until the last line crosses the bottom safe area: overflow must move to Page 2, not remain clipped.
- Paste a text long enough for 3+ pages: all pages must be created as required.
- Paste text from browser/WhatsApp/Word-like sources: pasted paragraphs should use the editor's one shared base line spacing.
- Select a font before typing and cross a page boundary: the base font must continue onto the overflow page.

V50 REAL LINE SPACING ENGINE FIX

Problem fixed
- The previous custom LineHeightSpan blocked every compact value below 1.0 because it used Math.max(originalHeight, originalHeight * multiplier).
- The previous global EditText spacing (0.82 + negative extra) and paragraph span could fight each other, making manual changes appear inconsistent.
- "Compact default" and "1.0 Normal" accidentally used the same value.
- Manual line spacing failed when the cursor was inside a paragraph but no text was highlighted.

V50 solution
- Neutral view-level baseline: 1.0 multiplier and 0 extra.
- New real paragraph line-height span adjusts ascent/descent and top/bottom together.
- Compact 0.85, normal 1.00, and 1.10 through 2.00 now have distinct behavior.
- Cursor-only formatting applies to the current paragraph automatically.
- Paragraph spans include the newline so subsequent typing keeps the selected line spacing.
- Line spacing is restored as a paragraph span after save/open.

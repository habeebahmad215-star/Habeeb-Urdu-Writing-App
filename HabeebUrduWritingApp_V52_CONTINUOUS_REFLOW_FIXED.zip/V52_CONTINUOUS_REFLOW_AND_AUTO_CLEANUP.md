# V52 — Continuous Page Reflow and Automatic Blank-Page Cleanup

## Fixed
- Multi-page pasted text is now treated as one continuous rich-text flow.
- Reducing font size pulls text from later pages back into newly available space on earlier pages.
- Reducing paragraph line spacing does the same reflow automatically.
- Every following page is compacted in sequence, not only the currently edited page.
- Rich selected-font, color, size, underline, style, word-spacing and line-spacing spans are carried with the text while pages are rebalanced.
- Empty trailing auto-flow pages are removed automatically when they contain no other object.
- Page state is rebuilt before save/export, so the compacted page layout is what gets saved.

## Important behavior
Pages containing non-text design objects are retained rather than silently deleting user content.

# V51 – Font Persistence & Stable Line Spacing Fix

## Fixed
- Selected-range fonts are stored as persistent rich-text spans and are not tied to the active selection highlight.
- Tapping blank space, moving the cursor, or closing the keyboard no longer converts a locally formatted range back to the base font.
- The active text object is snapshotted immediately after a font or line-spacing change, preserving formatting during page navigation and object restore.
- Stale remembered selections are cleared on genuine editor/page taps so later formatting cannot accidentally target an old range.
- Default editor line layout uses a stable normal baseline with font padding enabled for safer mixed Urdu font metrics.
- Manual line spacing still formats the current paragraph when there is only a cursor, and selected paragraphs when text is highlighted.
- Normal 1.00 clears custom paragraph spacing and returns to the stable default baseline.

## Compatibility
Documents remain compatible with the existing object/page rich-text model. Schema metadata is bumped to V51.

package com.habeeburdu.writing;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.print.*;
import android.text.InputType;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, toolbar, editorCard;
    EditText title, editor;
    Spinner fontSpinner, sizeSpinner, pageSpinner;
    Button saveBtn, openBtn, pdfBtn, printBtn, fontImportBtn, boldBtn, italicBtn, alignBtn;
    String currentFontName = "System Urdu";
    Typeface currentTypeface = Typeface.DEFAULT;
    int pageW = 595, pageH = 842; // A4 points
    boolean landscape = false;
    File fontDir, pdfLast;
    ArrayList<String> fontNames = new ArrayList<>();
    HashMap<String, Typeface> typefaces = new HashMap<>();

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s, float sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(23,32,42)); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); return b; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); fontDir=new File(getFilesDir(),"fonts"); if(!fontDir.exists()) fontDir.mkdirs(); loadFonts(); buildHome(); }

    void loadFonts(){
        fontNames.clear(); typefaces.clear();
        fontNames.add("System Urdu"); typefaces.put("System Urdu", Typeface.DEFAULT);
        File[] fs=fontDir.listFiles(); if(fs!=null) for(File f:fs){ try{ Typeface tf=Typeface.createFromFile(f); String n=f.getName(); typefaces.put(n,tf); fontNames.add(n); }catch(Exception ignored){} }
    }

    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }

    void buildHome(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(244,247,251)); setContentView(root);
        TextView head=tv("✒  Habeeb Urdu Writing App",20); head.setTextColor(Color.WHITE); head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.setPadding(dp(18),dp(8),dp(12),dp(8)); head.setBackgroundColor(Color.rgb(7,59,115)); root.addView(head,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView sub=tv("اردو لکھیں • ڈیزائن کریں • محفوظ کریں • PDF • Print",14); sub.setTextColor(Color.rgb(7,59,115)); sub.setGravity(Gravity.CENTER); sub.setPadding(0,dp(10),0,dp(10)); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setPadding(dp(14),dp(8),dp(14),dp(8));
        addHomeButton(grid,"✚  New Urdu Document",0xFF0B65C2, v->buildEditor());
        addHomeButton(grid,"📂  Open Document",0xFF178B54, v->openDocument());
        addHomeButton(grid,"🔤  Manage Nastaleeq Fonts",0xFF7A45B8, v->showFontsDialog());
        addHomeButton(grid,"📄  PDF / Print",0xFFB43A34, v->buildEditor());
        TextView info=tv("Professional Urdu writing & page design\nCustom .TTF / .OTF fonts supported",14); info.setGravity(Gravity.CENTER); info.setTextColor(Color.DKGRAY); info.setPadding(0,dp(22),0,0); grid.addView(info,new LinearLayout.LayoutParams(-1,dp(90)));
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
    }
    void addHomeButton(LinearLayout p,String s,int color,View.OnClickListener l){ Button b=btn(s); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setBackground(bg(color,16)); b.setOnClickListener(l); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(62)); lp.setMargins(0,dp(6),0,dp(6)); p.addView(b,lp); }

    void buildEditor(){
        root.removeAllViews();
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(8),0,dp(8),0); top.setBackgroundColor(Color.rgb(7,59,115));
        Button back=btn("‹"); back.setTextColor(Color.WHITE); back.setTextSize(30); back.setOnClickListener(v->buildHome()); top.addView(back,new LinearLayout.LayoutParams(dp(48),-1));
        title=new EditText(this); title.setText("Untitled Urdu Document"); title.setTextColor(Color.WHITE); title.setTextSize(17); title.setSingleLine(); title.setBackgroundColor(Color.TRANSPARENT); top.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        saveBtn=btn("Save"); pdfBtn=btn("PDF"); printBtn=btn("Print"); for(Button x:new Button[]{saveBtn,pdfBtn,printBtn}){x.setTextColor(Color.WHITE);x.setTextSize(11);top.addView(x,new LinearLayout.LayoutParams(dp(55),-1));}
        saveBtn.setOnClickListener(v->saveDocument()); pdfBtn.setOnClickListener(v->exportPdf(false)); printBtn.setOnClickListener(v->printPdf()); root.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));

        toolbar=new LinearLayout(this); toolbar.setOrientation(LinearLayout.VERTICAL); toolbar.setPadding(dp(6),dp(6),dp(6),dp(6)); toolbar.setBackgroundColor(Color.WHITE);
        LinearLayout r1=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL); fontSpinner=new Spinner(this); sizeSpinner=new Spinner(this);
        ArrayAdapter<String> fa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames); fontSpinner.setAdapter(fa); fontSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){currentFontName=fontNames.get(p); currentTypeface=typefaces.get(currentFontName); editor.setTypeface(currentTypeface);}});
        String[] sizes={"18","22","26","30","36","44","52","64"}; ArrayAdapter<String> sa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sizes); sizeSpinner.setAdapter(sa); sizeSpinner.setSelection(3); sizeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){editor.setTextSize(Float.parseFloat(sizes[p]));}});
        r1.addView(fontSpinner,new LinearLayout.LayoutParams(0,dp(48),1)); r1.addView(sizeSpinner,new LinearLayout.LayoutParams(dp(90),dp(48))); fontImportBtn=btn("+ Font"); fontImportBtn.setOnClickListener(v->importFont()); r1.addView(fontImportBtn,new LinearLayout.LayoutParams(dp(82),dp(48))); toolbar.addView(r1);
        LinearLayout r2=new LinearLayout(this); boldBtn=btn("B"); italicBtn=btn("I"); alignBtn=btn("⇔"); Button page=btn("Page"); Button image=btn("Image");
        boldBtn.setOnClickListener(v->toggleBold()); italicBtn.setOnClickListener(v->toggleItalic()); alignBtn.setOnClickListener(v->chooseAlign()); page.setOnClickListener(v->choosePage()); image.setOnClickListener(v->Toast.makeText(this,"Image placement is planned for the next editor layer.",Toast.LENGTH_SHORT).show());
        for(Button x:new Button[]{boldBtn,italicBtn,alignBtn,page,image}) r2.addView(x,new LinearLayout.LayoutParams(0,dp(46),1)); toolbar.addView(r2); root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(112)));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); editorCard=new LinearLayout(this); editorCard.setPadding(dp(18),dp(20),dp(18),dp(40)); editorCard.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL); editorCard.setBackgroundColor(Color.rgb(220,225,232));
        editor=new EditText(this); editor.setText("الحمد لله رب العالمين\n\nاپنا اردو متن یہاں لکھیں…"); editor.setTextSize(30); editor.setGravity(Gravity.TOP|Gravity.RIGHT); editor.setTextColor(Color.rgb(20,30,45)); editor.setPadding(dp(22),dp(26),dp(22),dp(26)); editor.setBackground(bg(Color.rgb(255,253,248),4)); editor.setTypeface(currentTypeface); editor.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); editor.setHint("اردو میں لکھنا شروع کریں…");
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(520),dp(735)); editorCard.addView(editor,ep); scroll.addView(editorCard); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }

    void toggleBold(){ editor.setTypeface(Typeface.create(currentTypeface, Typeface.BOLD)); }
    void toggleItalic(){ editor.setTypeface(Typeface.create(currentTypeface, Typeface.ITALIC)); }
    void chooseAlign(){ new AlertDialog.Builder(this).setTitle("Text Alignment").setItems(new String[]{"Right","Center","Left"},(d,w)->{editor.setGravity((w==0?Gravity.RIGHT:w==1?Gravity.CENTER:Gravity.LEFT)|Gravity.TOP);}).show(); }
    void choosePage(){ new AlertDialog.Builder(this).setTitle("Page Setup").setItems(new String[]{"A4 Portrait","A4 Landscape","A5 Portrait","Letter Portrait"},(d,w)->{ if(w==1){pageW=842;pageH=595;landscape=true;} else if(w==2){pageW=420;pageH=595;landscape=false;} else if(w==3){pageW=612;pageH=792;landscape=false;} else {pageW=595;pageH=842;landscape=false;} Toast.makeText(this,"Page size updated",Toast.LENGTH_SHORT).show(); }).show(); }

    void importFont(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("font/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,101); }
    @Override protected void onActivityResult(int r,int c,Intent d){
 super.onActivityResult(r,c,d);
 if(c!=RESULT_OK||d==null)return;
 try{
  Uri u=d.getData();
  if(r==101){String name="font_"+System.currentTimeMillis()+".ttf"; File out=new File(fontDir,name); InputStream in=getContentResolver().openInputStream(u); FileOutputStream fo=new FileOutputStream(out); byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)fo.write(buf,0,n);in.close();fo.close();loadFonts();Toast.makeText(this,"Font imported: "+name,Toast.LENGTH_LONG).show();if(editor!=null)buildEditor();}
  else if(r==102){writeJson(u);Toast.makeText(this,"Document saved",Toast.LENGTH_SHORT).show();}
  else if(r==103){openJson(u);}
  else if(r==104){createPdf(u);Toast.makeText(this,"PDF created successfully",Toast.LENGTH_SHORT).show();}
 }catch(Exception e){Toast.makeText(this,"Operation failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
}

    void showFontsDialog(){ loadFonts(); String[] items=fontNames.toArray(new String[0]); new AlertDialog.Builder(this).setTitle("Available Fonts").setItems(items,null).setPositiveButton("Import Font",(d,w)->importFont()).show(); }

    void saveDocument(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".json"); startActivityForResult(i,102); }
    String safeName(String s){return s.replaceAll("[^a-zA-Z0-9_\\- ]","_").trim().replaceAll(" +","_");}
    void writeJson(Uri u)throws Exception{ org.json.JSONObject o=new org.json.JSONObject();o.put("title",title.getText().toString());o.put("text",editor.getText().toString());o.put("font",currentFontName);o.put("size",editor.getTextSize());o.put("pageW",pageW);o.put("pageH",pageH); OutputStream out=getContentResolver().openOutputStream(u);out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));out.close(); }
    void openDocument(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,103); }
    void openJson(Uri u){try{InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[8192];int n;while((n=in.read(z))>0)b.write(z,0,n);in.close();org.json.JSONObject o=new org.json.JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));buildEditor();title.setText(o.optString("title","Untitled Urdu Document"));editor.setText(o.optString("text",""));editor.setTextSize((float)o.optDouble("size",30));currentFontName=o.optString("font","System Urdu");loadFonts();int ix=fontNames.indexOf(currentFontName);if(ix<0)ix=0;fontSpinner.setSelection(ix);pageW=o.optInt("pageW",595);pageH=o.optInt("pageH",842);Toast.makeText(this,"Document opened",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Open failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    void exportPdf(boolean forPrint){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".pdf");startActivityForResult(i,104); }

    void createPdf(Uri uri)throws Exception{ OutputStream out=getContentResolver().openOutputStream(uri); writePdfToStream(out); out.close(); pdfLast=new File(getCacheDir(),"last.pdf"); }

    void writePdfToStream(OutputStream out)throws Exception{
        PdfDocument doc=new PdfDocument(); int pw=pageW,ph=pageH;
        PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(pw,ph,1).create(); PdfDocument.Page p=doc.startPage(pi); Canvas c=p.getCanvas(); c.drawColor(Color.WHITE);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); paint.setColor(Color.rgb(20,30,45)); paint.setTextSize(Math.max(14,editor.getTextSize()/getResources().getDisplayMetrics().scaledDensity)); paint.setTypeface(currentTypeface);
        String text=editor.getText().toString(); int margin=36; int width=pw-margin*2;
        android.text.TextPaint tp=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG); tp.setColor(paint.getColor()); tp.setTextSize(paint.getTextSize()); tp.setTypeface(currentTypeface);
        android.text.StaticLayout sl=new android.text.StaticLayout(text,tp,width,Layout.Alignment.ALIGN_OPPOSITE,1.0f,0,false);
        c.save(); c.translate(margin,margin); sl.draw(c); c.restore(); doc.finishPage(p); doc.writeTo(out); doc.close();
    }

    void printPdf(){
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print(title.getText().toString(), new PrintDocumentAdapter(){
            public void onLayout(PrintAttributes oldA, PrintAttributes newA, CancellationSignal cs, LayoutResultCallback cb, Bundle extras){
                if(cs.isCanceled()){cb.onLayoutCancelled();return;}
                PrintDocumentInfo info=new PrintDocumentInfo.Builder(safeName(title.getText().toString())+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();
                cb.onLayoutFinished(info,true);
            }
            public void onWrite(PageRange[] ranges, ParcelFileDescriptor dest, CancellationSignal cs, WriteResultCallback cb){
                try{writePdfToStream(new FileOutputStream(dest.getFileDescriptor()));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}
                catch(Exception e){cb.onWriteFailed(e.getMessage());}
            }
        }, null);
    }

    @Override public void onBackPressed(){ if(root!=null && editor!=null){ new AlertDialog.Builder(this).setMessage("Return to home? Unsaved changes may be lost.").setNegativeButton("Cancel",null).setPositiveButton("Home",(d,w)->buildHome()).show(); } else super.onBackPressed(); }

    @Override protected void onResume(){super.onResume();}
}

# V73 — Page Zoom Reset and Scroll Lock

Major update requested from the latest demo reference:

1. The page starts at 100% and is kept naturally inside the editor viewport.
2. Pinch zoom changes the complete page scale from 55% to 280%.
3. A floating reset control (↺) is kept beside the page and restores the original 100% scale and top scroll position.
4. A floating page lock control toggles 🔓 / 🔒. When locked, horizontal and vertical page scrolling is frozen without disabling child text/object touches.
5. V72 real floating crop-style selection frame and resize handles remain unchanged.

GitHub Actions workflow label/artifact is updated to V73.

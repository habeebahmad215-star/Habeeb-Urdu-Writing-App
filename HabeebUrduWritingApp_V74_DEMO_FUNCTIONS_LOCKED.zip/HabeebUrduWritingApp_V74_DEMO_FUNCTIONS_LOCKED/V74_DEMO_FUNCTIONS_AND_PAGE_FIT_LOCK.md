# V74 — Demo Functions + Page Fit Lock

This version is the consolidated mobile-GitHub-build checkpoint after reviewing the supplied demo reference.

## Demo workflow locked in code
- Home → compact editor
- Add New → Add Text
- Add Text / Edit Text composer
- Paste and Urdu keyboard flow
- Add to Design → immediately select the created text object
- Real floating crop-style selection frame
- Drag inside frame to move
- Left/right handles resize width from the corresponding side
- Top/bottom and four corner handles resize the box
- Move, Delete, Duplicate, Edit
- Font, size, color, gradient, shadow, stroke and opacity controls
- Align and arrange actions
- Page/object selection separation
- Save Image panel
- Page zoom by pinch
- Persistent Reset Zoom control beside the page
- Persistent page-scroll Lock/Unlock control beside the page

## V74 correction to V73
The previous reset target was hard-coded to 1.0. On many narrow phones that can leave the page wider than the visible editor. V74 measures the actual mobile editor and computes a `pageFitZoom` baseline. The default page therefore stays inside the available editor as much as the current screen allows. Reset returns to that original fitted state and recenters scroll to the origin.

## Important implementation rule
Visible controls must remain functional. New demo-matching controls should be wired to a real action rather than added as decorative icons.

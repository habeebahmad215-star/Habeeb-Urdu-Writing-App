# V70 — Demo Flow Locked

Base: V69_COMPOSER_ONLY_TEXT_FLOW (latest uploaded build).

## Reference video audit completed
The full demo sequence was reviewed across the 268-second recording. V70 uses V69 as the single base so that V63/V65/V67/V68 improvements are not lost.

## Locked interaction flow
1. New Design / document-size entry flow.
2. Separate Add Text composer with RTL Urdu entry and paste workflow.
3. Add to Design creates a selected, compact text object on the page.
4. Selection frame and floating quick actions stay on the object.
5. Align & Arrange workflow.
6. Page background and transparency workflow.
7. Page management and add-page workflow.
8. Move/position workflow.
9. Font size workflow.
10. Text spacing workflow.
11. Duplicate / copy / flip / rotate / selection workflow.
12. Font picker workflow.
13. Color and gradient workflow.
14. Save Image panel with filename, format, quality and output size.

## Important rule
The video is treated as the layout/function reference: tool order, placement direction and compact density must be preserved. Existing working functions from V69 are retained rather than replaced with decorative mock controls.

## Accent update
Primary action and selected-state accent moved toward the reference purple interaction treatment. Habeeb Urdu branding remains intact.

## Build note
This package was prepared from the latest V69 source. The current environment did not contain Gradle/Android SDK, so a local compile could not be executed here. Build with JDK 17, Gradle 8.9 and Android SDK 35 as specified in README.

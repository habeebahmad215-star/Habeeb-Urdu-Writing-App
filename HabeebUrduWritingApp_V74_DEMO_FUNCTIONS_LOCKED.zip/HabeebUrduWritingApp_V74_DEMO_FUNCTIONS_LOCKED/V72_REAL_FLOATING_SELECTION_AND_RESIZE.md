# V72 — Real Floating Crop-Style Selection

## What changed
- After **Add to Design**, the selected text now gets a real floating selection frame.
- The frame is a touchable view, not only a decorative overlay.
- Drag the **left middle handle** to reduce/increase from the left.
- Drag the **right middle handle** to increase/reduce from the right.
- Corner handles resize width and height together.
- Top/bottom edges resize height.
- Drag inside the frame to move the object smoothly.
- The text box keeps the user-resized dimensions instead of auto-resetting to its old compact size.
- The frame stays synchronized after move/resize.

## Build
Mobile GitHub Actions compatible. Use the existing workflow and download the V72 APK artifact.

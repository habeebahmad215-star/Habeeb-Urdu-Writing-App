# V69 — Composer-only text workflow

## Required flow implemented
- The design canvas no longer accepts typing or paste input.
- New text opens the separate Text Composer.
- Existing text uses Edit to reopen the Composer with the current text.
- Paste, Clear, RTL and LTR controls are available in the Composer.
- Only Add to Design / update returns text to the canvas.
- Main-page text controls are object controls: Move, Delete, Duplicate, Size, Stroke, Shadow, Opacity, Font, Color and Gradient.
- The legacy full-page editor is hidden so it cannot expose a typing cursor.

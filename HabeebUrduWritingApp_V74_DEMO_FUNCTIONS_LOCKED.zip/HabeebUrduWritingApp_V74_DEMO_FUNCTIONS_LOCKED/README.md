V74 — Demo Functions Locked + Mobile Page Auto-Fit

# Habeeb Urdu Writing App V73 — Professional Advanced

**V73:** V72 real floating crop-style selection plus reversible page zoom and page-scroll lock.

## New interface
- Compact professional dashboard with small square quick-start cards
- Professional language selector
- Advanced canvas editor with horizontal + vertical navigation
- Font size 1–70, color, bold, italic and alignment
- Urdu RTL writing and imported TTF/OTF font support
- Object select, lock, delete and duplicate
- Whole-page selection, background and border controls
- Templates including certificate, notice, Islamic poster and corner styles
- Page duplicate/copy, image insertion, layers-like tools, undo/redo
- PDF export, printing, JSON save/open and auto-save
- System-bar safe layout so content starts below the front camera/status area

## Build
Requires JDK 17 and Gradle 8.9 with Android SDK 35 installed.
Run: `gradle assembleDebug`


## V73 Major Page Update
- Page opens at its natural 100% state and stays contained in the editor by default.
- Pinch zoom in/out is supported on the page area (55%–280%).
- A floating ↺ Reset Zoom control remains beside the page; one tap returns to the original 100% state and top position.
- A floating 🔓/🔒 Page Scroll control remains beside the page. When locked, vertical and horizontal page scrolling is frozen while child text/object interaction remains available.
- Existing V72 floating crop-style selection and resize handles are retained.

# V71 — Two Demo Reference Locked

Base source: V69 latest uploaded source, consolidated through V70.

## Reference material reviewed
- 139349.mp4 — compact editor/add-text reference sequence.
- 138827.mp4 — full workflow reference, including text object, arrange, pages,
  move, font size, spacing, color, and save-image flows.

## Locked implementation target
The app source keeps the reference workflow as the priority:
1. New Design / document entry.
2. Separate Add Text and Edit Text composer.
3. RTL Urdu typing and plain-text paste.
4. Add to Design creates a compact selected text object.
5. Floating object actions remain attached to the selected object.
6. Bottom tool groups remain compact and horizontally ordered like the reference.
7. Align & Arrange, move, lock, duplicate, delete and deselect workflows.
8. Font, size, text spacing, word spacing and line spacing.
9. Color, gradient, opacity, shadow and stroke controls.
10. Background, transparency, border and page tools.
11. Multi-page creation, switching, duplication and page management.
12. Save Image panel with filename, format, quality and output-size controls.

## Source rule
Do not replace working editor functions with decorative mock buttons. Keep the
existing V69 text composer, selection handling, plain paste and reflow logic as
the functional base while matching the reference interaction order and compact
density.

## Important visual rule
The demo is used as the layout/interaction reference: tool direction, grouping,
compact sizing and flow should be preserved. Branding remains Habeeb Urdu and is
not replaced by the reference app's branding.

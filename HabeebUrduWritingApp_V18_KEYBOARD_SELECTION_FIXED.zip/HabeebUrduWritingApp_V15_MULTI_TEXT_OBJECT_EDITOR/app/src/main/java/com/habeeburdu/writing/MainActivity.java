package com.habeeburdu.writing;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.*;
import android.text.*;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import android.graphics.drawable.ColorDrawable;

/** Advanced, dependency-free Urdu document designer. */
public class MainActivity extends Activity {
    final int BLUE=(int)0xFF123B67L, BLUE2=(int)0xFF1F5F9FL, GREEN=(int)0xFF178B54L, PURPLE=(int)0xFF7046A5L, RED=(int)0xFFB43A34L, BG=(int)0xFFF3F6FAL;
    LinearLayout root, editorRoot, tools; EditText title; SelectionEditText editor; FrameLayout paper; ScrollView verticalScroll; HorizontalScrollView horizontalScroll;
    Spinner fontSpinner, languageSpinner; SeekBar zoomBar, sizeBar;
    View pageSelectionOverlay; ImageView selectedImage; LinearLayout contextBar; boolean textToolsMode=false; boolean objectLocked=false, pageSelected=false; TextView zoomLabel, sizeLabel; ScaleGestureDetector textScaleDetector; ArrayList<PageState> pages=new ArrayList<>(); int currentPage=0;
    String currentFontName="System Urdu"; Typeface currentTypeface=Typeface.DEFAULT;
    final ArrayList<SelectionEditText> textObjects=new ArrayList<>(); SelectionEditText primaryEditor;
    int pageW=595,pageH=842,textColor=(int)0xFF182638L,paperColor=Color.WHITE; boolean bold=false,italic=false,center=false,landscape=false;
    File fontDir; ArrayList<String> fontNames=new ArrayList<>(); HashMap<String,Typeface> typefaces=new HashMap<>();
    Bitmap pageImage; final ArrayList<String> undoStack=new ArrayList<>(), redoStack=new ArrayList<>(); boolean changing=false;
    // Keeps a word/phrase selected when Android's Back key closes the keyboard.
    int preservedSelectionStart=-1, preservedSelectionEnd=-1; boolean preserveSelectionAfterImeBack=false;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    int sp(float v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,v,getResources().getDisplayMetrics());}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor((int)0xFF1D2A3AL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);return b;}

    /** EditText with reliable long-press word selection and selection change reporting. */
    static class SelectionEditText extends android.widget.EditText {
        interface SelectionListener { void onSelectionChanged(int start,int end); }
        interface KeyboardBackListener { void onKeyboardBack(SelectionEditText view); }
        SelectionListener listener; KeyboardBackListener keyboardBackListener;
        float lastTouchX,lastTouchY;
        SelectionEditText(Context c){ super(c); }
        void setSelectionListener(SelectionListener l){ listener=l; }
        void setKeyboardBackListener(KeyboardBackListener l){ keyboardBackListener=l; }
        @Override public boolean onKeyPreIme(int keyCode, KeyEvent event){
            if(keyCode==KeyEvent.KEYCODE_BACK && event.getAction()==KeyEvent.ACTION_UP &&
                    getSelectionStart()!=getSelectionEnd() && keyboardBackListener!=null){
                keyboardBackListener.onKeyboardBack(this);
            }
            return super.onKeyPreIme(keyCode,event);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                lastTouchX=e.getX(); lastTouchY=e.getY();
            }
            return super.onTouchEvent(e);
        }
        @Override public boolean performLongClick(){
            // Use Android's native selection system: highlight + drag handles.
            boolean handled=super.performLongClick();
            // Some Android builds keep the cursor collapsed after long-press.
            // Force word selection in that case so the text is visibly highlighted.
            post(()->{
                if(getSelectionStart()==getSelectionEnd()) selectWordAtLastTouch();
                if(listener!=null)listener.onSelectionChanged(getSelectionStart(),getSelectionEnd());
            });
            return handled;
        }
        void selectWordAtLastTouch(){
            try{
                int off=getOffsetForPosition(lastTouchX,lastTouchY);
                CharSequence cs=getText(); int n=cs.length();
                if(n==0)return; off=Math.max(0,Math.min(off,n-1));
                if(isBreak(cs.charAt(off)) && off>0) off--;
                int a=off,b=Math.min(n,off+1);
                while(a>0 && !isBreak(cs.charAt(a-1)))a--;
                while(b<n && !isBreak(cs.charAt(b)))b++;
                if(a<b) setSelection(a,b);
            }catch(Exception ignored){}
        }
        @Override public boolean onTextContextMenuItem(int id){
            boolean r=super.onTextContextMenuItem(id);
            post(()->{ if(listener!=null) listener.onSelectionChanged(getSelectionStart(),getSelectionEnd()); });
            return r;
        }
        boolean isBreak(char c){ return Character.isWhitespace(c) || ",.;:!?()[]{}\"'،۔؛:!?\n\r\t".indexOf(c)>=0; }
        @Override protected void onSelectionChanged(int selStart,int selEnd){
            super.onSelectionChanged(selStart,selEnd);
            if(listener!=null) listener.onSelectionChanged(selStart,selEnd);
        }
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BLUE);getWindow().setNavigationBarColor(BLUE); if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(true); getWindow().getDecorView().setSystemUiVisibility(0);} fontDir=new File(getFilesDir(),"fonts");fontDir.mkdirs();loadFonts();buildHome();}
    void installInsets(View v){v.setOnApplyWindowInsetsListener((view,insets)->{
        if(Build.VERSION.SDK_INT>=30){
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
            android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());
            // Include the IME inset so the bottom Text Tools bar moves ABOVE the keyboard.
            view.setPadding(0,bars.top,0,Math.max(bars.bottom,ime.bottom));
        }
        return insets;
    });}
    void loadFonts(){fontNames.clear();typefaces.clear();fontNames.add("System Urdu");typefaces.put("System Urdu",Typeface.DEFAULT);File[] fs=fontDir.listFiles();if(fs!=null)for(File f:fs){try{Typeface t=Typeface.createFromFile(f);fontNames.add(f.getName());typefaces.put(f.getName(),t);}catch(Exception ignored){}}}

    void buildHome(){
        editor=null; paper=null; selectedImage=null;
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);installInsets(root);setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.setPadding(dp(18),dp(12),dp(18),dp(12));header.setBackgroundColor(BLUE);
        LinearLayout hr=new LinearLayout(this);hr.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(getResources().getIdentifier("habeeb_logo","drawable",getPackageName()));logo.setScaleType(ImageView.ScaleType.CENTER_CROP);GradientDrawable lg=bg(Color.WHITE,28);logo.setBackground(lg);hr.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setPadding(dp(10),0,dp(4),0);
        TextView h=text("Habeeb Urdu Designer",20);h.setTextColor(Color.WHITE);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);names.addView(h,new LinearLayout.LayoutParams(-1,dp(29)));
        TextView loc=text("Writing • Calligraphy • Graphic Design",11);loc.setTextColor((int)0xFFDCE9F6L);names.addView(loc,new LinearLayout.LayoutParams(-1,dp(19)));
        hr.addView(names,new LinearLayout.LayoutParams(0,dp(52),1));
        Button lang=button("🌐 اردو");lang.setTextColor(Color.WHITE);lang.setTextSize(11);lang.setBackground(bg(BLUE2,12));lang.setOnClickListener(v->showHomeLanguage());hr.addView(lang,new LinearLayout.LayoutParams(dp(88),dp(46)));
        header.addView(hr);root.addView(header);

        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(12),dp(12),dp(12),dp(26));
        TextView welcome=text("اردو تحریر، خوبصورت ڈیزائن اور پروفیشنل گرافکس ایک ہی جگہ",15);welcome.setGravity(Gravity.CENTER);welcome.setTextColor((int)0xFF233548L);welcome.setPadding(dp(6),dp(3),dp(6),dp(12));body.addView(welcome);

        LinearLayout stats=new LinearLayout(this);stats.setGravity(Gravity.CENTER);homeStat(stats,"📄","Documents",BLUE2);homeStat(stats,"✦","Templates",PURPLE);homeStat(stats,"🔤","Fonts",GREEN);homeStat(stats,"★","Designs",(int)0xFF9A651FL);body.addView(stats,new LinearLayout.LayoutParams(-1,dp(76)));

        section(body,"Start Here","Simple and easy");
        addHomeGrid(body,new String[][]{
            {"✚","New Document","Start writing"},{"🧩","Templates","Ready designs"},{"📂","Open","Saved document"},{"PDF","Export PDF","Save or share"},
            {"📜","Certificate","Professional"},{"☪","Islamic Poster","Urdu design"},{"🔤","Fonts","TTF / OTF"},{"…","More Tools","Advanced"}
        },new View.OnClickListener[]{
            v->buildEditor(),v->chooseTemplate(),v->openDocument(),v->{buildEditor();exportPdf();},
            v->{buildEditor();chooseTemplateIndex(5);},v->{buildEditor();chooseTemplateIndex(4);},v->showFontsDialog(),v->{buildEditor();showMoreTools();}
        });

        section(body,"How it works","Professional but simple");
        TextView guide=text("1. New Document سے لکھنا شروع کریں\n2. متن منتخب کریں تو Text Tools خود ظاہر ہوں گے\n3. متن منتخب نہ ہو تو Page Tools ظاہر ہوں گے\n4. Save, PDF اور Print اوپر سے آسانی سے کریں",13);
        guide.setPadding(dp(16),dp(16),dp(16),dp(16));guide.setTextColor((int)0xFF334155L);guide.setBackground(bg(Color.WHITE,14));body.addView(guide,new LinearLayout.LayoutParams(-1,-2));

        TextView tip=text("Tip: غیر ضروری دہرائے گئے آپشنز کم کیے گئے ہیں تاکہ ایپ صاف، آسان اور user-friendly رہے۔",12);tip.setPadding(dp(14),dp(14),dp(14),dp(14));tip.setTextColor((int)0xFF526273L);tip.setBackground(bg(Color.WHITE,14));body.addView(tip,new LinearLayout.LayoutParams(-1,-2));
        sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    void section(LinearLayout body,String title,String sub){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(2),dp(14),dp(2),dp(7));TextView a=text(title,18);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.addView(a,new LinearLayout.LayoutParams(0,dp(36),1));TextView b=text(sub,10);b.setTextColor((int)0xFF6B7785L);b.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);r.addView(b,new LinearLayout.LayoutParams(dp(150),dp(36)));body.addView(r);}
    void homeStat(LinearLayout p,String icon,String label,int color){LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER);c.setPadding(dp(5),0,dp(5),0);c.setBackground(bg(Color.WHITE,14));LinearLayout in=new LinearLayout(this);in.setOrientation(LinearLayout.VERTICAL);in.setGravity(Gravity.CENTER);TextView i=text(icon,18);i.setGravity(Gravity.CENTER);i.setTextColor(color);in.addView(i,new LinearLayout.LayoutParams(-1,dp(30)));TextView t=text(label,9);t.setGravity(Gravity.CENTER);t.setTextColor((int)0xFF526273L);in.addView(t,new LinearLayout.LayoutParams(-1,dp(22)));c.addView(in,new LinearLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),0,dp(3),0);p.addView(c,lp);}
    void addHomeGrid(LinearLayout body,String[][] labels,View.OnClickListener[] listeners){for(int i=0;i<labels.length;i+=4){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);for(int j=0;j<4&&i+j<labels.length;j++){final int k=i+j;homeTile(row,labels[k][0],labels[k][1],labels[k][2],listeners[k]);}body.addView(row,new LinearLayout.LayoutParams(-1,dp(102)));}}
    void homeTile(LinearLayout p,String icon,String title,String sub,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(3),dp(7),dp(3),dp(4));c.setBackground(bg(Color.WHITE,14));c.setElevation(dp(2));c.setOnClickListener(l);TextView i=text(icon,20);i.setGravity(Gravity.CENTER);i.setTextColor(BLUE2);c.addView(i,new LinearLayout.LayoutParams(-1,dp(34)));TextView a=text(title,11);a.setGravity(Gravity.CENTER);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);c.addView(a,new LinearLayout.LayoutParams(-1,dp(25)));TextView b=text(sub,8);b.setGravity(Gravity.CENTER);b.setTextColor((int)0xFF778391L);c.addView(b,new LinearLayout.LayoutParams(-1,dp(20)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(3),dp(3),dp(3),dp(3));p.addView(c,lp);}
    void chooseTemplateIndex(int w){String[] a={"Blank Document","Islamic Notice","Character Certificate","Simple Poster","Islamic Poster","Madrasa Certificate","Elegant Gold Page","Corner Arrow Page","Modern Blue Frame"};if(w<0||w>=a.length){chooseTemplate();return;}String t="";paperColor=Color.WHITE;if(w==1){t="اعلان\n\nتمام طلبہ و طالبات کو مطلع کیا جاتا ہے کہ\n\n________________________________\n\nتاریخ: __________";applyBorder(4);}else if(w==2){t="کردار نامہ\n\nیہ تصدیق کی جاتی ہے کہ\n\n________________________________\n\nنے ہمارے ادارے میں اچھے اخلاق اور بہترین کردار کا مظاہرہ کیا ہے۔\n\nدستخط: __________";applyBorder(3);}else if(w==3){t="بسم اللہ الرحمن الرحیم\n\nعنوان یہاں لکھیں\n\nاپنا خوبصورت پیغام یہاں تحریر کریں";applyBorder(2);}else if(w==4){t="بسم اللہ الرحمن الرحیم\n\nاسلامی پوسٹر\n\nاپنا پیغام یہاں تحریر کریں";paperColor=(int)0xFFFFFDF8L;applyBorder(4);}else if(w==5){t="دارالتحفیظ للقرآن الکریم\n\nاعزازی سند\n\nیہ سند __________ کو دی جاتی ہے";paperColor=(int)0xFFF7F0E2L;applyBorder(1);}else if(w==6){t="بسم اللہ الرحمن الرحیم\n\nخوبصورت اردو ڈیزائن\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFFFFCF4L;applyBorder(1);}else if(w==7){t="عنوان\n\nاپنا پیغام یہاں لکھیں";applyBorder(2);}else if(w==8){t="PROFESSIONAL PAGE\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFEFF6FFL;applyBorder(2);}else applyBorder(0);paper.setBackgroundColor(paperColor);changing=true;editor.setText(t);changing=false;undoStack.clear();undoStack.add(t);toast(a[w]+" loaded");}
    void showMoreTools(){new AlertDialog.Builder(this).setTitle("Advanced Design Tools").setItems(new String[]{"Text Editor","Font Import","Templates","Background","Borders","Add Image","Object Tools","Page Setup"},(d,w)->{if(w==0){}else if(w==1)importFont();else if(w==2)chooseTemplate();else if(w==3)choosePaperColor();else if(w==4)chooseBorder();else if(w==5)pickImage();else if(w==6)selectObject();else choosePage();}).show();}
    void showHomeLanguage(){String[] a={"اردو — Urdu RTL","English — LTR","العربية — Arabic RTL","हिन्दी — Hindi","বাংলা — Bengali","ਪੰਜਾਬੀ — Punjabi","Roman Urdu — LTR"};new AlertDialog.Builder(this).setTitle("Select Language").setItems(a,(d,w)->toast(a[w]+" selected")).show();}

    void buildEditor(){
        pages.clear(); textObjects.clear(); primaryEditor=null; currentPage=0; pageSelected=false; pageSelectionOverlay=null; textToolsMode=false; preserveSelectionAfterImeBack=false; preservedSelectionStart=-1; preservedSelectionEnd=-1;
        editorRoot=new LinearLayout(this); editorRoot.setOrientation(LinearLayout.VERTICAL); editorRoot.setBackgroundColor(BG); installInsets(editorRoot); setContentView(editorRoot); root=editorRoot;
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(5),0,dp(6),0); top.setBackgroundColor(BLUE);
        Button back=button("‹"); back.setTextSize(30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->confirmHome()); top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(56)));
        title=new EditText(this); title.setSingleLine(); title.setText("Untitled Urdu Document"); title.setTextColor(Color.WHITE); title.setTextSize(17); title.setBackgroundColor(Color.TRANSPARENT); top.addView(title,new LinearLayout.LayoutParams(0,dp(56),1));
        addTop(top,"Save",v->saveDocument()); addTop(top,"PDF",v->exportPdf()); addTop(top,"Print",v->printPdf()); editorRoot.addView(top);

        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); tools=new LinearLayout(this); tools.setPadding(dp(6),dp(5),dp(6),dp(5)); tools.setGravity(Gravity.CENTER_VERTICAL); tools.setBackgroundColor(Color.WHITE);
        languageSpinner=new Spinner(this); String[] langs={"🌐 Language / زبان","اردو — Urdu RTL","English — LTR","العربية — Arabic RTL","हिन्दी — Hindi","বাংলা — Bengali","ਪੰਜਾਬੀ — Punjabi","ગુજરાતી — Gujarati","मराठी — Marathi","தமிழ் — Tamil","తెలుగు — Telugu","Roman Urdu — LTR"};
        languageSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,langs)); languageSpinner.setSelection(1); languageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(pos>0)applyLanguage(pos);}}); tools.addView(languageSpinner,new LinearLayout.LayoutParams(dp(150),dp(48)));
        fontSpinner=new Spinner(this); ArrayAdapter<String> fa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames); fontSpinner.setAdapter(fa); fontSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(editor!=null && pos>=0 && pos<fontNames.size()){currentFontName=fontNames.get(pos); currentTypeface=typefaces.get(currentFontName); applyTypeface();}}}); tools.addView(fontSpinner,new LinearLayout.LayoutParams(dp(155),dp(48)));
        addTool("Edit",v->{editor.requestFocus(); showKeyboardReliable(); updateContextMode();}); addTool("+ Text",v->addTextObject()); addTool("Objects",v->showObjectsDialog()); addTool("Undo",v->undo()); addTool("Redo",v->redo()); addTool("Image",v->pickImage()); addTool("More",v->showMoreTools());
        hsv.addView(tools); editorRoot.addView(hsv,new LinearLayout.LayoutParams(-1,dp(58)));

        verticalScroll=new ScrollView(this); verticalScroll.setFillViewport(true); verticalScroll.setClipToPadding(false); horizontalScroll=new HorizontalScrollView(this); horizontalScroll.setFillViewport(true);
        FrameLayout stage=new FrameLayout(this); stage.setBackgroundColor((int)0xFFE1E6ECL); stage.setPadding(dp(22),dp(20),dp(22),dp(40)); stage.setOnClickListener(v->activatePageMode());
        paper=new FrameLayout(this); paper.setBackgroundColor(paperColor); paper.setElevation(dp(3)); paper.setClickable(true); paper.setOnClickListener(v->activatePageMode());
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(595),dp(842),Gravity.TOP|Gravity.CENTER_HORIZONTAL); stage.addView(paper,pp);

        editor=createTextObject("الحمد لله رب العالمین\n\nاپنا اردو متن یہاں لکھیں…",0,0,true);
        primaryEditor=editor;
        applyTypeface(); setupUndo(); pages.add(capturePage());
        horizontalScroll.addView(stage,new HorizontalScrollView.LayoutParams(-1,-1)); verticalScroll.addView(horizontalScroll,new ScrollView.LayoutParams(-1,-1)); editorRoot.addView(verticalScroll,new LinearLayout.LayoutParams(-1,0,1));

        contextBar=new LinearLayout(this); contextBar.setOrientation(LinearLayout.VERTICAL); contextBar.setPadding(dp(8),dp(5),dp(8),dp(6)); contextBar.setBackgroundColor(Color.WHITE); contextBar.setElevation(dp(10)); editorRoot.addView(contextBar,new LinearLayout.LayoutParams(-1,dp(178)));
        showPageTools();
    }

    /** Creates an independent text object. The active object becomes the editor target. */
    SelectionEditText createTextObject(String initial,int left,int top,boolean fillPage){
        SelectionEditText e=new SelectionEditText(this);
        e.setText(initial); e.setTextSize(30); e.setTextColor(textColor);
        e.setGravity(Gravity.TOP|Gravity.RIGHT); e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setPadding(dp(18),dp(18),dp(18),dp(18)); e.setBackgroundColor(Color.TRANSPARENT);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setHint("اردو میں لکھنا شروع کریں…"); e.setHintTextColor((int)0xFF9AA5B1L);
        e.setFocusableInTouchMode(true); e.setLongClickable(true); e.setSelectAllOnFocus(false);
        e.setSelectionListener((a,b)->{ if(editor==e && contextBar!=null)e.post(()->updateContextMode()); });
        e.setKeyboardBackListener(v->rememberSelectionBeforeKeyboardBack(v));
        e.setOnFocusChangeListener((v,has)->{if(has)setActiveTextObject(e);});
        textScaleDetector=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){float base;
            public boolean onScaleBegin(ScaleGestureDetector d){base=e.getTextSize()/getResources().getDisplayMetrics().scaledDensity;return true;}
            public boolean onScale(ScaleGestureDetector d){float n=Math.max(8,Math.min(96,base*d.getScaleFactor()));e.setTextSize(n);if(sizeLabel!=null)sizeLabel.setText("Font "+(int)n+"sp");return true;}});
        e.setOnTouchListener((v,event)->{ if(event.getPointerCount()>1){textScaleDetector.onTouchEvent(event);return textScaleDetector.isInProgress();}
            if(event.getAction()==MotionEvent.ACTION_DOWN)setActiveTextObject(e);
            return false; });
        FrameLayout.LayoutParams lp=fillPage?new FrameLayout.LayoutParams(-1,-1):new FrameLayout.LayoutParams(dp(260),dp(150));
        if(!fillPage){lp.leftMargin=dp(left);lp.topMargin=dp(top); GradientDrawable g=new GradientDrawable();g.setColor(Color.TRANSPARENT);g.setStroke(dp(1),(int)0x225B6B7AL);e.setBackground(g);}
        paper.addView(e,lp); textObjects.add(e); return e;
    }
    void setActiveTextObject(SelectionEditText e){
        if(e==null)return; editor=e;
        for(SelectionEditText x:textObjects){ if(x==e){ if(x.getBackground() instanceof ColorDrawable){} } }
        if(contextBar!=null)updateContextMode();
    }
    void addTextObject(){
        if(paper==null)return;
        SelectionEditText e=createTextObject("نیا اردو متن",28,70,false);
        setActiveTextObject(e); e.requestFocus(); e.setSelection(e.length()); showKeyboardReliable();
        toast("New text box added — tap inside to edit, long press to select text");
    }
    void showObjectsDialog(){
        if(textObjects.isEmpty()){toast("No text objects");return;}
        String[] names=new String[textObjects.size()];
        for(int i=0;i<names.length;i++){String t=textObjects.get(i).getText().toString().replace("\\n"," "); if(t.length()>28)t=t.substring(0,28)+"…"; names[i]="Text "+(i+1)+": "+t;}
        new AlertDialog.Builder(this).setTitle("Text Objects").setItems(names,(d,w)->{setActiveTextObject(textObjects.get(w));textObjects.get(w).requestFocus();}).show();
    }
    void deleteActiveTextObject(){
        if(editor==null)return;
        if(editor==primaryEditor){deleteSelected();return;}
        paper.removeView(editor); textObjects.remove(editor); editor=primaryEditor; if(editor!=null)editor.requestFocus(); showPageTools(); toast("Text box deleted");
    }

    void updateContextMode(){
        if(editor==null || contextBar==null) return;
        int a=editor.getSelectionStart(), b=editor.getSelectionEnd();
        if(a>=0 && b>=0 && a!=b){ showTextTools(); return; }
        // Android may briefly collapse selection while the Back key hides the IME.
        // Restore the exact selection instead of closing the Text Tools panel.
        if(preserveSelectionAfterImeBack && preservedSelectionStart>=0 && preservedSelectionEnd>preservedSelectionStart){
            final int start=Math.min(preservedSelectionStart,editor.length());
            final int end=Math.min(preservedSelectionEnd,editor.length());
            editor.postDelayed(()->{
                if(editor!=null && preserveSelectionAfterImeBack){
                    try{ editor.setSelection(start,end); }catch(Exception ignored){}
                    preserveSelectionAfterImeBack=false;
                    preservedSelectionStart=-1; preservedSelectionEnd=-1;
                    showTextTools();
                }
            },80);
            return;
        }
        showPageTools();
    }

    void rememberSelectionBeforeKeyboardBack(SelectionEditText e){
        if(e==null || e!=editor)return;
        int a=e.getSelectionStart(), b=e.getSelectionEnd();
        if(a>=0 && b>=0 && a!=b){
            preservedSelectionStart=Math.min(a,b); preservedSelectionEnd=Math.max(a,b);
            preserveSelectionAfterImeBack=true;
            textToolsMode=true;
        }
    }

    /** Explicit page mode: close text editing and restore page controls. */
    void activatePageMode(){
        preserveSelectionAfterImeBack=false; preservedSelectionStart=-1; preservedSelectionEnd=-1;
        if(editor!=null){
            int p=Math.max(0,editor.getSelectionEnd());
            editor.setSelection(p); // collapses any highlighted range
            editor.clearFocus();
            InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null) imm.hideSoftInputFromWindow(editor.getWindowToken(),0);
        }
        showPageTools();
    }

    void showKeyboardReliable(){
        if(editor==null || objectLocked)return;
        editor.setFocusableInTouchMode(true); editor.requestFocus();
        editor.postDelayed(()->{InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); if(imm!=null){imm.showSoftInput(editor,InputMethodManager.SHOW_IMPLICIT); imm.showSoftInput(editor,InputMethodManager.SHOW_FORCED);}},120);
    }
    View contextButton(String icon,String label,View.OnClickListener click){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(dp(4),dp(2),dp(4),dp(2)); box.setClickable(true); box.setBackground(bg((int)0xFFF7F8FCL,10)); box.setOnClickListener(click);
        TextView a=text(icon,20); a.setGravity(Gravity.CENTER); a.setTextColor(PURPLE); box.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView b=text(label,10); b.setGravity(Gravity.CENTER); b.setSingleLine(); b.setTextColor((int)0xFF4E5865L); box.addView(b,new LinearLayout.LayoutParams(-1,dp(28)));
        return box;
    }
    void contextRow(LinearLayout row,String icon,String label,View.OnClickListener click){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(78),dp(62)); lp.setMargins(dp(3),dp(2),dp(3),dp(2)); row.addView(contextButton(icon,label,click),lp); }
    void showTextTools(){
        if(contextBar==null)return; textToolsMode=true; contextBar.removeAllViews();
        TextView head=text("TEXT SELECTED • Tools are ready below",11); head.setPadding(dp(10),0,0,0); head.setTextColor(PURPLE); head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); contextBar.addView(head,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout r1=new LinearLayout(this); r1.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(r1,"Aa","Font",v->showFontsDialog()); contextRow(r1,"↕","Size",v->showSizeDialog()); contextRow(r1,"B","Bold",v->toggleStyleSelection(Typeface.BOLD)); contextRow(r1,"I","Italic",v->toggleStyleSelection(Typeface.ITALIC)); contextRow(r1,"U","Underline",v->toggleUnderlineSelection()); contextRow(r1,"◆","Color",v->chooseTextColor());
        HorizontalScrollView hs1=new HorizontalScrollView(this); hs1.setHorizontalScrollBarEnabled(false); hs1.addView(r1,new HorizontalScrollView.LayoutParams(-2,dp(70))); contextBar.addView(hs1,new LinearLayout.LayoutParams(-1,dp(70)));
        LinearLayout r2=new LinearLayout(this); r2.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(r2,"▤","Align",v->chooseAlignment()); contextRow(r2,"▣","Copy",v->copySelection(false)); contextRow(r2,"✂","Cut",v->copySelection(true)); contextRow(r2,"▣+","Paste",v->pasteClipboard()); contextRow(r2,"⌫","Delete",v->deleteSelected()); contextRow(r2,"▣×","Delete Box",v->deleteActiveTextObject()); contextRow(r2,"ALL","All",v->{editor.selectAll();updateContextMode();});
        HorizontalScrollView hs2=new HorizontalScrollView(this); hs2.setHorizontalScrollBarEnabled(false); hs2.addView(r2,new HorizontalScrollView.LayoutParams(-2,dp(70))); contextBar.addView(hs2,new LinearLayout.LayoutParams(-1,dp(70)));
    }
    void showPageTools(){
        if(contextBar==null)return; textToolsMode=false;
        contextBar.removeAllViews(); TextView head=text("PAGE TOOLS • Tap text to edit, select text for text tools",11); head.setPadding(dp(8),0,0,0); head.setTextColor(BLUE2); head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); contextBar.addView(head,new LinearLayout.LayoutParams(-1,dp(22)));
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(row,"＋","Text Box",v->addTextObject()); contextRow(row,"▦","Objects",v->showObjectsDialog()); contextRow(row,"＋","New Page",v->addNewPage()); contextRow(row,"↔","Paper Size",v->choosePage()); contextRow(row,"◇","Background",v->choosePaperColor()); contextRow(row,"▣","Border",v->chooseBorder()); contextRow(row,"▤","Pages",v->showPageEditDialog()); contextRow(row,"▧","Template",v->chooseTemplate()); contextRow(row,"🖼","Add Image",v->pickImage()); contextRow(row,"🔒","Lock",v->toggleLock());
        hs.addView(row,new HorizontalScrollView.LayoutParams(-2,dp(70))); contextBar.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
    }

    void addTop(LinearLayout row,String label,View.OnClickListener l){Button b=button(label);b.setTextColor(Color.WHITE);b.setTextSize(10);b.setBackground(bg(BLUE2,10));b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(54),dp(42));lp.setMargins(dp(2),0,dp(2),0);row.addView(b,lp);}
    void addTool(String label,View.OnClickListener l){Button b=button(label);b.setTextSize(11);b.setTextColor(BLUE);b.setBackground(bg((int)0xFFF2F5F8L,10));b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(82),dp(42));lp.setMargins(dp(3),0,dp(3),0);tools.addView(b,lp);}


    void applyTypeface(){
        if(editor==null)return;
        if(currentTypeface==null)currentTypeface=Typeface.DEFAULT;
        int style=(bold?Typeface.BOLD:Typeface.NORMAL)|(italic?Typeface.ITALIC:Typeface.NORMAL);
        editor.setTypeface(currentTypeface,style);
    }

    void applyGravity(){
        if(editor==null)return;
        if(center){
            editor.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        }else{
            boolean rtl=languageSpinner==null || languageSpinner.getSelectedItemPosition()==1 || languageSpinner.getSelectedItemPosition()==3;
            editor.setGravity(Gravity.TOP|(rtl?Gravity.RIGHT:Gravity.LEFT));
        }
    }

    void setupUndo(){
        undoStack.clear();
        redoStack.clear();
        if(editor==null)return;
        undoStack.add(editor.getText().toString());
        editor.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable s){
                if(changing)return;
                String now=s.toString();
                if(undoStack.isEmpty() || !now.equals(undoStack.get(undoStack.size()-1))){
                    undoStack.add(now);
                    if(undoStack.size()>100)undoStack.remove(0);
                    redoStack.clear();
                }
                saveCurrentPageState();
            }
        });
    }

    void undo(){
        if(editor==null || undoStack.size()<2){toast("Nothing to undo");return;}
        String current=undoStack.remove(undoStack.size()-1);
        redoStack.add(current);
        String previous=undoStack.get(undoStack.size()-1);
        changing=true;
        editor.setText(previous);
        editor.setSelection(editor.length());
        changing=false;
        saveCurrentPageState();
    }

    void redo(){
        if(editor==null || redoStack.isEmpty()){toast("Nothing to redo");return;}
        String next=redoStack.remove(redoStack.size()-1);
        undoStack.add(next);
        changing=true;
        editor.setText(next);
        editor.setSelection(editor.length());
        changing=false;
        saveCurrentPageState();
    }

    void applyLanguage(int p){if(editor==null)return;boolean rtl=(p==1||p==3);Locale loc=new Locale("ur","PK");if(p==2||p==11)loc=Locale.ENGLISH;else if(p==3)loc=new Locale("ar");else if(p==4)loc=new Locale("hi","IN");else if(p==5)loc=new Locale("bn","BD");else if(p==6)loc=new Locale("pa","IN");else if(p==7)loc=new Locale("gu","IN");else if(p==8)loc=new Locale("mr","IN");else if(p==9)loc=new Locale("ta","IN");else if(p==10)loc=new Locale("te","IN");editor.setTextDirection(rtl?View.TEXT_DIRECTION_RTL:View.TEXT_DIRECTION_LTR);editor.setTextLocale(loc);if(rtl)editor.setGravity(Gravity.TOP|Gravity.RIGHT);else editor.setGravity(Gravity.TOP|Gravity.LEFT);toast("Language activated: "+languageSpinner.getSelectedItem());}
    void toggleStyleSelection(int style){
        int a=editor.getSelectionStart(),b=editor.getSelectionEnd();
        if(a==b){toast("Select text first");return;}
        Editable e=editor.getText(); a=Math.min(a,b);b=Math.max(a,b);
        StyleSpan[] old=e.getSpans(a,b,StyleSpan.class); boolean remove=false;
        for(StyleSpan sp:old) if((sp.getStyle()&style)!=0){remove=true; e.removeSpan(sp);}
        if(!remove)e.setSpan(new StyleSpan(style),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        toast(remove?"Style removed":"Style applied");
    }
    void showSizeDialog(){
        final String[] sizes={"14","18","22","26","30","36","42","48"};
        new AlertDialog.Builder(this).setTitle("Selected text size").setItems(sizes,(d,w)->applySizeToSelection(Float.parseFloat(sizes[w]))).show();
    }
    void applySizeToSelection(float size){
        int a=editor.getSelectionStart(),b=editor.getSelectionEnd();
        if(a==b){toast("Select text first");return;}
        editor.getText().setSpan(new android.text.style.RelativeSizeSpan(size/(editor.getTextSize()/getResources().getDisplayMetrics().scaledDensity)),Math.min(a,b),Math.max(a,b),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    void chooseAlignment(){new AlertDialog.Builder(this).setTitle("Text Alignment").setItems(new String[]{"Right (Urdu/Arabic)","Center","Left"},(d,w)->{if(w==0){center=false;editor.setGravity(Gravity.TOP|Gravity.RIGHT);}else if(w==1){center=true;applyGravity();}else{center=false;editor.setGravity(Gravity.TOP|Gravity.LEFT);}}).show();}
    void showTextEditDialog(){if(editor==null)return;new AlertDialog.Builder(this).setTitle("Text Edit").setItems(new String[]{"Font","Font Size (pinch with two fingers)","Bold","Italic","Underline selected text","Text Color","Alignment","Copy selected text","Cut selected text","Paste","Delete selected text"},(d,w)->{if(w==0)showFontsDialog();else if(w==1)toast("Use two fingers on the text and pinch in/out");else if(w==2){bold=!bold;applyTypeface();}else if(w==3){italic=!italic;applyTypeface();}else if(w==4)toggleUnderlineSelection();else if(w==5)chooseTextColor();else if(w==6)chooseAlignment();else if(w==7)copySelection(false);else if(w==8)copySelection(true);else if(w==9)pasteClipboard();else deleteSelected();}).show();}
    void toggleUnderlineSelection(){int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a==b){toast("Select text first");return;}Editable e=editor.getText();e.setSpan(new UnderlineSpan(),Math.min(a,b),Math.max(a,b),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);toast("Underline applied");}
    void copySelection(boolean cut){int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a==b){toast("Select text first");return;}String x=editor.getText().subSequence(Math.min(a,b),Math.max(a,b)).toString();android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("text",x));if(cut)editor.getText().delete(Math.min(a,b),Math.max(a,b));toast(cut?"Text cut":"Text copied");}
    void pasteClipboard(){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence x=cm.getPrimaryClip().getItemAt(0).coerceToText(this);editor.getText().insert(Math.max(0,editor.getSelectionStart()),x);toast("Text pasted");}else toast("Clipboard is empty");}
    void selectObject(){if(selectedImage!=null)toast("Image selected");else {editor.requestFocus();toast("Text object selected");}}
    void toggleLock(){objectLocked=!objectLocked;editor.setEnabled(!objectLocked);if(selectedImage!=null)selectedImage.setClickable(!objectLocked);toast(objectLocked?"Object locked":"Object unlocked");}
    void deleteSelected(){if(objectLocked){toast("Unlock object first");return;}if(selectedImage!=null){paper.removeView(selectedImage);selectedImage=null;toast("Selected image deleted");}else{int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a!=b){editor.getText().delete(Math.min(a,b),Math.max(a,b));toast("Selected text deleted");}else {new AlertDialog.Builder(this).setMessage("Clear the whole text object?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->editor.setText("")).show();}}}
    void duplicateSelected(){if(selectedImage!=null){ImageView cp=new ImageView(this);cp.setImageDrawable(selectedImage.getDrawable());cp.setScaleType(ImageView.ScaleType.CENTER_CROP);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(selectedImage.getWidth()>0?selectedImage.getWidth():dp(220),selectedImage.getHeight()>0?selectedImage.getHeight():dp(160));lp.leftMargin=dp(24);lp.topMargin=dp(24);paper.addView(cp,lp);selectedImage=cp;makeDraggable(cp);toast("Image duplicated");}else{int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a!=b){String x=editor.getText().subSequence(Math.min(a,b),Math.max(a,b)).toString();editor.getText().insert(Math.max(a,b),x);toast("Selected text duplicated");}else{editor.append("\n"+editor.getText().toString());toast("Text object duplicated");}}}
    void togglePageSelection(){pageSelected=!pageSelected;if(pageSelectionOverlay==null){pageSelectionOverlay=new View(this);GradientDrawable gd=new GradientDrawable();gd.setColor((int)0x00000000L);gd.setStroke(dp(3),(int)0xFF1F5F9FL);pageSelectionOverlay.setBackground(gd);paper.addView(pageSelectionOverlay,new FrameLayout.LayoutParams(-1,-1));}pageSelectionOverlay.setVisibility(pageSelected?View.VISIBLE:View.GONE);toast(pageSelected?"Whole page selected — use BG, Border or Page Copy":"Page selection removed");}
    static class PageState{String text,title;int color,w,h;PageState(String t,String ti,int c,int ww,int hh){text=t;title=ti;color=c;w=ww;h=hh;}}
    PageState capturePage(){return new PageState(editor==null?"":editor.getText().toString(),title==null?"Untitled":title.getText().toString(),paperColor,pageW,pageH);}
    void saveCurrentPageState(){if(editor==null)return;PageState p=capturePage();if(pages.size()==0)pages.add(p);else if(currentPage<pages.size())pages.set(currentPage,p);}
    void loadPageState(int index){if(index<0||index>=pages.size())return;changing=true;PageState p=pages.get(index);currentPage=index;pageW=p.w;pageH=p.h;paperColor=p.color;editor.setText(p.text);title.setText(p.title);paper.setBackgroundColor(paperColor);choosePageSilent();changing=false;toast("Page "+(currentPage+1)+" of "+pages.size());}
    void addNewPage(){saveCurrentPageState();pages.add(new PageState("","Untitled Page "+(pages.size()+1),Color.WHITE,595,842));loadPageState(pages.size()-1);}
    void switchPageDialog(){saveCurrentPageState();String[] names=new String[pages.size()];for(int i=0;i<pages.size();i++)names[i]="Page "+(i+1)+(i==currentPage?" ✓":"");new AlertDialog.Builder(this).setTitle("Multiple Pages").setItems(names,(d,w)->loadPageState(w)).setNegativeButton("Cancel",null).setPositiveButton("+ New Page",(d,w)->addNewPage()).show();}
    void duplicatePage(){saveCurrentPageState();PageState p=pages.get(currentPage);pages.add(currentPage+1,new PageState(p.text,p.title+" Copy",p.color,p.w,p.h));loadPageState(currentPage+1);toast("Page duplicated");}
    void showPageEditDialog(){new AlertDialog.Builder(this).setTitle("Page Edit — Page "+(currentPage+1)+" / "+Math.max(1,pages.size())).setItems(new String[]{"Background Color","Background Transparency","Border / Frame","Page Size & Orientation","Multiple Pages / Switch","+ Add New Page","Duplicate Current Page","Delete Current Page"},(d,w)->{if(w==0)choosePaperColor();else if(w==1)choosePageTransparency();else if(w==2)chooseBorder();else if(w==3)choosePage();else if(w==4)switchPageDialog();else if(w==5)addNewPage();else if(w==6)duplicatePage();else deleteCurrentPage();}).show();}
    void choosePageTransparency(){final String[] a={"100% Opaque","85%","70%","55%","40%"};new AlertDialog.Builder(this).setTitle("Page Transparency").setItems(a,(d,w)->{int alpha=255-w*38;paper.setAlpha(Math.max(.4f,alpha/255f));toast(a[w]+" selected");}).show();}
    void deleteCurrentPage(){if(pages.size()<=1){toast("At least one page is required");return;}pages.remove(currentPage);if(currentPage>=pages.size())currentPage=pages.size()-1;loadPageState(currentPage);}
    void chooseBorder(){String[] a={"No Border","Gold Corner Border","Blue Corner Border","Double Frame","Islamic Green Frame"};new AlertDialog.Builder(this).setTitle("Professional Borders").setItems(a,(d,w)->applyBorder(w)).show();}
    void applyBorder(int type){View old=paper.findViewWithTag("border");if(old!=null)paper.removeView(old);if(type==0)return;BorderView bv=new BorderView(this,type);bv.setTag("border");paper.addView(bv,new FrameLayout.LayoutParams(-1,-1));toast("Border applied");}
    void makeDraggable(final View v){v.setOnTouchListener(new View.OnTouchListener(){float dx,dy;public boolean onTouch(View q,MotionEvent e){if(objectLocked)return false;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)q.getLayoutParams();if(e.getAction()==MotionEvent.ACTION_DOWN){dx=e.getRawX()-lp.leftMargin;dy=e.getRawY()-lp.topMargin;selectedImage=(q instanceof ImageView)?(ImageView)q:selectedImage;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){lp.leftMargin=Math.max(0,(int)(e.getRawX()-dx));lp.topMargin=Math.max(0,(int)(e.getRawY()-dy));q.setLayoutParams(lp);return true;}return true;}});}
    String getDisplayName(Uri uri){Cursor c=getContentResolver().query(uri,null,null,null,null);if(c!=null){try{int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0)return c.getString(i);}finally{c.close();}}return "font_"+System.currentTimeMillis()+".ttf";}
    public static class BorderView extends View{Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int type;BorderView(Context c,int t){super(c);type=t;}protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();int col=type==2?(int)0xFF1F5F9FL:type==4?(int)0xFF178B54L:(int)0xFFC59A32L;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(type==3?8:5);p.setColor(col);if(type==3){c.drawRect(18,18,w-18,h-18,p);c.drawRect(34,34,w-34,h-34,p);}else{c.drawRect(20,20,w-20,h-20,p);p.setStrokeWidth(8);int z=48;c.drawLine(20,20,z,20,p);c.drawLine(20,20,20,z,p);c.drawLine(w-20,20,w-z,20,p);c.drawLine(w-20,20,w-20,z,p);c.drawLine(20,h-20,z,h-20,p);c.drawLine(20,h-20,20,h-z,p);c.drawLine(w-20,h-20,w-z,h-20,p);c.drawLine(w-20,h-20,w-20,h-z,p);}}}

    void chooseTextColor(){chooseColor("Text Color",new int[]{(int)0xFF182638L,(int)0xFF073B73L,(int)0xFF8B1E3FL,(int)0xFF116B4DL,(int)0xFF6A3D9AL,Color.BLACK},c->{int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a!=b){editor.getText().setSpan(new ForegroundColorSpan(c),Math.min(a,b),Math.max(a,b),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);}else{ textColor=c;editor.setTextColor(c); }});}
    void choosePaperColor(){chooseColor("Page Background",new int[]{Color.WHITE,(int)0xFFFFFDF8L,(int)0xFFF7F0E2L,(int)0xFFEFF6FFL,(int)0xFFF4EFFAL,(int)0xFFF2F5F7L},c->{paperColor=c;paper.setBackgroundColor(c);});}
    interface ColorPick{void pick(int c);} void chooseColor(String title,int[] cs,ColorPick cb){String[] names={"Black","Blue","Maroon","Green","Purple","Light"};new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,w)->cb.pick(cs[w])).show();}
    void choosePage(){new AlertDialog.Builder(this).setTitle("Page Setup").setItems(new String[]{"A4 Portrait","A4 Landscape","A5 Portrait","Letter Portrait"},(d,w)->{if(w==1){pageW=842;pageH=595;}else if(w==2){pageW=420;pageH=595;}else if(w==3){pageW=612;pageH=792;}else{pageW=595;pageH=842;}choosePageSilent();saveCurrentPageState();Toast.makeText(this,"Page updated",Toast.LENGTH_SHORT).show();}).show();}
    void chooseTemplate(){String[] a={"Blank Document","Islamic Notice","Character Certificate","Simple Poster","Islamic Poster","Madrasa Certificate","Elegant Gold Page","Corner Arrow Page","Modern Blue Frame"};new AlertDialog.Builder(this).setTitle("Professional Template Library").setItems(a,(d,w)->{if(editor==null)buildEditor();String t="";paperColor=Color.WHITE;if(w==1){t="اعلان\n\nتمام طلبہ و طالبات کو مطلع کیا جاتا ہے کہ\n\n________________________________\n\nتاریخ: __________";applyBorder(4);}else if(w==2){t="کردار نامہ\n\nیہ تصدیق کی جاتی ہے کہ\n\n________________________________\n\nنے ہمارے ادارے میں اچھے اخلاق اور بہترین کردار کا مظاہرہ کیا ہے۔\n\nدستخط: __________";applyBorder(3);}else if(w==3){t="بسم اللہ الرحمن الرحیم\n\nعنوان یہاں لکھیں\n\nاپنا خوبصورت پیغام یہاں تحریر کریں";applyBorder(2);}else if(w==4){t="بسم اللہ الرحمن الرحیم\n\nاسلامی پوسٹر\n\nاپنا پیغام یہاں تحریر کریں";paperColor=(int)0xFFFFFDF8L;applyBorder(4);}else if(w==5){t="دارالتحفیظ للقرآن الکریم\n\nاعزازی سند\n\nیہ سند __________ کو دی جاتی ہے";paperColor=(int)0xFFF7F0E2L;applyBorder(1);}else if(w==6){t="بسم اللہ الرحمن الرحیم\n\nخوبصورت اردو ڈیزائن\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFFFFCF4L;applyBorder(1);}else if(w==7){t="عنوان\n\nاپنا پیغام یہاں لکھیں";applyBorder(2);}else if(w==8){t="PROFESSIONAL PAGE\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFEFF6FFL;applyBorder(2);}else applyBorder(0);paper.setBackgroundColor(paperColor);changing=true;editor.setText(t);changing=false;undoStack.clear();undoStack.add(t);toast("Template loaded");}).show();}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,105);}
    void importFont(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,101);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;try{Uri u=d.getData();if(r==101){String original=getDisplayName(u);String lower=original.toLowerCase(Locale.ROOT);if(!(lower.endsWith(".ttf")||lower.endsWith(".otf"))){toast("Please select a TTF or OTF font");return;}File out=new File(fontDir,original.replaceAll("[^a-zA-Z0-9._ -]","_") );copy(u,out);Typeface test=Typeface.createFromFile(out);loadFonts();Toast.makeText(this,"Font imported and activated: "+original,Toast.LENGTH_LONG).show();if(fontSpinner!=null){ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames);fontSpinner.setAdapter(a);int ix=fontNames.indexOf(out.getName());if(ix>=0)fontSpinner.setSelection(ix);}}else if(r==102){writeJson(u);toast("Document saved");}else if(r==103){openJson(u);}else if(r==104){createPdf(u);toast("PDF created successfully");}else if(r==105){InputStream in=getContentResolver().openInputStream(u);pageImage=BitmapFactory.decodeStream(in);if(in!=null)in.close();if(pageImage!=null&&paper!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(pageImage);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setAlpha(.35f);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(220),dp(160),Gravity.TOP|Gravity.CENTER_HORIZONTAL);ip.topMargin=dp(24);paper.addView(iv,ip);selectedImage=iv;makeDraggable(iv);iv.setOnClickListener(x->{selectedImage=iv;toast("Image selected");});toast("Image added: select, move, lock or delete");}}}catch(Exception e){toast("Operation failed: "+e.getMessage());}}
    void copy(Uri u,File out)throws Exception{InputStream in=getContentResolver().openInputStream(u);FileOutputStream fo=new FileOutputStream(out);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)fo.write(b,0,n);in.close();fo.close();}
    void showFontsDialog(){
        loadFonts();
        new AlertDialog.Builder(this).setTitle("Available Fonts")
            .setItems(fontNames.toArray(new String[0]),(d,w)->{
                if(w>=0 && w<fontNames.size()){
                    currentFontName=fontNames.get(w);
                    currentTypeface=typefaces.get(currentFontName);
                    if(currentTypeface==null) currentTypeface=Typeface.DEFAULT;
                    applyTypeface();
                    if(fontSpinner!=null) fontSpinner.setSelection(w);
                    toast("Font applied: "+currentFontName);
                }
            })
            .setPositiveButton("Import Font",(d,w)->importFont()).show();
    }
    void saveDocument(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".json");startActivityForResult(i,102);}String safeName(String s){return s.replaceAll("[^a-zA-Z0-9_\\- ]","_").trim().replaceAll(" +","_");}
    void writeJson(Uri u)throws Exception{org.json.JSONObject o=new org.json.JSONObject();o.put("title",title.getText().toString());o.put("text",editor.getText().toString());o.put("font",currentFontName);o.put("size",editor.getTextSize());o.put("pageW",pageW);o.put("pageH",pageH);o.put("textColor",textColor);o.put("paperColor",paperColor);o.put("bold",bold);o.put("italic",italic);o.put("center",center);OutputStream out=getContentResolver().openOutputStream(u);out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));out.close();}
    void openDocument(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,103);}void openJson(Uri u){try{InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[8192];int n;while((n=in.read(z))>0)b.write(z,0,n);in.close();org.json.JSONObject o=new org.json.JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));buildEditor();title.setText(o.optString("title","Untitled Urdu Document"));changing=true;editor.setText(o.optString("text",""));changing=false;editor.setTextSize((float)o.optDouble("size",30));pageW=o.optInt("pageW",595);pageH=o.optInt("pageH",842);textColor=o.optInt("textColor",textColor);paperColor=o.optInt("paperColor",paperColor);bold=o.optBoolean("bold",false);italic=o.optBoolean("italic",false);center=o.optBoolean("center",false);editor.setTextColor(textColor);paper.setBackgroundColor(paperColor);currentFontName=o.optString("font","System Urdu");loadFonts();int ix=fontNames.indexOf(currentFontName);if(ix<0)ix=0;fontSpinner.setSelection(ix);applyTypeface();applyGravity();choosePageSilent();toast("Document opened");}catch(Exception e){toast("Open failed: "+e.getMessage());}}
    void choosePageSilent(){ViewGroup.LayoutParams lp=paper.getLayoutParams();lp.width=dp(pageW);lp.height=dp(pageH);paper.setLayoutParams(lp);}
    void exportPdf(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".pdf");startActivityForResult(i,104);}void createPdf(Uri uri)throws Exception{OutputStream out=getContentResolver().openOutputStream(uri);writePdfToStream(out);out.close();}
    void writePdfToStream(OutputStream out)throws Exception{PdfDocument doc=new PdfDocument();PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(pageW,pageH,1).create();PdfDocument.Page p=doc.startPage(pi);Canvas c=p.getCanvas();c.drawColor(paperColor);int margin=36;if(pageImage!=null){Rect src=new Rect(0,0,pageImage.getWidth(),pageImage.getHeight());Rect dst=new Rect(margin,margin,pageW-margin,pageH/3);Paint ip=new Paint(Paint.ANTI_ALIAS_FLAG);ip.setAlpha(90);c.drawBitmap(pageImage,src,dst,ip);}TextPaint tp=new TextPaint(Paint.ANTI_ALIAS_FLAG);tp.setColor(textColor);float scale=getResources().getDisplayMetrics().scaledDensity;tp.setTextSize(Math.max(14,editor.getTextSize()/scale));tp.setTypeface(editor.getTypeface());int width=pageW-margin*2;Layout.Alignment al=center?Layout.Alignment.ALIGN_CENTER:Layout.Alignment.ALIGN_OPPOSITE;StaticLayout sl=new StaticLayout(editor.getText(),tp,width,al,1.2f,0,false);c.save();c.translate(margin,margin);sl.draw(c);c.restore();doc.finishPage(p);doc.writeTo(out);doc.close();}
    void printPdf(){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print(title.getText().toString(),new PrintDocumentAdapter(){public void onLayout(PrintAttributes o,PrintAttributes n,CancellationSignal cs,LayoutResultCallback cb,Bundle e){if(cs.isCanceled()){cb.onLayoutCancelled();return;}PrintDocumentInfo info=new PrintDocumentInfo.Builder(safeName(title.getText().toString())+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();cb.onLayoutFinished(info,true);}public void onWrite(PageRange[] r,ParcelFileDescriptor d,CancellationSignal cs,WriteResultCallback cb){try{writePdfToStream(new FileOutputStream(d.getFileDescriptor()));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.getMessage());}}},null);}
    void restoreDraft(){try{SharedPreferences p=getSharedPreferences("draft",0);String s=p.getString("text",null);if(s!=null){title.setText(p.getString("title",title.getText().toString()));changing=true;editor.setText(s);changing=false;undoStack.clear();undoStack.add(s);}}catch(Exception ignored){}}
    void saveDraft(){if(editor!=null){saveCurrentPageState();}if(editor!=null)getSharedPreferences("draft",0).edit().putString("title",title.getText().toString()).putString("text",editor.getText().toString()).apply();}
    void confirmHome(){saveDraft();new AlertDialog.Builder(this).setMessage("Return to home? Your current draft is auto-saved.").setNegativeButton("Cancel",null).setPositiveButton("Home",(d,w)->buildHome()).show();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(editor!=null)confirmHome();else super.onBackPressed();}
    @Override protected void onPause(){saveDraft();super.onPause();}
}

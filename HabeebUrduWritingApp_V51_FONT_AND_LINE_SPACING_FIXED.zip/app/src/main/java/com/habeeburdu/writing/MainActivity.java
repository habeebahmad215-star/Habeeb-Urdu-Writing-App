package com.habeeburdu.writing;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.*;
import android.text.*;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.MetricAffectingSpan;
import android.text.style.LineHeightSpan;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import android.graphics.drawable.ColorDrawable;

/** Advanced, dependency-free Urdu document designer. */
public class MainActivity extends Activity {
    final int BLUE=(int)0xFF123B67L, BLUE2=(int)0xFF1F5F9FL, GREEN=(int)0xFF178B54L, PURPLE=(int)0xFF7046A5L, RED=(int)0xFFB43A34L, BG=(int)0xFFF3F6FAL;
    // V26: Every new document/text box starts at an exact 12sp base size.
    static final float DEFAULT_FONT_SIZE_SP=12f;
    // V35: Urdu words use a slightly tighter default gap for a natural Nastaliq-style look.
    static final float DEFAULT_URDU_WORD_SPACING_DP=-1.5f;
    // V50: one neutral view-level baseline. All manual paragraph spacing is handled
    // by a real paragraph span, so default and manual spacing never fight each other.
    static final float DEFAULT_LINE_SPACING_MULTIPLIER=1.0f;
    static final float DEFAULT_LINE_SPACING_EXTRA_DP=0.0f;
    // One shared document safe area: text, images and borders all respect this.
    static final float CONTENT_SAFE_DP=46f; static final float MIN_SAFE_DP=14f; static final float CONTENT_GAP_DP=8f;
    float borderSafeDp=CONTENT_SAFE_DP; View selectionOverlay;
    LinearLayout root, editorRoot, tools; EditText title; SelectionEditText editor; FrameLayout paper, stage; ScrollView verticalScroll; HorizontalScrollView horizontalScroll;
    Spinner fontSpinner, languageSpinner; SeekBar zoomBar, sizeBar;
    View pageSelectionOverlay; ImageView selectedImage; LinearLayout contextBar; boolean textToolsMode=false; boolean objectLocked=false, pageSelected=false; TextView zoomLabel, sizeLabel; ScaleGestureDetector textScaleDetector; ArrayList<PageState> pages=new ArrayList<>(); int currentPage=0;
    String currentFontName="System Urdu"; Typeface currentTypeface=Typeface.DEFAULT;
    final ArrayList<SelectionEditText> textObjects=new ArrayList<>(); final ArrayList<View> designObjects=new ArrayList<>(); final IdentityHashMap<View,String> designObjectNames=new IdentityHashMap<>(); final IdentityHashMap<View,Boolean> objectLocks=new IdentityHashMap<>(); final IdentityHashMap<View,Boolean> objectVisibility=new IdentityHashMap<>(); final IdentityHashMap<View,String> imageSources=new IdentityHashMap<>(); View selectedDesignObject; SelectionEditText primaryEditor; SelectionEditText selectedTextObject; boolean objectSelectionMode=false;
    int pageW=595,pageH=842,textColor=(int)0xFF182638L,paperColor=Color.WHITE; boolean bold=false,italic=false,center=false,landscape=false;
    File fontDir; ArrayList<String> fontNames=new ArrayList<>(); HashMap<String,Typeface> typefaces=new HashMap<>();
    // Per-text-object base font. This is the source of truth for future typing and page restore.
    HashMap<SelectionEditText,String> textObjectFontNames=new HashMap<>();
    Bitmap pageImage; final ArrayList<String> undoStack=new ArrayList<>(), redoStack=new ArrayList<>(); boolean changing=false, autoPaginating=false;
    // Keeps a word/phrase selected when Android's Back key closes the keyboard.
    int preservedSelectionStart=-1, preservedSelectionEnd=-1; boolean preserveSelectionAfterImeBack=false;
    // V37: keep the exact formatting range even when a Spinner/Dialog steals focus.
    int formatSelectionStart=-1, formatSelectionEnd=-1; boolean suppressFontSpinnerCallback=false;
    // V51: prevents an old highlighted range from being reused after the user has
    // genuinely finished formatting and tapped elsewhere.
    boolean formattingRangePinned=false;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    int sp(float v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,v,getResources().getDisplayMetrics());}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor((int)0xFF1D2A3AL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);return b;}

    /** EditText with reliable long-press word selection and selection change reporting. */
    static class SelectionEditText extends android.widget.EditText {
        interface SelectionListener { void onSelectionChanged(int start,int end); }
        interface KeyboardBackListener { void onKeyboardBack(SelectionEditText view); }
        SelectionListener listener; KeyboardBackListener keyboardBackListener;
        float lastTouchX,lastTouchY;
        SelectionEditText(Context c){ super(c); }
        void setSelectionListener(SelectionListener l){ listener=l; }
        void setKeyboardBackListener(KeyboardBackListener l){ keyboardBackListener=l; }
        @Override public boolean onKeyPreIme(int keyCode, KeyEvent event){
            if(keyCode==KeyEvent.KEYCODE_BACK && event.getAction()==KeyEvent.ACTION_UP &&
                    getSelectionStart()!=getSelectionEnd() && keyboardBackListener!=null){
                keyboardBackListener.onKeyboardBack(this);
            }
            return super.onKeyPreIme(keyCode,event);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                lastTouchX=e.getX(); lastTouchY=e.getY();
            }
            return super.onTouchEvent(e);
        }
        @Override public boolean performLongClick(){
            // Use Android's native selection system: highlight + drag handles.
            boolean handled=super.performLongClick();
            // Some Android builds keep the cursor collapsed after long-press.
            // Force word selection in that case so the text is visibly highlighted.
            post(()->{
                if(getSelectionStart()==getSelectionEnd()) selectWordAtLastTouch();
                if(listener!=null)listener.onSelectionChanged(getSelectionStart(),getSelectionEnd());
            });
            return handled;
        }
        void selectWordAtLastTouch(){
            try{
                int off=getOffsetForPosition(lastTouchX,lastTouchY);
                CharSequence cs=getText(); int n=cs.length();
                if(n==0)return; off=Math.max(0,Math.min(off,n-1));
                if(isBreak(cs.charAt(off)) && off>0) off--;
                int a=off,b=Math.min(n,off+1);
                while(a>0 && !isBreak(cs.charAt(a-1)))a--;
                while(b<n && !isBreak(cs.charAt(b)))b++;
                if(a<b) setSelection(a,b);
            }catch(Exception ignored){}
        }
        @Override public boolean onTextContextMenuItem(int id){
            boolean r=super.onTextContextMenuItem(id);
            post(()->{ if(listener!=null) listener.onSelectionChanged(getSelectionStart(),getSelectionEnd()); });
            return r;
        }
        boolean isBreak(char c){ return Character.isWhitespace(c) || ",.;:!?()[]{}\"'،۔؛:!?\n\r\t".indexOf(c)>=0; }
        @Override protected void onSelectionChanged(int selStart,int selEnd){
            super.onSelectionChanged(selStart,selEnd);
            if(listener!=null) listener.onSelectionChanged(selStart,selEnd);
        }
    }
    /** Exact word spacing for selected text. Value is stored in screen pixels. */
    static class WordSpacingSpan extends MetricAffectingSpan {
        final float extraPx;
        WordSpacingSpan(float px){extraPx=px;}
        @Override public void updateDrawState(TextPaint p){ if(Build.VERSION.SDK_INT>=21)p.setWordSpacing(extraPx); }
        @Override public void updateMeasureState(TextPaint p){ if(Build.VERSION.SDK_INT>=21)p.setWordSpacing(extraPx); }
    }
    /**
     * Real paragraph line-height controller. The previous implementation used
     * Math.max(h, h*multiplier), which made every value below 1.0 a no-op. It also
     * fought the EditText's global setLineSpacing multiplier. This span changes the
     * complete font-metric box symmetrically, so compact and expanded values both
     * take effect immediately and predictably.
     */
    static class RelativeLineSpacingSpan implements LineHeightSpan.WithDensity {
        final float multiplier;
        RelativeLineSpacingSpan(float m){ multiplier=Math.max(0.70f,Math.min(3.00f,m)); }
        @Override public void chooseHeight(CharSequence text,int start,int end,int spanstartv,int v,Paint.FontMetricsInt fm){
            int oldHeight=Math.max(1,fm.descent-fm.ascent);
            int target=Math.max(1,Math.round(oldHeight*multiplier));
            int delta=target-oldHeight;
            // Keep the baseline visually stable by distributing the change around it.
            int up=(int)Math.floor(delta/2f);
            int down=delta-up;
            int topOffset=fm.top-fm.ascent;
            int bottomOffset=fm.bottom-fm.descent;
            fm.ascent-=up;
            fm.descent+=down;
            fm.top=fm.ascent+topOffset;
            fm.bottom=fm.descent+bottomOffset;
        }
        @Override public void chooseHeight(CharSequence text,int start,int end,int spanstartv,int v,Paint.FontMetricsInt fm,TextPaint paint){
            chooseHeight(text,start,end,spanstartv,v,fm);
        }
    }
    /** V36: font span for a selected range only. */
    static class LocalTypefaceSpan extends MetricAffectingSpan {
        final Typeface typeface; final String fontName;
        LocalTypefaceSpan(Typeface t,String n){typeface=t==null?Typeface.DEFAULT:t;fontName=n==null?"System Urdu":n;}
        private void apply(Paint p){p.setTypeface(typeface);}
        @Override public void updateDrawState(android.text.TextPaint p){apply(p);}
        @Override public void updateMeasureState(android.text.TextPaint p){apply(p);}
    }

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BLUE);getWindow().setNavigationBarColor(BLUE); if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(true); getWindow().getDecorView().setSystemUiVisibility(0);} fontDir=new File(getFilesDir(),"fonts");fontDir.mkdirs();loadFonts();buildHome();}
    void installInsets(View v){v.setOnApplyWindowInsetsListener((view,insets)->{
        if(Build.VERSION.SDK_INT>=30){
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
            android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());
            // Include the IME inset so the bottom Text Tools bar moves ABOVE the keyboard.
            view.setPadding(0,bars.top,0,Math.max(bars.bottom,ime.bottom));
        }
        return insets;
    });}
    void loadFonts(){fontNames.clear();typefaces.clear();fontNames.add("System Urdu");typefaces.put("System Urdu",Typeface.DEFAULT);File[] fs=fontDir.listFiles();if(fs!=null)for(File f:fs){try{Typeface t=Typeface.createFromFile(f);fontNames.add(f.getName());typefaces.put(f.getName(),t);}catch(Exception ignored){}}}

    /** V33 polished home: compact hierarchy, responsive text and consistent premium cards. */
    void buildHome(){
        editor=null; paper=null; selectedImage=null; selectedDesignObject=null; selectedTextObject=null; objectSelectionMode=false; designObjects.clear(); designObjectNames.clear();
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);installInsets(root);setContentView(root);

        // Compact branded header: no clipped subtitle and no wasted vertical space.
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(16),dp(10),dp(16),dp(10));header.setBackgroundColor(BLUE);
        ImageView logo=new ImageView(this);logo.setImageResource(getResources().getIdentifier("habeeb_logo","drawable",getPackageName()));logo.setScaleType(ImageView.ScaleType.CENTER_CROP);logo.setBackground(bg((int)0xFF0B2038L,16));logo.setPadding(dp(3),dp(3),dp(3),dp(3));header.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setGravity(Gravity.CENTER_VERTICAL);names.setPadding(dp(12),0,dp(6),0);
        TextView h=text("Habeeb Urdu",22);h.setTextColor(Color.WHITE);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setSingleLine(true);names.addView(h,new LinearLayout.LayoutParams(-1,dp(31)));
        TextView loc=text("Writing • Calligraphy • Design",10);loc.setTextColor((int)0xFFD5E4F4L);loc.setSingleLine(true);loc.setEllipsize(TextUtils.TruncateAt.END);names.addView(loc,new LinearLayout.LayoutParams(-1,dp(20)));
        header.addView(names,new LinearLayout.LayoutParams(0,dp(58),1));
        Button lang=button("اردو  🌐");lang.setTextColor(Color.WHITE);lang.setTextSize(10);lang.setAllCaps(false);lang.setBackground(bg(BLUE2,18));lang.setOnClickListener(v->showHomeLanguage());header.addView(lang,new LinearLayout.LayoutParams(dp(94),dp(44)));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(78)));

        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setClipToPadding(false);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(12),dp(16),dp(22));

        // Compact hero with wrapping text: no overflow on small screens.
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(16),dp(12),dp(16),dp(12));hero.setBackground(cardBg((int)0xFFF9FBFEL,(int)0xFFD9E3EEL,18));
        TextView welcome=text("اردو تحریر اور خوبصورت ڈیزائن — ایک ہی جگہ",16);welcome.setGravity(Gravity.CENTER);welcome.setTextColor((int)0xFF25384DL);welcome.setTypeface(Typeface.DEFAULT,Typeface.BOLD);welcome.setMaxLines(2);hero.addView(welcome,new LinearLayout.LayoutParams(-1,-2));
        TextView welcomeSub=text("Professional writing, templates, PDF export and printing",10);welcomeSub.setGravity(Gravity.CENTER);welcomeSub.setTextColor((int)0xFF708092L);welcomeSub.setMaxLines(2);welcomeSub.setPadding(0,dp(5),0,0);hero.addView(welcomeSub,new LinearLayout.LayoutParams(-1,-2));body.addView(hero,new LinearLayout.LayoutParams(-1,-2));

        section(body,"Quick Start","Start or continue");
        addPremiumGrid(body,new String[][]{
            {"✚","New Document","Start writing"},{"📂","Open File","Open saved file"},{"↻","Continue","Restore last draft"},{"PDF","Export PDF","High-quality output"}
        },new int[]{BLUE2,(int)0xFFF08A24L,PURPLE,(int)0xFFB63A4BL},new View.OnClickListener[]{
            v->buildEditor(),v->openDocument(),v->{buildEditor();restoreDraft();toast("Last draft restored");},v->{buildEditor();exportPdf();}
        });

        section(body,"Design Studio","Create beautiful designs");
        addPremiumGrid(body,new String[][]{
            {"✦","Templates","Ready-made designs"},{"☪","Islamic Poster","Urdu poster design"},{"▣","Certificate","Professional certificate"},{"✎","Graphics","Drawing and objects"}
        },new int[]{PURPLE,GREEN,(int)0xFFD69A21L,(int)0xFF198F9BL},new View.OnClickListener[]{
            v->chooseTemplate(),v->{buildEditor();chooseTemplateIndex(4);},v->{buildEditor();chooseTemplateIndex(5);},v->{buildEditor();showMoreTools();}
        });

        section(body,"Design Library","Assets for your page");
        addLibraryGrid(body,new String[][]{
            {"▧","Templates","Editable"},{"☪","Posters","Islamic designs"},{"▣","Certificates","Ready-made"},{"◇","Shapes","Quick add"},
            {"⌜","Corners","Page decor"},{"✦","Elements","Design items"},{"▤","Borders","Professional"},{"PNG","Images","PNG / photo"}
        },new int[]{PURPLE,GREEN,(int)0xFFD69A21L,(int)0xFF198F9BL,(int)0xFF9A5BB8L,(int)0xFFE06C75L,BLUE2,(int)0xFF4E8C8CL},new View.OnClickListener[]{
            v->chooseTemplate(),v->{buildEditor();chooseTemplateIndex(4);},v->{buildEditor();chooseTemplateIndex(5);},v->{buildEditor();showShapeLibrary();},
            v->{buildEditor();showCornerLibrary();},v->{buildEditor();showElementLibrary();},v->{buildEditor();chooseBorder();},v->{buildEditor();pickImage();}
        });

        section(body,"Tools & Publishing","Simple and powerful");
        addPremiumGrid(body,new String[][]{
            {"Aa","Fonts","TTF / OTF fonts"},{"▣","Print","Print document"},{"•••","All Tools","Advanced options"},{"?","Help","How to use the app"}
        },new int[]{(int)0xFF526FE5L,(int)0xFF1A9C70L,(int)0xFF7A56A8L,(int)0xFF64748BL},new View.OnClickListener[]{
            v->showFontsDialog(),v->{buildEditor();printPdf();},v->{buildEditor();showMoreTools();},v->showHomeHelp()
        });

        section(body,"Recent Projects","Continue where you left off");
        addRecentProjects(body);
        TextView tip=text("Professional • Easy • Powerful",11);tip.setGravity(Gravity.CENTER);tip.setPadding(dp(10),dp(14),dp(10),dp(2));tip.setTextColor((int)0xFF64748BL);tip.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(tip,new LinearLayout.LayoutParams(-1,dp(34)));
        sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        addHomeBottomNav(root);
    }

    void addRecentProjects(LinearLayout body){
        SharedPreferences prefs=getSharedPreferences("draft",0);String draftTitle=prefs.getString("title","");String draftText=prefs.getString("text","");
        String name=(draftTitle==null||draftTitle.trim().isEmpty())?"Untitled Document":draftTitle.trim();
        if(draftText==null||draftText.trim().isEmpty()) name="Start your first project";
        addRecentProjectCard(body,"↻",name,draftText==null||draftText.trim().isEmpty()?"Create a new document to begin":"Auto-saved draft • Tap to continue",v->{buildEditor();restoreDraft();});
        if(draftText!=null&&!draftText.trim().isEmpty()) addRecentProjectCard(body,"PDF","Export your document","Open the editor, then export a high-quality PDF",v->{buildEditor();});
    }
    void addRecentProjectCard(LinearLayout body,String icon,String title,String sub,View.OnClickListener l){
        LinearLayout recent=new LinearLayout(this);recent.setGravity(Gravity.CENTER_VERTICAL);recent.setPadding(dp(14),dp(10),dp(10),dp(10));recent.setBackground(cardBg(Color.WHITE,(int)0xFFD7DFE8L,18));recent.setElevation(dp(1));recent.setOnClickListener(l);
        TextView ri=text(icon,19);ri.setTextColor(PURPLE);ri.setGravity(Gravity.CENTER);ri.setTypeface(Typeface.DEFAULT,Typeface.BOLD);ri.setBackground(bg((int)0xFFF2EAFE,15));recent.addView(ri,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout rd=new LinearLayout(this);rd.setOrientation(LinearLayout.VERTICAL);rd.setGravity(Gravity.CENTER_VERTICAL);rd.setPadding(dp(11),0,dp(8),0);
        TextView rt=text(title,13);rt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);rt.setMaxLines(2);rt.setEllipsize(TextUtils.TruncateAt.END);rd.addView(rt,new LinearLayout.LayoutParams(-1,-2));
        TextView rs=text(sub,9);rs.setMaxLines(2);rs.setTextColor((int)0xFF6B7785L);rs.setPadding(0,dp(3),0,0);rd.addView(rs,new LinearLayout.LayoutParams(-1,-2));recent.addView(rd,new LinearLayout.LayoutParams(0,-2,1));
        TextView open=text("Open ›",10);open.setTextColor(Color.WHITE);open.setGravity(Gravity.CENTER);open.setBackground(bg(PURPLE,14));recent.addView(open,new LinearLayout.LayoutParams(dp(62),dp(40)));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.setMargins(0,0,0,dp(8));body.addView(recent,rlp);
    }
    void addHomeBottomNav(LinearLayout parent){
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(10),dp(5),dp(10),dp(5));nav.setBackgroundColor((int)0xFF183A5FL);
        addNavItem(nav,"⌂","Home",v->buildHome(),true);addNavItem(nav,"✚","Create",v->buildEditor(),false);addNavItem(nav,"✦","Templates",v->chooseTemplate(),false);addNavItem(nav,"▧","Projects",v->{toast("Recent projects are shown above");},false);addNavItem(nav,"•••","More",v->showMoreTools(),false);
        parent.addView(nav,new LinearLayout.LayoutParams(-1,dp(58)));
    }
    void addNavItem(LinearLayout nav,String icon,String label,View.OnClickListener l,boolean active){
        LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setOnClickListener(l);
        TextView a=text(icon,17);a.setGravity(Gravity.CENTER);a.setTextColor(active?(int)0xFF70C5FFL:(int)0xFFD8E4F0L);item.addView(a,new LinearLayout.LayoutParams(-1,dp(25)));
        TextView b=text(label,8);b.setGravity(Gravity.CENTER);b.setTextColor(active?Color.WHITE:(int)0xFFD8E4F0L);item.addView(b,new LinearLayout.LayoutParams(-1,dp(20)));nav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }
    void addPremiumGrid(LinearLayout body,String[][] labels,int[] colors,View.OnClickListener[] listeners){
        for(int i=0;i<labels.length;i+=2){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);for(int j=0;j<2&&i+j<labels.length;j++){final int k=i+j;premiumHomeTile(row,labels[k][0],labels[k][1],labels[k][2],colors[k],listeners[k]);}body.addView(row,new LinearLayout.LayoutParams(-1,dp(106)));}
    }
    // V31 designer library: lightweight editable assets that are inserted directly on the current page.
    void showShapeLibrary(){
        String[] a={"Rectangle","Rounded Card","Circle","Pill","Banner"};
        new AlertDialog.Builder(this).setTitle("Shape Library").setItems(a,(d,w)->addDesignerShape(w)).show();
    }
    void addDesignerShape(int type){
        if(paper==null)buildEditor();
        View v=new View(this); GradientDrawable g=new GradientDrawable();
        int[] cs={(int)0xFF1F5F9F,(int)0xFF7046A5,(int)0xFF178B54,(int)0xFFB43A34,(int)0xFFD69A21}; g.setColor(cs[Math.min(type,cs.length-1)]); g.setAlpha(210);
        if(type==2)g.setShape(GradientDrawable.OVAL); else g.setCornerRadius(dp(type==3?40:type==1?20:6));
        v.setBackground(g); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(type==4?dp(250):dp(170),type==2?dp(170):dp(90)); lp.leftMargin=dp(40);lp.topMargin=dp(120);paper.addView(v,lp);registerDesignObject(v,"Shape");toast("Shape added — tap to select, then edit/duplicate/delete");
    }
    void showCornerLibrary(){String[] a={"Gold Corners","Blue Corners","Double Frame","Islamic Green Frame"};new AlertDialog.Builder(this).setTitle("Corner & Frame Library").setItems(a,(d,w)->applyBorder(w+1)).show();}
    void showElementLibrary(){
        String[] a={"✦ Star","☪ Moon","❀ Floral","◆ Diamond","✒ Pen","بسم اللہ"};
        new AlertDialog.Builder(this).setTitle("Design Elements").setItems(a,(d,w)->addDesignerElement(a[w])).show();
    }
    void addDesignerElement(String label){
        if(paper==null)buildEditor(); TextView v=text(label,26);v.setTextColor(BLUE2);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(6),dp(8),dp(6));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(180),dp(70));lp.leftMargin=dp(50);lp.topMargin=dp(180);paper.addView(v,lp);registerDesignObject(v,"Element: "+label);toast("Element added — tap to select, then edit/duplicate/delete");
    }
    void premiumHomeTile(LinearLayout p,String icon,String title,String sub,int accent,View.OnClickListener l){
        LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(12),dp(10),dp(10),dp(10));c.setBackground(cardBg(Color.WHITE,(int)0xFFE1E7EEL,18));c.setElevation(dp(1));c.setOnClickListener(l);
        TextView i=text(icon,20);i.setGravity(Gravity.CENTER);i.setTextColor(Color.WHITE);i.setTypeface(Typeface.DEFAULT,Typeface.BOLD);i.setBackground(bg(accent,16));c.addView(i,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setGravity(Gravity.CENTER_VERTICAL);tx.setPadding(dp(10),0,dp(1),0);
        TextView a=text(title,13);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setMaxLines(2);a.setEllipsize(TextUtils.TruncateAt.END);tx.addView(a,new LinearLayout.LayoutParams(-1,-2));
        TextView b=text(sub,9);b.setMaxLines(2);b.setTextColor((int)0xFF778391L);b.setPadding(0,dp(3),0,0);tx.addView(b,new LinearLayout.LayoutParams(-1,-2));c.addView(tx,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(4),dp(4),dp(4),dp(4));p.addView(c,lp);
    }
    GradientDrawable cardBg(int fill,int stroke,float radius){GradientDrawable g=bg(fill,radius);g.setStroke(dp(1),stroke);return g;}
    void section(LinearLayout body,String title,String sub){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(2),dp(14),dp(2),dp(5));TextView a=text(title,19);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setSingleLine(true);r.addView(a,new LinearLayout.LayoutParams(0,dp(34),1));TextView b=text(sub,9);b.setTextColor((int)0xFF6B7785L);b.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);b.setSingleLine(true);b.setEllipsize(TextUtils.TruncateAt.END);r.addView(b,new LinearLayout.LayoutParams(dp(142),dp(34)));body.addView(r);}
    void addLibraryGrid(LinearLayout body,String[][] labels,int[] colors,View.OnClickListener[] listeners){for(int i=0;i<labels.length;i+=2){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);for(int j=0;j<2&&i+j<labels.length;j++){final int k=i+j;libraryTile(row,labels[k][0],labels[k][1],labels[k][2],colors[k],listeners[k]);}body.addView(row,new LinearLayout.LayoutParams(-1,dp(92)));}}
    void libraryTile(LinearLayout p,String icon,String title,String sub,int accent,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(11),dp(8),dp(8),dp(8));c.setBackground(cardBg(Color.WHITE,(int)0xFFE1E7EEL,16));c.setElevation(dp(1));c.setOnClickListener(l);TextView i=text(icon,17);i.setGravity(Gravity.CENTER);i.setTextColor(Color.WHITE);i.setTypeface(Typeface.DEFAULT,Typeface.BOLD);i.setBackground(bg(accent,14));c.addView(i,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setGravity(Gravity.CENTER_VERTICAL);tx.setPadding(dp(9),0,dp(1),0);TextView a=text(title,12);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setMaxLines(2);tx.addView(a,new LinearLayout.LayoutParams(-1,-2));TextView b=text(sub,8);b.setMaxLines(2);b.setTextColor((int)0xFF778391L);b.setPadding(0,dp(3),0,0);tx.addView(b,new LinearLayout.LayoutParams(-1,-2));c.addView(tx,new LinearLayout.LayoutParams(0,-1,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.setMargins(dp(4),dp(4),dp(4),dp(4));p.addView(c,lp);}
    void showHomeHelp(){new AlertDialog.Builder(this).setTitle("How to use Habeeb Urdu").setMessage("1. New Document سے نیا صفحہ کھولیں۔\n\n2. لکھنے کے لیے text پر tap کریں۔\n\n3. کسی لفظ کو long press کریں تو وہ highlight ہوگا اور Text Tools کھل جائیں گے۔\n\n4. Keyboard بند کرنے کے لیے Back دبائیں؛ selection برقرار رہے گی۔\n\n5. Save، PDF اور Print اوپر موجود ہیں۔\n\n6. More Tools میں background، border، image اور page options ملیں گے.").setPositiveButton("Got it",null).show();}
    void showHomeLanguage(){String[] a={"اردو — Urdu RTL","English — LTR","العربية — Arabic RTL","हिन्दी — Hindi","বাংলা — Bengali","ਪੰਜਾਬੀ — Punjabi","Roman Urdu — LTR"};new AlertDialog.Builder(this).setTitle("Select Language").setItems(a,(d,w)->toast(a[w]+" selected")).show();}

    void chooseTemplateIndex(int w){String[] a={"Blank Document","Islamic Notice","Character Certificate","Simple Poster","Islamic Poster","Madrasa Certificate","Elegant Gold Page","Corner Arrow Page","Modern Blue Frame"};if(w<0||w>=a.length){chooseTemplate();return;}String t="";paperColor=Color.WHITE;if(w==1){t="اعلان\n\nتمام طلبہ و طالبات کو مطلع کیا جاتا ہے کہ\n\n________________________________\n\nتاریخ: __________";applyBorder(4);}else if(w==2){t="کردار نامہ\n\nیہ تصدیق کی جاتی ہے کہ\n\n________________________________\n\nنے ہمارے ادارے میں اچھے اخلاق اور بہترین کردار کا مظاہرہ کیا ہے۔\n\nدستخط: __________";applyBorder(3);}else if(w==3){t="بسم اللہ الرحمن الرحیم\n\nعنوان یہاں لکھیں\n\nاپنا خوبصورت پیغام یہاں تحریر کریں";applyBorder(2);}else if(w==4){t="بسم اللہ الرحمن الرحیم\n\nاسلامی پوسٹر\n\nاپنا پیغام یہاں تحریر کریں";paperColor=(int)0xFFFFFDF8L;applyBorder(4);}else if(w==5){t="دارالتحفیظ للقرآن الکریم\n\nاعزازی سند\n\nیہ سند __________ کو دی جاتی ہے";paperColor=(int)0xFFF7F0E2L;applyBorder(1);}else if(w==6){t="بسم اللہ الرحمن الرحیم\n\nخوبصورت اردو ڈیزائن\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFFFFCF4L;applyBorder(1);}else if(w==7){t="عنوان\n\nاپنا پیغام یہاں لکھیں";applyBorder(2);}else if(w==8){t="PROFESSIONAL PAGE\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFEFF6FFL;applyBorder(2);}else applyBorder(0);paper.setBackgroundColor(paperColor);changing=true;editor.setText(t);changing=false;undoStack.clear();undoStack.add(t);toast(a[w]+" loaded");}
    void showMoreTools(){new AlertDialog.Builder(this).setTitle("Advanced Design Tools").setItems(new String[]{"Text Editor","Font Import","Templates","Background","Borders","Add Image","Object Tools","Page Setup"},(d,w)->{if(w==0){}else if(w==1)importFont();else if(w==2)chooseTemplate();else if(w==3)choosePaperColor();else if(w==4)chooseBorder();else if(w==5)pickImage();else if(w==6)selectObject();else choosePage();}).show();}

    void buildEditor(){
        pages.clear(); textObjects.clear(); textObjectFontNames.clear(); designObjects.clear(); designObjectNames.clear(); objectLocks.clear(); borderSafeDp=CONTENT_SAFE_DP; selectedDesignObject=null; selectedTextObject=null; objectSelectionMode=false; primaryEditor=null; currentPage=0; pageSelected=false; pageSelectionOverlay=null; textToolsMode=false; preserveSelectionAfterImeBack=false; preservedSelectionStart=-1; preservedSelectionEnd=-1; formatSelectionStart=-1; formatSelectionEnd=-1; selectedDesignObject=null; selectedImage=null; suppressFontSpinnerCallback=false;
        editorRoot=new LinearLayout(this); editorRoot.setOrientation(LinearLayout.VERTICAL); editorRoot.setBackgroundColor(BG); installInsets(editorRoot); setContentView(editorRoot); root=editorRoot;
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        // Responsive two-row header: the document title never gets squeezed by action buttons.
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL); top.setBackgroundColor(BLUE);
        LinearLayout titleRow=new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL); titleRow.setPadding(dp(5),0,dp(6),0);
        Button back=button("‹"); back.setTextSize(30); back.setTextColor(Color.WHITE); back.setOnClickListener(v->confirmHome()); titleRow.addView(back,new LinearLayout.LayoutParams(dp(48),dp(52)));
        title=new EditText(this); title.setSingleLine(); title.setText("Untitled Urdu Document"); title.setTextColor(Color.WHITE); title.setTextSize(17); title.setBackgroundColor(Color.TRANSPARENT); title.setEllipsize(TextUtils.TruncateAt.END); titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));
        top.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER); actions.setPadding(dp(6),0,dp(6),dp(5));
        addTop(actions,"Save",v->saveDocument()); addTop(actions,"Preview",v->showPdfPreview()); addTop(actions,"PDF",v->exportPdf()); addTop(actions,"Print",v->printPdf());
        top.addView(actions,new LinearLayout.LayoutParams(-1,dp(47))); editorRoot.addView(top);

        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); tools=new LinearLayout(this); tools.setPadding(dp(6),dp(5),dp(6),dp(5)); tools.setGravity(Gravity.CENTER_VERTICAL); tools.setBackgroundColor(Color.WHITE);
        languageSpinner=new Spinner(this); String[] langs={"🌐 Language / زبان","اردو — Urdu RTL","English — LTR","العربية — Arabic RTL","हिन्दी — Hindi","বাংলা — Bengali","ਪੰਜਾਬੀ — Punjabi","ગુજરાતી — Gujarati","मराठी — Marathi","தமிழ் — Tamil","తెలుగు — Telugu","Roman Urdu — LTR"};
        languageSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,langs)); languageSpinner.setSelection(1); languageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(pos>0)applyLanguage(pos);}}); tools.addView(languageSpinner,new LinearLayout.LayoutParams(dp(150),dp(48)));
        fontSpinner=new Spinner(this); ArrayAdapter<String> fa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames); fontSpinner.setAdapter(fa);
        // Capture selection BEFORE the spinner takes focus and Android collapses it.
        fontSpinner.setOnTouchListener((v,event)->{if(event.getAction()==android.view.MotionEvent.ACTION_DOWN)rememberFormattingSelection();return false;});
        fontSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(suppressFontSpinnerCallback)return;if(editor!=null && pos>=0 && pos<fontNames.size()){currentFontName=fontNames.get(pos); currentTypeface=typefaces.get(currentFontName); applyTypeface();}}}); tools.addView(fontSpinner,new LinearLayout.LayoutParams(dp(155),dp(48)));
        addTool("Edit",v->{editor.requestFocus(); showKeyboardReliable(); updateContextMode();}); addTool("+ Text",v->addTextObject()); addTool("Objects",v->showAllObjectsDialog()); addTool("Undo",v->undo()); addTool("Redo",v->redo()); addTool("Image",v->pickImage()); addTool("More",v->showMoreTools());
        hsv.addView(tools); editorRoot.addView(hsv,new LinearLayout.LayoutParams(-1,dp(58)));

        verticalScroll=new ScrollView(this); verticalScroll.setFillViewport(true); verticalScroll.setClipToPadding(false); horizontalScroll=new HorizontalScrollView(this); horizontalScroll.setFillViewport(true);
        stage=new FrameLayout(this); stage.setBackgroundColor((int)0xFFE7EBF0L); stage.setMinimumWidth(dp(pageW)+dp(44)); stage.setPadding(dp(22),dp(20),dp(22),dp(40)); stage.setOnClickListener(v->{clearFormattingSelection();activatePageMode();});
        paper=new FrameLayout(this); paper.setBackground(bg(paperColor,2)); paper.setElevation(dp(5)); paper.setClickable(true); paper.setOnClickListener(v->{clearFormattingSelection();activatePageMode();});
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(595),dp(842),Gravity.TOP|Gravity.CENTER_HORIZONTAL); stage.addView(paper,pp);

        editor=createTextObject("",0,0,true);
        editor.setTextSize(TypedValue.COMPLEX_UNIT_SP,DEFAULT_FONT_SIZE_SP);
        primaryEditor=editor;
        applyTypeface(); setupUndo(); pages.add(capturePage()); // New documents always start with exactly ONE page; more pages are created only by overflow or the user.
        horizontalScroll.addView(stage,new HorizontalScrollView.LayoutParams(Math.max(-1,dp(pageW)+dp(44)),-1)); verticalScroll.addView(horizontalScroll,new ScrollView.LayoutParams(-1,-1)); editorRoot.addView(verticalScroll,new LinearLayout.LayoutParams(-1,0,1));

        contextBar=new LinearLayout(this); contextBar.setOrientation(LinearLayout.VERTICAL); contextBar.setPadding(dp(8),dp(5),dp(8),dp(6)); contextBar.setBackgroundColor(Color.WHITE); contextBar.setElevation(dp(10)); editorRoot.addView(contextBar,new LinearLayout.LayoutParams(-1,dp(132)));
        showPageTools();
    }

    /** Creates an independent text object. The active object becomes the editor target. */
    SelectionEditText createTextObject(String initial,int left,int top,boolean fillPage){
        SelectionEditText e=new SelectionEditText(this);
        e.setText(initial); e.setTextSize(TypedValue.COMPLEX_UNIT_SP,DEFAULT_FONT_SIZE_SP); e.setTextColor(textColor);
        Typeface baseTf=currentTypeface==null?Typeface.DEFAULT:currentTypeface;
        e.setTypeface(baseTf); textObjectFontNames.put(e,currentFontName==null?"System Urdu":currentFontName);
        // Keep Urdu words naturally close by default; this changes only the gap created by spaces, not Urdu letter shaping.
        if(Build.VERSION.SDK_INT>=21) e.getPaint().setWordSpacing(DEFAULT_URDU_WORD_SPACING_DP*getResources().getDisplayMetrics().density);
        e.setGravity(Gravity.TOP|Gravity.RIGHT); e.setTextDirection(View.TEXT_DIRECTION_RTL);
        // V51 stable visual baseline. Font padding prevents different Urdu fonts from
        // looking vertically clipped or irregular when no custom line spacing is used.
        e.setIncludeFontPadding(true);
        e.setLineSpacing(dp(DEFAULT_LINE_SPACING_EXTRA_DP), DEFAULT_LINE_SPACING_MULTIPLIER);
        e.setPadding(0,0,0,0); e.setBackgroundColor(Color.TRANSPARENT); e.setHorizontallyScrolling(false); e.setVerticalScrollBarEnabled(true); e.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setHint("اردو میں لکھنا شروع کریں…"); e.setHintTextColor((int)0xFF9AA5B1L);
        e.setFocusableInTouchMode(true); e.setLongClickable(true); e.setSelectAllOnFocus(false);
        // Keep the view's base size stable. Android spans may style selected text,
        // but SPACE and ENTER must never rescale the whole editor automatically.
        e.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(Editable s){
                float current=pxToSp(e.getTextSize());
                if(current<12f || current>72f){
                    e.setTextSize(TypedValue.COMPLEX_UNIT_SP,DEFAULT_FONT_SIZE_SP);
                }
            }
        });
        e.setSelectionListener((a,b)->{ if(editor==e){
            if(a>=0 && b>=0 && a!=b){formatSelectionStart=Math.min(a,b);formatSelectionEnd=Math.max(a,b);formattingRangePinned=true;}
            else if(!formattingRangePinned){clearFormattingSelection();}
            if(contextBar!=null)e.post(()->updateContextMode());
        } });
        e.setKeyboardBackListener(v->rememberSelectionBeforeKeyboardBack(v));
        // A genuine tap/cursor move means formatting is finished; do not let an old
        // highlighted range be reused by the next font operation.
        e.setOnTouchListener((v,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN && e.getSelectionStart()==e.getSelectionEnd()) clearFormattingSelection();return false;});
        e.setOnFocusChangeListener((v,has)->{if(has)setActiveTextObject(e);});
        textScaleDetector=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){float base;
            public boolean onScaleBegin(ScaleGestureDetector d){base=e.getTextSize()/getResources().getDisplayMetrics().scaledDensity;return true;}
            public boolean onScale(ScaleGestureDetector d){float n=Math.max(12,Math.min(72,base*d.getScaleFactor()));e.setTextSize(n);if(sizeLabel!=null)sizeLabel.setText("Font "+(int)n+"sp");return true;}});
        final boolean[] blankTapWhileSelected=new boolean[]{false};
        e.setOnTouchListener((v,event)->{
            if(event.getPointerCount()>1){textScaleDetector.onTouchEvent(event);return textScaleDetector.isInProgress();}
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                if(Boolean.TRUE.equals(objectLocks.get(e))){toast("Unlock this object first");return true;}
                setActiveTextObject(e);
                // V30: one tap on genuinely empty paper immediately finishes selection.
                blankTapWhileSelected[0]=e.getSelectionStart()!=e.getSelectionEnd() && isBlankEditorTap(e,event.getX(),event.getY());
                if(blankTapWhileSelected[0]) return true;
            }
            if(blankTapWhileSelected[0]){
                if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL){
                    blankTapWhileSelected[0]=false;
                    activatePageMode();
                }
                return true;
            }
            return false;
        });
        FrameLayout.LayoutParams lp;
        if(fillPage){
            // The editable area itself is INSIDE the print-safe border. Cursor and typing
            // can never travel outside this rectangle.
            lp=new FrameLayout.LayoutParams(-1,-1);
            int safe=dp(borderSafeDp+CONTENT_GAP_DP); lp.leftMargin=safe; lp.topMargin=safe; lp.rightMargin=safe; lp.bottomMargin=safe;
            e.setPadding(0,0,0,0);
        }else{
            lp=new FrameLayout.LayoutParams(dp(260),dp(150));lp.leftMargin=Math.max(dp(borderSafeDp+CONTENT_GAP_DP),dp(left));lp.topMargin=Math.max(dp(borderSafeDp+CONTENT_GAP_DP),dp(top));
            GradientDrawable g=new GradientDrawable();g.setColor(Color.TRANSPARENT);g.setStroke(dp(1),(int)0x225B6B7AL);e.setBackground(g);
        }
        paper.addView(e,lp); textObjects.add(e); objectLocks.put(e,false); objectVisibility.put(e,true); return e;
    }

    /** Returns true only when the tap lands outside the visible text on the current line. */
    boolean isBlankEditorTap(SelectionEditText e,float x,float y){
        try{
            Layout l=e.getLayout(); if(l==null) return false;
            float localY=y-e.getTotalPaddingTop()+e.getScrollY();
            if(localY<0 || localY>l.getHeight()) return true;
            int line=l.getLineForVertical((int)localY);
            if(line<0 || line>=l.getLineCount()) return true;
            int start=l.getLineStart(line), end=l.getLineEnd(line);
            if(start==end || (start<e.length() && end==start+1 && e.getText().charAt(start)=='\n')) return true;
            float localX=x-e.getTotalPaddingLeft()+e.getScrollX();
            float left=l.getLineLeft(line)-dp(8), right=l.getLineRight(line)+dp(8);
            return localX<left || localX>right;
        }catch(Exception ignored){return false;}
    }

    void setActiveTextObject(SelectionEditText e){
        if(e==null)return;
        editor=e;
        String objectFont=textObjectFontNames.get(e);
        if(objectFont!=null){ currentFontName=objectFont; currentTypeface=typefaces.get(objectFont); if(currentTypeface==null)currentTypeface=Typeface.DEFAULT; if(fontSpinner!=null){int fi=fontNames.indexOf(objectFont); if(fi>=0){suppressFontSpinnerCallback=true;fontSpinner.setSelection(fi);suppressFontSpinnerCallback=false;}}}
        selectedTextObject=e;
        selectedDesignObject=null;
        selectedImage=null;
        for(SelectionEditText x:textObjects){ if(x==e){ if(x.getBackground() instanceof ColorDrawable){} } }
        showSelectionOutline(e);
        if(contextBar!=null){
            if(objectSelectionMode) showSelectedTextObjectTools(); else updateContextMode();
        }
    }
    void addTextObject(){
        if(paper==null)return;
        SelectionEditText e=createTextObject("نیا اردو متن",28,70,false);
        setActiveTextObject(e); e.requestFocus(); e.setSelection(e.length()); showKeyboardReliable();
        toast("New text box added — tap inside to edit, long press to select text");
    }
    void showObjectsDialog(){
        showAllObjectsDialog();
    }

    /** One object manager for everything placed on the page. Nothing is permanent by mistake. */
    void showAllObjectsDialog(){
        final ArrayList<View> refs=new ArrayList<>(); final ArrayList<String> names=new ArrayList<>();
        for(int i=0;i<textObjects.size();i++){
            SelectionEditText e=textObjects.get(i); if(e.getParent()!=paper)continue;
            String t=e.getText().toString().replace("\n"," ").trim(); if(t.length()>26)t=t.substring(0,26)+"…";
            refs.add(e); names.add("TEXT "+(i+1)+"  •  "+(t.isEmpty()?"(empty)":t));
        }
        for(View v:designObjects) if(v!=null&&v.getParent()==paper){
            refs.add(v); String n=designObjectNames.get(v);
            names.add((n==null?"DESIGN OBJECT":n.toUpperCase()));
        }
        LinearLayout rootBox=new LinearLayout(this); rootBox.setOrientation(LinearLayout.VERTICAL); rootBox.setPadding(dp(12),dp(8),dp(12),0);
        LinearLayout topRow=new LinearLayout(this); topRow.setGravity(Gravity.CENTER_VERTICAL);
        Button lockAll=button("🔒 Lock All"), unlockAll=button("🔓 Unlock All");
        Button front=button("⬆ Front"), back=button("⬇ Back");
        topRow.addView(lockAll,new LinearLayout.LayoutParams(0,dp(42),1));
        topRow.addView(unlockAll,new LinearLayout.LayoutParams(0,dp(42),1));
        rootBox.addView(topRow);
        LinearLayout layerRow=new LinearLayout(this); layerRow.setGravity(Gravity.CENTER_VERTICAL);
        layerRow.addView(front,new LinearLayout.LayoutParams(0,dp(40),1));
        layerRow.addView(back,new LinearLayout.LayoutParams(0,dp(40),1));
        rootBox.addView(layerRow);
        LinearLayout editRow=new LinearLayout(this); editRow.setGravity(Gravity.CENTER_VERTICAL);
        Button move=button("✥ Move"), align=button("▤ Align");
        editRow.addView(move,new LinearLayout.LayoutParams(0,dp(40),1)); editRow.addView(align,new LinearLayout.LayoutParams(0,dp(40),1)); rootBox.addView(editRow);
        TextView hint=text("Tick one object to select it. Blue frame = selected. Lock icon locks only that item. Layer order can be changed safely.",11);
        hint.setPadding(dp(4),dp(6),dp(4),dp(4)); rootBox.addView(hint);
        TextView layerHelp=text("☑ Select  •  👁 Show/Hide  •  🔒 Lock  •  Front/Back changes layer order",10);layerHelp.setTextColor((int)0xFF607080L);rootBox.addView(layerHelp);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        final ArrayList<CheckBox> boxes=new ArrayList<>();
        for(int i=0;i<refs.size();i++){
            final View ref=refs.get(i); final int index=i;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(2),0,dp(2),0);
            CheckBox cb=new CheckBox(this); boxes.add(cb);
            TextView label=text(names.get(i),11); label.setSingleLine(true);
            TextView eye=text(ref.getVisibility()==View.VISIBLE?"👁":"🚫",18); eye.setGravity(Gravity.CENTER);
            TextView lock=text(Boolean.TRUE.equals(objectLocks.get(ref))?"🔒":"🔓",20); lock.setGravity(Gravity.CENTER);
            row.addView(cb,new LinearLayout.LayoutParams(dp(44),dp(50)));
            row.addView(label,new LinearLayout.LayoutParams(0,dp(50),1));
            row.addView(eye,new LinearLayout.LayoutParams(dp(46),dp(50)));
            row.addView(lock,new LinearLayout.LayoutParams(dp(50),dp(50)));
            cb.setOnCheckedChangeListener((b,checked)->{
                if(!checked)return;
                for(int j=0;j<boxes.size();j++)if(j!=index&&boxes.get(j).isChecked())boxes.get(j).setChecked(false);
                if(ref instanceof SelectionEditText){
                    objectSelectionMode=true; setActiveTextObject((SelectionEditText)ref); showSelectedTextObjectTools();
                }else selectDesignObject(ref);
            });
            eye.setOnClickListener(v->{boolean visible=ref.getVisibility()!=View.VISIBLE;ref.setVisibility(visible?View.VISIBLE:View.INVISIBLE);objectVisibility.put(ref,visible);eye.setText(visible?"👁":"🚫");toast(visible?"Object shown":"Object hidden");});
            lock.setOnClickListener(v->{boolean n=!Boolean.TRUE.equals(objectLocks.get(ref));objectLocks.put(ref,n);lock.setText(n?"🔒":"🔓");toast(n?"Object locked":"Object unlocked");});
            row.setOnClickListener(v->cb.setChecked(true)); list.addView(row);
        }
        if(refs.isEmpty()){TextView empty=text("No objects on this page yet.",13);empty.setPadding(dp(12),dp(20),0,dp(20));list.addView(empty);}
        scroll.addView(list); rootBox.addView(scroll,new LinearLayout.LayoutParams(-1,dp(350)));
        lockAll.setOnClickListener(v->{setAllObjectsLocked(true); for(int i=0;i<refs.size();i++){} toast("All page objects locked");});
        unlockAll.setOnClickListener(v->{setAllObjectsLocked(false);toast("All page objects unlocked");});
        front.setOnClickListener(v->{moveSelectedLayer(true);});
        back.setOnClickListener(v->{moveSelectedLayer(false);});
        move.setOnClickListener(v->{showMoveSelectedObjectDialog();});
        align.setOnClickListener(v->{showAlignSelectedObjectDialog();});
        new AlertDialog.Builder(this).setTitle("Layers & Objects").setView(rootBox).setNegativeButton("Close",null).show();
    }

    void moveSelectedLayer(boolean toFront){
        View v=selectedDesignObject!=null?selectedDesignObject:selectedTextObject;
        if(v==null){toast("Tick/select an object first");return;}
        if("border".equals(v.getTag())){toast("Border stays behind all content");return;}
        if(toFront)v.bringToFront(); else {
            if(paper!=null){int index=paper.indexOfChild(v); if(index>1){paper.removeView(v); paper.addView(v,1);}}
        }
        if(v==selectedDesignObject)showSelectionOutline(v); else if(v==selectedTextObject)showSelectionOutline(v);
        toast(toFront?"Layer moved to front":"Layer moved backward");
    }

    void showMoveSelectedObjectDialog(){
        final View target=selectedDesignObject!=null?selectedDesignObject:selectedTextObject;
        if(target==null){toast("Select an object first");return;}
        String[] a={"Move Up","Move Down","Move Left","Move Right","Center Horizontally","Center Vertically"};
        new AlertDialog.Builder(this).setTitle("Move Selected Object").setItems(a,(d,w)->{
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)target.getLayoutParams(); int step=dp(8);
            if(w==0)lp.topMargin-=step; else if(w==1)lp.topMargin+=step; else if(w==2)lp.leftMargin-=step; else if(w==3)lp.leftMargin+=step;
            else if(w==4)lp.leftMargin=Math.max(0,(paper.getWidth()-Math.max(1,target.getWidth()))/2);
            else lp.topMargin=Math.max(0,(paper.getHeight()-Math.max(1,target.getHeight()))/2);
            clampObjectToAllowedArea(target,lp); target.setLayoutParams(lp); showSelectionOutline(target);
        }).show();
    }
    void showAlignSelectedObjectDialog(){
        final View target=selectedDesignObject!=null?selectedDesignObject:selectedTextObject;
        if(target==null){toast("Select an object first");return;}
        String[] a={"Left","Center","Right","Top","Middle","Bottom"};
        new AlertDialog.Builder(this).setTitle("Align Selected Object").setItems(a,(d,w)->{
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)target.getLayoutParams(); int tw=Math.max(1,target.getWidth()), th=Math.max(1,target.getHeight());
            int safe=target==primaryEditor?dp(borderSafeDp+CONTENT_GAP_DP):0;
            if(w==0)lp.leftMargin=safe; else if(w==1)lp.leftMargin=Math.max(safe,(paper.getWidth()-tw)/2); else if(w==2)lp.leftMargin=Math.max(safe,paper.getWidth()-safe-tw);
            else if(w==3)lp.topMargin=safe; else if(w==4)lp.topMargin=Math.max(safe,(paper.getHeight()-th)/2); else lp.topMargin=Math.max(safe,paper.getHeight()-safe-th);
            clampObjectToAllowedArea(target,lp); target.setLayoutParams(lp); showSelectionOutline(target);
        }).show();
    }
    void clampObjectToAllowedArea(View target,FrameLayout.LayoutParams lp){
        if(paper==null || target==null)return;
        // Safe area is enforced for every movable content object. The actual border itself
        // is a page decoration and is intentionally exempt.
        if("border".equals(target.getTag())) return;
        int safe=dp(borderSafeDp+CONTENT_GAP_DP);
        int w=target.getWidth()>0?target.getWidth():lp.width;
        int h=target.getHeight()>0?target.getHeight():lp.height;
        if(w>0){int max=Math.max(safe,paper.getWidth()-safe-w);lp.leftMargin=Math.max(safe,Math.min(max,lp.leftMargin));}
        if(h>0){int max=Math.max(safe,paper.getHeight()-safe-h);lp.topMargin=Math.max(safe,Math.min(max,lp.topMargin));}
    }

void registerDesignObject(View v,String name){
        if(v==null)return;
        if(!designObjects.contains(v))designObjects.add(v);
        designObjectNames.put(v,name==null?"Design Object":name); objectLocks.put(v,false); objectVisibility.put(v,true);
        makeDraggable(v);
        v.setOnClickListener(q->{selectDesignObject(q);});
    }

    void selectDesignObject(View v){
        if(v==null)return;
        objectSelectionMode=false;
        selectedTextObject=null;
        selectedDesignObject=v;
        selectedImage=v instanceof ImageView?(ImageView)v:null;
        if(v instanceof SelectionEditText){
            setActiveTextObject((SelectionEditText)v);
            ((SelectionEditText)v).requestFocus();
            return;
        }
        // A small elevation change gives a visible selected state without destroying the original design.
        for(View x:designObjects) if(x!=null) x.setElevation(dp(1));
        if(v.getTag()!=null && "border".equals(v.getTag())) v.setElevation(0); else v.setElevation(dp(8));
        showSelectionOutline(v);
        if(contextBar!=null)showSelectedObjectTools();
        toast((designObjectNames.get(v)==null?"Object":designObjectNames.get(v))+" selected");
    }

    void showSelectedObjectTools(){
        if(contextBar==null || selectedDesignObject==null)return;
        contextBar.removeAllViews();
        String n=designObjectNames.get(selectedDesignObject);
        if(n==null && "border".equals(selectedDesignObject.getTag()))n="Border / Frame";
        if(n==null)n="Selected Object";
        TextView head=text(n+" SELECTED • You can safely edit, duplicate or delete it",10);
        head.setPadding(dp(8),0,0,0);head.setTextColor(PURPLE);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        contextBar.addView(head,new LinearLayout.LayoutParams(-1,dp(24)));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        boolean isBorder="border".equals(selectedDesignObject.getTag());
        contextRow(row,"✎","Edit",v->editSelectedDesignObject());
        if(isBorder){
            contextRow(row,"↕","Line Width",v->showBorderStrokeWidthDialog());
            contextRow(row,"↔","Safe Margin",v->showBorderSafeWidthDialog());
        } else {
            contextRow(row,"✥","Move",v->showMoveSelectedObjectDialog());
            contextRow(row,"▤","Align",v->showAlignSelectedObjectDialog());
            contextRow(row,"＋","Larger",v->resizeSelectedDesignObject(1.15f));
            contextRow(row,"－","Smaller",v->resizeSelectedDesignObject(.85f));
            contextRow(row,"▣+","Duplicate",v->duplicateSelectedDesignObject());
            contextRow(row,"⌫","Delete",v->deleteSelectedDesignObject());
        }
        contextRow(row,"🔒","Lock",v->toggleSelectedObjectLock());
        contextRow(row,"☷","Layers",v->showAllObjectsDialog());
        contextRow(row,"⬆","Front",v->moveSelectedLayer(true)); contextRow(row,"⬇","Back",v->moveSelectedLayer(false));
        contextRow(row,"✓","Done",v->activatePageMode());
        hs.addView(row,new HorizontalScrollView.LayoutParams(-2,dp(70)));
        contextBar.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
    }

    void editSelectedDesignObject(){
        if(selectedDesignObject==null)return;
        if("border".equals(selectedDesignObject.getTag())){showBorderStrokeWidthDialog();return;}
        if(selectedDesignObject instanceof ImageView){showImageTools();return;}
        if(selectedDesignObject instanceof TextView){
            TextView tv=(TextView)selectedDesignObject;
            final EditText input=new EditText(this);input.setText(tv.getText());input.setSelectAllOnFocus(true);
            new AlertDialog.Builder(this).setTitle("Edit Element").setView(input)
                .setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{tv.setText(input.getText());toast("Element updated");}).show();
            return;
        }
        final int[] colors={BLUE2,PURPLE,GREEN,RED,(int)0xFFD69A21L,(int)0xFF178B8BL,Color.DKGRAY};
        String[] names={"Blue","Purple","Green","Red","Gold","Teal","Dark"};
        new AlertDialog.Builder(this).setTitle("Edit Shape Color").setItems(names,(d,w)->{
            GradientDrawable g=bg(colors[w],12);g.setAlpha(210);selectedDesignObject.setBackground(g);toast("Shape updated");
        }).show();
    }

    void duplicateSelectedDesignObject(){
        if(selectedDesignObject==null){toast("Select an object first");return;}
        if("border".equals(selectedDesignObject.getTag())){toast("Only one page border is allowed — choose another border to replace it");return;}
        View original=selectedDesignObject;
        FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)original.getLayoutParams();
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(dp(40),old.width),Math.max(dp(40),old.height));
        lp.leftMargin=Math.max(0,old.leftMargin+dp(18));lp.topMargin=Math.max(0,old.topMargin+dp(18));
        View copyView;
        if(original instanceof ImageView){
            ImageView iv=new ImageView(this);iv.setImageDrawable(((ImageView)original).getDrawable());iv.setScaleType(((ImageView)original).getScaleType());copyView=iv;
        }else if(original instanceof TextView){
            TextView a=(TextView)original;TextView tv=new TextView(this);tv.setText(a.getText());tv.setTextSize(TypedValue.COMPLEX_UNIT_PX,a.getTextSize());tv.setTextColor(a.getCurrentTextColor());tv.setGravity(a.getGravity());tv.setPadding(a.getPaddingLeft(),a.getPaddingTop(),a.getPaddingRight(),a.getPaddingBottom());tv.setBackground(a.getBackground());copyView=tv;
        }else{
            View v=new View(this);v.setBackground(original.getBackground());copyView=v;
        }
        paper.addView(copyView,lp);
        registerDesignObject(copyView,(designObjectNames.get(original)==null?"Object":designObjectNames.get(original))+" Copy");
        selectDesignObject(copyView);toast("Object duplicated");
    }

    void resizeSelectedDesignObject(float factor){
        if(selectedDesignObject==null){toast("Select an object first");return;}
        if("border".equals(selectedDesignObject.getTag())){toast("Border size follows the page safely");return;}
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)selectedDesignObject.getLayoutParams();
        int maxW=Math.max(dp(60),paper.getWidth()-dp(20)),maxH=Math.max(dp(60),paper.getHeight()-dp(20));
        int cw=selectedDesignObject.getWidth()>0?selectedDesignObject.getWidth():lp.width;
        int ch=selectedDesignObject.getHeight()>0?selectedDesignObject.getHeight():lp.height;
        lp.width=Math.max(dp(40),Math.min(maxW,Math.round(cw*factor)));
        lp.height=Math.max(dp(40),Math.min(maxH,Math.round(ch*factor)));
        selectedDesignObject.setLayoutParams(lp);showSelectionOutline(selectedDesignObject);toast("Object resized");
    }

    void deleteSelectedDesignObject(){
        if(selectedDesignObject==null){toast("Select an object first");return;}
        if("border".equals(selectedDesignObject.getTag())){
            paper.removeView(selectedDesignObject);designObjects.remove(selectedDesignObject);designObjectNames.remove(selectedDesignObject);objectLocks.remove(selectedDesignObject);objectVisibility.remove(selectedDesignObject);imageSources.remove(selectedDesignObject);selectedDesignObject=null;toast("Border removed");showPageTools();return;
        }
        View v=selectedDesignObject;
        new AlertDialog.Builder(this).setTitle("Delete Object?").setMessage("This object can be removed safely from the page.")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
                if(v.getParent()==paper)paper.removeView(v);
                designObjects.remove(v);designObjectNames.remove(v);objectLocks.remove(v);objectVisibility.remove(v);imageSources.remove(v);
                if(v==selectedImage)selectedImage=null;
                selectedDesignObject=null;toast("Object deleted");showPageTools();
            }).show();
    }

    void duplicateActiveTextObject(){
        if(editor==null){toast("Select a text box first");return;}
        if(Boolean.TRUE.equals(objectLocks.get(editor))){toast("Unlock this object first");return;}
        SelectionEditText original=editor;
        FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)original.getLayoutParams();
        boolean isPrimary=original==primaryEditor || old.width==-1 || old.height==-1;
        int left=isPrimary?dp(28):old.leftMargin+dp(18);
        int top=isPrimary?dp(70):old.topMargin+dp(18);
        SelectionEditText copy=createTextObject(original.getText().toString(),left,top,false);
        copy.setTextColor(original.getCurrentTextColor());
        copy.setTextSize(TypedValue.COMPLEX_UNIT_PX,original.getTextSize());
        setActiveTextObject(copy);copy.requestFocus();toast("Text box duplicated");
    }

    void deleteActiveTextObject(){
        if(editor==null)return;
        if(editor==primaryEditor){deleteSelected();return;}
        SelectionEditText doomed=editor;
        new AlertDialog.Builder(this).setTitle("Delete Text Box?").setNegativeButton("Cancel",null)
            .setPositiveButton("Delete",(d,w)->{paper.removeView(doomed);textObjects.remove(doomed);objectLocks.remove(doomed);objectVisibility.remove(doomed);editor=primaryEditor;if(editor!=null)editor.requestFocus();showPageTools();toast("Text box deleted");}).show();
    }

    /** Object-level controls for a selected text box. These work even when no word is highlighted. */
    void showSelectedTextObjectTools(){
        if(contextBar==null || selectedTextObject==null)return;
        contextBar.removeAllViews();
        String preview=selectedTextObject.getText().toString().replace("\n"," ").trim();
        if(preview.length()>22)preview=preview.substring(0,22)+"…";
        TextView head=text("TEXT BOX SELECTED • "+(preview.length()==0?"Empty":preview),10);
        head.setPadding(dp(8),0,0,0);head.setTextColor(PURPLE);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        contextBar.addView(head,new LinearLayout.LayoutParams(-1,dp(24)));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(row,"✎","Edit",v->{objectSelectionMode=false;selectedTextObject.requestFocus();showKeyboardReliable();updateContextMode();});
        contextRow(row,"▣+","Duplicate",v->duplicateActiveTextObject());
        contextRow(row,"⌫","Delete",v->deleteActiveTextObject());
        contextRow(row,"✥","Move",v->showMoveSelectedObjectDialog()); contextRow(row,"▤","Align",v->showAlignSelectedObjectDialog());
        contextRow(row,"↗","Front",v->{if(selectedTextObject!=null){selectedTextObject.bringToFront();showSelectionOutline(selectedTextObject);toast("Text box brought to front");}});
        contextRow(row,"↕","Size",v->{editor=selectedTextObject;showSizeDialog();}); contextRow(row,"🔒","Lock",v->toggleSelectedObjectLock());
        contextRow(row,"✓","Done",v->activatePageMode());
        hs.addView(row,new HorizontalScrollView.LayoutParams(-2,dp(70)));
        contextBar.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
    }

    void updateContextMode(){
        if(editor==null || contextBar==null) return;
        int a=editor.getSelectionStart(), b=editor.getSelectionEnd();
        if(a>=0 && b>=0 && a!=b){ showTextTools(); return; }
        // Android may briefly collapse selection while the Back key hides the IME.
        // Restore the exact selection instead of closing the Text Tools panel.
        if(preserveSelectionAfterImeBack && preservedSelectionStart>=0 && preservedSelectionEnd>preservedSelectionStart){
            final int start=Math.min(preservedSelectionStart,editor.length());
            final int end=Math.min(preservedSelectionEnd,editor.length());
            editor.postDelayed(()->{
                if(editor!=null && preserveSelectionAfterImeBack){
                    try{ editor.setSelection(start,end); }catch(Exception ignored){}
                    preserveSelectionAfterImeBack=false;
                    preservedSelectionStart=-1; preservedSelectionEnd=-1;
                    showTextTools();
                }
            },80);
            return;
        }
        showPageTools();
    }

    void rememberSelectionBeforeKeyboardBack(SelectionEditText e){
        if(e==null || e!=editor)return;
        int a=e.getSelectionStart(), b=e.getSelectionEnd();
        if(a>=0 && b>=0 && a!=b){
            preservedSelectionStart=Math.min(a,b); preservedSelectionEnd=Math.max(a,b);
            preserveSelectionAfterImeBack=true;
            textToolsMode=true;
        }
    }

    /** Explicit page mode: close text editing and restore page controls. */
    void activatePageMode(){
        preserveSelectionAfterImeBack=false; preservedSelectionStart=-1; preservedSelectionEnd=-1; formatSelectionStart=-1; formatSelectionEnd=-1; objectSelectionMode=false; selectedTextObject=null; selectedDesignObject=null; selectedImage=null;
        if(editor!=null){
            int p=Math.max(0,editor.getSelectionEnd());
            editor.setSelection(p); // collapses any highlighted range
            editor.clearFocus();
            InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null) imm.hideSoftInputFromWindow(editor.getWindowToken(),0);
        }
        clearSelectionOutline();
        showPageTools();
    }

    void showKeyboardReliable(){
        if(editor==null || objectLocked)return;
        editor.setFocusableInTouchMode(true); editor.requestFocus();
        editor.postDelayed(()->{InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); if(imm!=null){imm.showSoftInput(editor,InputMethodManager.SHOW_IMPLICIT); imm.showSoftInput(editor,InputMethodManager.SHOW_FORCED);}},120);
    }
    View contextButton(String icon,String label,View.OnClickListener click){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(dp(4),dp(2),dp(4),dp(2)); box.setClickable(true); box.setBackground(bg((int)0xFFF7F8FCL,10)); box.setOnClickListener(click);
        TextView a=text(icon,20); a.setGravity(Gravity.CENTER); a.setTextColor(PURPLE); box.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView b=text(label,10); b.setGravity(Gravity.CENTER); b.setSingleLine(); b.setTextColor((int)0xFF4E5865L); box.addView(b,new LinearLayout.LayoutParams(-1,dp(28)));
        return box;
    }
    void contextRow(LinearLayout row,String icon,String label,View.OnClickListener click){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(78),dp(62)); lp.setMargins(dp(3),dp(2),dp(3),dp(2)); row.addView(contextButton(icon,label,click),lp); }
    void showTextTools(){
        if(contextBar==null)return; ViewGroup.LayoutParams textToolsLp=contextBar.getLayoutParams(); if(textToolsLp!=null){textToolsLp.height=dp(170);contextBar.setLayoutParams(textToolsLp);} textToolsMode=true; contextBar.removeAllViews();
        TextView head=text("TEXT SELECTED • Tools are ready below",11); head.setPadding(dp(10),0,0,0); head.setTextColor(PURPLE); head.setTypeface(Typeface.DEFAULT,Typeface.BOLD); contextBar.addView(head,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout r1=new LinearLayout(this); r1.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(r1,"Aa","Font",v->showFontsDialog()); contextRow(r1,"↕","Size",v->showSizeDialog()); contextRow(r1,"B","Bold",v->toggleStyleSelection(Typeface.BOLD)); contextRow(r1,"I","Italic",v->toggleStyleSelection(Typeface.ITALIC)); contextRow(r1,"U","Underline",v->toggleUnderlineSelection()); contextRow(r1,"◆","Color",v->chooseTextColor()); contextRow(r1,"↔","Word Space",v->showWordSpacingDialog()); contextRow(r1,"↕","Line Space",v->showLineSpacingDialog());
        HorizontalScrollView hs1=new HorizontalScrollView(this); hs1.setHorizontalScrollBarEnabled(false); hs1.addView(r1,new HorizontalScrollView.LayoutParams(-2,dp(70))); contextBar.addView(hs1,new LinearLayout.LayoutParams(-1,dp(70)));
        LinearLayout r2=new LinearLayout(this); r2.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(r2,"▤","Align",v->chooseAlignment()); contextRow(r2,"▣","Copy",v->copySelection(false)); contextRow(r2,"✂","Cut",v->copySelection(true)); contextRow(r2,"▣+","Paste",v->pasteClipboard()); contextRow(r2,"⌫","Delete",v->deleteSelected()); contextRow(r2,"▣+","Duplicate Box",v->duplicateActiveTextObject()); contextRow(r2,"▣×","Delete Box",v->deleteActiveTextObject()); contextRow(r2,"ALL","All",v->{editor.selectAll();updateContextMode();}); contextRow(r2,"✓","Done",v->activatePageMode());
        HorizontalScrollView hs2=new HorizontalScrollView(this); hs2.setHorizontalScrollBarEnabled(false); hs2.addView(r2,new HorizontalScrollView.LayoutParams(-2,dp(70))); contextBar.addView(hs2,new LinearLayout.LayoutParams(-1,dp(70)));
    }
    /**
     * Always-visible page navigation. Earlier builds put page switching behind the
     * horizontally-scrollable tool row, which made Page 1 / Page 3 navigation easy
     * to miss on narrow phones.
     */
    void showPageTools(){
        if(contextBar==null)return;
        ViewGroup.LayoutParams pageToolsLp=contextBar.getLayoutParams();
        if(pageToolsLp!=null){pageToolsLp.height=dp(132);contextBar.setLayoutParams(pageToolsLp);}
        textToolsMode=false; objectSelectionMode=false; selectedTextObject=null;
        contextBar.removeAllViews();

        LinearLayout nav=new LinearLayout(this);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(dp(6),dp(3),dp(6),dp(3));

        TextView prev=text("‹  Prev",13); prev.setGravity(Gravity.CENTER); prev.setTextColor(Color.WHITE);
        prev.setTypeface(Typeface.DEFAULT,Typeface.BOLD); prev.setBackground(bg(BLUE2,10));
        prev.setContentDescription("Previous page"); prev.setEnabled(currentPage>0); prev.setAlpha(currentPage>0?1f:.35f);
        prev.setOnClickListener(v->goToPreviousPage());
        nav.addView(prev,new LinearLayout.LayoutParams(dp(72),dp(40)));

        TextView indicator=text("PAGE "+(currentPage+1)+" of "+Math.max(1,pages.size())+" • TAP TO JUMP",12);
        indicator.setGravity(Gravity.CENTER); indicator.setTextColor(BLUE2); indicator.setSingleLine(true);
        indicator.setEllipsize(TextUtils.TruncateAt.END); indicator.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        indicator.setClickable(true); indicator.setPadding(dp(6),0,dp(6),0); indicator.setBackground(bg((int)0xFFF3F6FAL,10));
        indicator.setOnClickListener(v->showPageJumpDialog());
        LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(0,dp(40),1);ilp.setMargins(dp(5),0,dp(5),0);nav.addView(indicator,ilp);

        TextView next=text("Next  ›",13); next.setGravity(Gravity.CENTER); next.setTextColor(Color.WHITE);
        next.setTypeface(Typeface.DEFAULT,Typeface.BOLD); next.setBackground(bg(BLUE2,10));
        next.setContentDescription("Next page"); next.setEnabled(currentPage<pages.size()-1); next.setAlpha(currentPage<pages.size()-1?1f:.35f);
        next.setOnClickListener(v->goToNextPage());
        nav.addView(next,new LinearLayout.LayoutParams(dp(72),dp(40)));
        contextBar.addView(nav,new LinearLayout.LayoutParams(-1,dp(46)));

        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        contextRow(row,"＋","Text Box",v->addTextObject()); contextRow(row,"▦","Objects",v->showAllObjectsDialog()); contextRow(row,"☷","Layers",v->showAllObjectsDialog()); contextRow(row,"＋","New Page",v->addNewPage()); contextRow(row,"↔","Paper Size",v->choosePage()); contextRow(row,"◇","Background",v->choosePaperColor()); contextRow(row,"▣","Border",v->chooseBorder()); contextRow(row,"▤","Pages",v->showPageEditDialog()); contextRow(row,"▧","Template",v->chooseTemplate()); contextRow(row,"🖼","Add Image",v->pickImage()); contextRow(row,"🔒","Lock",v->toggleLock());
        hs.addView(row,new HorizontalScrollView.LayoutParams(-2,dp(70)));
        contextBar.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
    }

    void addTop(LinearLayout row,String label,View.OnClickListener l){Button b=button(label);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setBackground(bg(BLUE2,10));b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);row.addView(b,lp);}
    void addTool(String label,View.OnClickListener l){Button b=button(label);b.setTextSize(11);b.setTextColor(BLUE);b.setBackground(bg((int)0xFFF2F5F8L,10));b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(82),dp(42));lp.setMargins(dp(3),0,dp(3),0);tools.addView(b,lp);}


    /** Remember the current highlighted range for formatting UI that steals focus. */
    void rememberFormattingSelection(){
        if(editor==null)return;
        int a=editor.getSelectionStart(), b=editor.getSelectionEnd();
        if(a>=0 && b>=0 && a!=b){
            formatSelectionStart=Math.min(a,b);formatSelectionEnd=Math.max(a,b);
            formattingRangePinned=true;
        }else if(!formattingRangePinned){
            clearFormattingSelection();
        }
    }
    void clearFormattingSelection(){
        formatSelectionStart=-1;formatSelectionEnd=-1;formattingRangePinned=false;
    }
    boolean hasRememberedFormattingSelection(){
        return editor!=null && formattingRangePinned && formatSelectionStart>=0 && formatSelectionEnd>formatSelectionStart && formatSelectionEnd<=editor.length();
    }
    int formattingStart(){return hasRememberedFormattingSelection()?formatSelectionStart:Math.min(editor.getSelectionStart(),editor.getSelectionEnd());}
    int formattingEnd(){return hasRememberedFormattingSelection()?formatSelectionEnd:Math.max(editor.getSelectionStart(),editor.getSelectionEnd());}

    void applyTypeface(){
        if(editor==null)return;
        if(currentTypeface==null)currentTypeface=Typeface.DEFAULT;
        rememberFormattingSelection();
        // No highlighted text: this is a default typing choice, not an error.
        // New keystrokes (and a new blank/overflow page) keep this font until changed manually.
        if(!hasRememberedFormattingSelection()){
            editor.setTypeface(currentTypeface);
            textObjectFontNames.put(editor,currentFontName);
            editor.requestLayout();
            toast("Font set for typing: "+currentFontName);
            return;
        }
        int a=formattingStart(), b=formattingEnd();
        Editable e=editor.getText();
        LocalTypefaceSpan[] oldSpans=e.getSpans(0,e.length(),LocalTypefaceSpan.class);
        for(LocalTypefaceSpan sp:oldSpans){
            int ss=e.getSpanStart(sp),se=e.getSpanEnd(sp);
            if(ss<b && se>a){
                e.removeSpan(sp);
                if(ss<a)e.setSpan(new LocalTypefaceSpan(sp.typeface,sp.fontName),ss,a,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                if(se>b)e.setSpan(new LocalTypefaceSpan(sp.typeface,sp.fontName),b,se,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        // Keep the range-local font as a real rich-text span. The span is independent
        // of focus/selection state, so tapping empty space or closing the keyboard can
        // never convert the selected characters back to the object's base font.
        e.setSpan(new LocalTypefaceSpan(currentTypeface,currentFontName),a,b,Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
        editor.requestLayout(); editor.invalidate();
        saveCurrentPageState();
        clearFormattingSelection();
        toast("Font permanently applied to selected text");
    }

    /** Persist all supported rich formatting for each independent text object. */
    String serializeTypefaceSpans(SelectionEditText e){
        try{
            org.json.JSONArray out=new org.json.JSONArray(); Editable x=e.getText();
            for(Object span:x.getSpans(0,x.length(),Object.class)){
                int st=x.getSpanStart(span), en=x.getSpanEnd(span); if(st<0||en<=st)continue;
                org.json.JSONObject j=new org.json.JSONObject(); j.put("s",st); j.put("e",en);
                if(span instanceof LocalTypefaceSpan){j.put("t","font");j.put("f",((LocalTypefaceSpan)span).fontName);}
                else if(span instanceof ForegroundColorSpan){j.put("t","color");j.put("v",((ForegroundColorSpan)span).getForegroundColor());}
                else if(span instanceof StyleSpan){j.put("t","style");j.put("v",((StyleSpan)span).getStyle());}
                else if(span instanceof UnderlineSpan){j.put("t","underline");}
                else if(span instanceof AbsoluteSizeSpan){j.put("t","size");j.put("v",((AbsoluteSizeSpan)span).getSize());j.put("dip",true);}
                else if(span instanceof WordSpacingSpan){j.put("t","word");j.put("v",((WordSpacingSpan)span).extraPx);}
                else if(span instanceof RelativeLineSpacingSpan){j.put("t","line");j.put("v",((RelativeLineSpacingSpan)span).multiplier);}
                else continue;
                out.put(j);
            }
            return out.toString();
        }catch(Exception ignored){return "[]";}
    }
    void restoreTypefaceSpans(SelectionEditText e,String raw){
        if(raw==null||raw.isEmpty())return;
        try{org.json.JSONArray a=new org.json.JSONArray(raw); Editable x=e.getText();
            for(int i=0;i<a.length();i++){
                org.json.JSONObject j=a.getJSONObject(i); int st=Math.max(0,j.has("s")?j.optInt("s"):j.optInt("start"));
                int en=Math.min(x.length(),j.has("e")?j.optInt("e"):j.optInt("end")); if(en<=st)continue;
                String t=j.optString("t",""); Object span=null;
                if("font".equals(t)||j.has("f")){String fn=j.optString("f",j.optString("font","System Urdu"));Typeface tf=typefaces.get(fn);if(tf==null)tf=Typeface.DEFAULT;span=new LocalTypefaceSpan(tf,fn);}
                else if("color".equals(t)){span=new ForegroundColorSpan(j.optInt("v",textColor));}
                else if("style".equals(t)){span=new StyleSpan(j.optInt("v",Typeface.NORMAL));}
                else if("underline".equals(t)){span=new UnderlineSpan();}
                else if("size".equals(t)){span=new AbsoluteSizeSpan(j.optInt("v",14),j.optBoolean("dip",true));}
                else if("word".equals(t)){span=new WordSpacingSpan((float)j.optDouble("v",0));}
                else if("line".equals(t)){span=new RelativeLineSpacingSpan((float)j.optDouble("v",1));}
                if(span!=null){
                    int flags=(span instanceof RelativeLineSpacingSpan)?Spannable.SPAN_PARAGRAPH:Spannable.SPAN_EXCLUSIVE_EXCLUSIVE;
                    x.setSpan(span,st,en,flags);
                }
            }
        }catch(Exception ignored){}
    }
    /** Returns the rich-format JSON for a character range, with offsets rebased to zero. */
    String sliceRichSpans(String raw,int from,int to){
        try{org.json.JSONArray src=new org.json.JSONArray(raw==null?"[]":raw), out=new org.json.JSONArray();
            for(int i=0;i<src.length();i++){org.json.JSONObject j=src.getJSONObject(i);int s0=j.has("s")?j.optInt("s"):j.optInt("start"), e0=j.has("e")?j.optInt("e"):j.optInt("end");
                int a=Math.max(from,s0), b=Math.min(to,e0); if(b<=a)continue;
                org.json.JSONObject q=new org.json.JSONObject(j.toString());q.put("s",a-from);q.put("e",b-from);q.remove("start");q.remove("end");out.put(q);
            } return out.toString();
        }catch(Exception ignored){return "[]";}
    }

    void applyGravity(){
        if(editor==null)return;
        if(center){
            editor.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        }else{
            boolean rtl=languageSpinner==null || languageSpinner.getSelectedItemPosition()==1 || languageSpinner.getSelectedItemPosition()==3;
            editor.setGravity(Gravity.TOP|(rtl?Gravity.RIGHT:Gravity.LEFT));
        }
    }

    void setupUndo(){
        undoStack.clear();
        redoStack.clear();
        if(editor==null)return;
        undoStack.add(editor.getText().toString());
        editor.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable s){
                if(changing)return;
                String now=s.toString();
                if(undoStack.isEmpty() || !now.equals(undoStack.get(undoStack.size()-1))){
                    undoStack.add(now);
                    if(undoStack.size()>100)undoStack.remove(0);
                    redoStack.clear();
                }
                saveCurrentPageState();
                editor.post(()->ensureActiveTextFitsPage());
            }
        });
    }

    void undo(){
        if(editor==null || undoStack.size()<2){toast("Nothing to undo");return;}
        String current=undoStack.remove(undoStack.size()-1);
        redoStack.add(current);
        String previous=undoStack.get(undoStack.size()-1);
        changing=true;
        editor.setText(previous);
        editor.setSelection(editor.length());
        changing=false;
        saveCurrentPageState();
    }

    void redo(){
        if(editor==null || redoStack.isEmpty()){toast("Nothing to redo");return;}
        String next=redoStack.remove(redoStack.size()-1);
        undoStack.add(next);
        changing=true;
        editor.setText(next);
        editor.setSelection(editor.length());
        changing=false;
        saveCurrentPageState();
    }

    void applyLanguage(int p){if(editor==null)return;boolean rtl=(p==1||p==3);Locale loc=new Locale("ur","PK");if(p==2||p==11)loc=Locale.ENGLISH;else if(p==3)loc=new Locale("ar");else if(p==4)loc=new Locale("hi","IN");else if(p==5)loc=new Locale("bn","BD");else if(p==6)loc=new Locale("pa","IN");else if(p==7)loc=new Locale("gu","IN");else if(p==8)loc=new Locale("mr","IN");else if(p==9)loc=new Locale("ta","IN");else if(p==10)loc=new Locale("te","IN");editor.setTextDirection(rtl?View.TEXT_DIRECTION_RTL:View.TEXT_DIRECTION_LTR);editor.setTextLocale(loc);if(rtl)editor.setGravity(Gravity.TOP|Gravity.RIGHT);else editor.setGravity(Gravity.TOP|Gravity.LEFT);toast("Language activated: "+languageSpinner.getSelectedItem());}
    void toggleStyleSelection(int style){
        rememberFormattingSelection();
        int a=formattingStart(),b=formattingEnd();
        if(a==b){toast("Select text first");return;}
        Editable e=editor.getText(); a=Math.min(a,b);b=Math.max(a,b);
        StyleSpan[] old=e.getSpans(a,b,StyleSpan.class); boolean remove=false;
        for(StyleSpan sp:old) if((sp.getStyle()&style)!=0){remove=true; e.removeSpan(sp);}
        if(!remove)e.setSpan(new StyleSpan(style),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        toast(remove?"Style removed":"Style applied");
    }
    void showWordSpacingDialog(){
        rememberFormattingSelection();
        if(editor==null || formattingStart()==formattingEnd()){toast("Select text first");return;}
        final String[] labels={"Extra tight","Tight","Default compact","Normal","1","2","3","4","6","8","10"};
        final float[] values={-3f,-2f,DEFAULT_URDU_WORD_SPACING_DP,0f,1f,2f,3f,4f,6f,8f,10f};
        new AlertDialog.Builder(this).setTitle("Word spacing").setItems(labels,(d,w)->applyWordSpacingToSelection(values[w])).show();
    }
    void applyWordSpacingToSelection(float dpValue){
        int a=Math.min(formattingStart(),formattingEnd()), b=Math.max(formattingStart(),formattingEnd());
        if(a==b){toast("Select text first");return;}
        Editable e=editor.getText();
        for(WordSpacingSpan sp:e.getSpans(0,e.length(),WordSpacingSpan.class)){int ss=e.getSpanStart(sp),se=e.getSpanEnd(sp);if(ss<b&&se>a)e.removeSpan(sp);}
        // Use the compact Urdu default when no custom span is needed. Negative values tighten only word gaps.
        if(Math.abs(dpValue-DEFAULT_URDU_WORD_SPACING_DP)>0.01f){
            float px=dpValue*getResources().getDisplayMetrics().density;
            e.setSpan(new WordSpacingSpan(px),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        editor.requestLayout();
        if(Math.abs(dpValue-DEFAULT_URDU_WORD_SPACING_DP)<0.01f) toast("Default compact word spacing applied");
        else if(dpValue<0) toast("Tighter word spacing applied");
        else if(dpValue==0) toast("Normal word spacing applied");
        else toast("Word spacing: "+dpValue);
    }
    void showLineSpacingDialog(){
        rememberFormattingSelection();
        if(editor==null || editor.length()==0){toast("Add text first");return;}
        final String[] labels={"Compact 0.85","Normal 1.00","1.10","1.20","1.30","1.40","1.50","1.60","1.80","2.00"};
        final float[] values={0.85f,1.00f,1.10f,1.20f,1.30f,1.40f,1.50f,1.60f,1.80f,2.00f};
        new AlertDialog.Builder(this).setTitle("Line spacing")
                .setItems(labels,(d,w)->applyLineSpacingToSelection(values[w])).show();
    }
    void applyLineSpacingToSelection(float multiplier){
        if(editor==null)return;
        Editable e=editor.getText();
        if(e.length()==0){toast("Add text first");return;}
        int a=Math.min(formattingStart(),formattingEnd()), b=Math.max(formattingStart(),formattingEnd());
        // With a cursor only, format the current paragraph instead of silently failing.
        if(a==b){
            a=Math.max(0,Math.min(editor.getSelectionStart(),e.length()));
            b=a;
        }
        while(a>0 && e.charAt(a-1)!='\n')a--;
        while(b<e.length() && e.charAt(b)!='\n')b++;
        if(b<e.length())b++; // Include the paragraph break so future typing keeps this format.
        if(a==b){a=0;b=e.length();}
        for(RelativeLineSpacingSpan sp:e.getSpans(a,b,RelativeLineSpacingSpan.class)){
            int ss=e.getSpanStart(sp),se=e.getSpanEnd(sp);
            if(ss<b&&se>a)e.removeSpan(sp);
        }
        // V51: exactly one paragraph span may control a formatted paragraph. Normal
        // removes custom spacing and returns to one stable editor baseline.
        if(Math.abs(multiplier-1f)>0.001f){
            e.setSpan(new RelativeLineSpacingSpan(multiplier),a,b,Spannable.SPAN_PARAGRAPH);
        }
        editor.requestLayout(); editor.invalidate();
        saveCurrentPageState();
        clearFormattingSelection();
        toast("Line spacing: "+String.format(java.util.Locale.US,"%.2f",multiplier));
    }
    void showSizeDialog(){
        rememberFormattingSelection();
        // Exact, non-relative sizes: tapping the same value repeatedly always keeps that exact value.
        final String[] sizes={"12","14","16","18","20","22","24","26","28","30","32","34","36","38","40","42","44","46","48","50","52","54","56","58","60","62","64","66","68","70","72"};
        new AlertDialog.Builder(this).setTitle("Selected text size (12–72)")
                .setItems(sizes,(d,w)->applySizeToSelection(Float.parseFloat(sizes[w]))).show();
    }
    void applySizeToSelection(float size){
        if(editor==null)return;
        // Exact absolute size. Never calculate from the current size, so repeated
        // taps (or typing SPACE/ENTER afterwards) cannot make the font drift.
        size=Math.max(12,Math.min(72,size));
        int a=Math.min(formattingStart(),formattingEnd());
        int b=Math.max(formattingStart(),formattingEnd());
        if(a==b){
            // No selected range: change the active typing size exactly. This is
            // also the size used for new characters until the user changes it.
            editor.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
            if(sizeLabel!=null)sizeLabel.setText("Font "+Math.round(size)+"sp");
            editor.requestLayout();
            toast(Math.round(size)+"sp set for typing");
            return;
        }
        Editable editable=editor.getText();

        // Remove every old absolute/relative size span that intersects the selected range.
        // This prevents 14 -> 12 -> 10 style cumulative scaling bugs.
        for(RelativeSizeSpan span:editable.getSpans(0,editable.length(),RelativeSizeSpan.class)){
            int ss=editable.getSpanStart(span), se=editable.getSpanEnd(span);
            if(ss<b && se>a) editable.removeSpan(span);
        }
        for(AbsoluteSizeSpan span:editable.getSpans(0,editable.length(),AbsoluteSizeSpan.class)){
            int ss=editable.getSpanStart(span), se=editable.getSpanEnd(span);
            if(ss<b && se>a) editable.removeSpan(span);
        }
        editable.setSpan(new AbsoluteSizeSpan(Math.round(size),true),a,b,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        if(sizeLabel!=null)sizeLabel.setText("Font "+Math.round(size)+"sp");
        editor.requestLayout();
        toast(Math.round(size)+"sp applied exactly");
    }
    void chooseAlignment(){new AlertDialog.Builder(this).setTitle("Text Alignment").setItems(new String[]{"Right (Urdu/Arabic)","Center","Left"},(d,w)->{if(w==0){center=false;editor.setGravity(Gravity.TOP|Gravity.RIGHT);}else if(w==1){center=true;applyGravity();}else{center=false;editor.setGravity(Gravity.TOP|Gravity.LEFT);}}).show();}
    void showTextEditDialog(){if(editor==null)return;new AlertDialog.Builder(this).setTitle("Text Edit").setItems(new String[]{"Font","Font Size (pinch with two fingers)","Bold","Italic","Underline selected text","Text Color","Alignment","Copy selected text","Cut selected text","Paste","Delete selected text"},(d,w)->{if(w==0)showFontsDialog();else if(w==1)toast("Use two fingers on the text and pinch in/out");else if(w==2){bold=!bold;applyTypeface();}else if(w==3){italic=!italic;applyTypeface();}else if(w==4)toggleUnderlineSelection();else if(w==5)chooseTextColor();else if(w==6)chooseAlignment();else if(w==7)copySelection(false);else if(w==8)copySelection(true);else if(w==9)pasteClipboard();else deleteSelected();}).show();}
    void toggleUnderlineSelection(){rememberFormattingSelection();int a=formattingStart(),b=formattingEnd();if(a==b){toast("Select text first");return;}Editable e=editor.getText();e.setSpan(new UnderlineSpan(),Math.min(a,b),Math.max(a,b),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);toast("Underline applied");}
    void copySelection(boolean cut){int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a==b){toast("Select text first");return;}String x=editor.getText().subSequence(Math.min(a,b),Math.max(a,b)).toString();android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("text",x));if(cut)editor.getText().delete(Math.min(a,b),Math.max(a,b));toast(cut?"Text cut":"Text copied");}
    void pasteClipboard(){
        if(editor==null)return;
        android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if(cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){
            CharSequence raw=cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            // Paste as plain text deliberately: external apps may put LineHeightSpan/
            // ParagraphStyle formatting in the clipboard, which previously produced
            // huge gaps and unnecessary extra pages in this editor.
            String x=raw==null?"":raw.toString().replace("\r\n","\n").replace('\r','\n');
            // Remove non-printing paragraph separators that can create visually blank lines.
            x=x.replace("\u2028","\n").replace("\u2029","\n").replace("\u00A0"," ");
            int at=Math.max(0,editor.getSelectionStart());
            editor.getText().insert(at,x);
            editor.requestLayout();
            toast("Text pasted with compact default spacing");
        }else toast("Clipboard is empty");
    }
    void selectObject(){showAllObjectsDialog();}
    void toggleLock(){objectLocked=!objectLocked;editor.setEnabled(!objectLocked);if(selectedImage!=null)selectedImage.setClickable(!objectLocked);toast(objectLocked?"Object locked":"Object unlocked");}
    void deleteSelected(){if(objectLocked || (editor!=null && Boolean.TRUE.equals(objectLocks.get(editor)))){toast("Unlock object first");return;}if(selectedDesignObject!=null && !(selectedDesignObject instanceof SelectionEditText)){deleteSelectedDesignObject();return;}if(selectedImage!=null){paper.removeView(selectedImage);designObjects.remove(selectedImage);designObjectNames.remove(selectedImage);selectedImage=null;toast("Selected image deleted");}else{int a=editor.getSelectionStart(),b=editor.getSelectionEnd();if(a!=b){editor.getText().delete(Math.min(a,b),Math.max(a,b));toast("Selected text deleted");}else {new AlertDialog.Builder(this).setMessage("Clear the whole text object?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->editor.setText("")).show();}}}
    void duplicateSelected(){
        if(selectedDesignObject!=null){duplicateSelectedDesignObject();return;}
        if(selectedTextObject!=null||editor!=null){duplicateActiveTextObject();return;}
        toast("Select an object first");
    }
    void togglePageSelection(){pageSelected=!pageSelected;if(pageSelectionOverlay==null){pageSelectionOverlay=new View(this);GradientDrawable gd=new GradientDrawable();gd.setColor((int)0x00000000L);gd.setStroke(dp(3),(int)0xFF1F5F9FL);pageSelectionOverlay.setBackground(gd);paper.addView(pageSelectionOverlay,new FrameLayout.LayoutParams(-1,-1));}pageSelectionOverlay.setVisibility(pageSelected?View.VISIBLE:View.GONE);toast(pageSelected?"Whole page selected — use BG, Border or Page Copy":"Page selection removed");}
    /** Real page/object state: every page owns independent objects, locks, visibility and layer order. */
    static class ObjectState{
        String kind,name,text,imageUri,fontName,spansJson; int left,top,width,height,color,borderType; float textSize,alpha,stroke; boolean locked,visible,fillPage; int gravity;
    }
    static class PageState{String title;int color,w,h;float safe;ArrayList<ObjectState> objects=new ArrayList<>();PageState(String ti,int c,int ww,int hh,float sf){title=ti;color=c;w=ww;h=hh;safe=sf;}}
    /** Returns the page's main text object (prefer the full-page editor). */
    ObjectState getPrimaryTextState(PageState p){
        if(p==null) return null;
        ObjectState first=null;
        for(ObjectState o:p.objects){
            if("text".equals(o.kind)){
                if(first==null) first=o;
                if(o.fillPage) return o;
            }
        }
        return first;
    }
    boolean isPageTextEmpty(PageState p){
        ObjectState o=getPrimaryTextState(p);
        return o==null || o.text==null || o.text.trim().isEmpty();
    }
    ObjectState copyObjectState(ObjectState x){
        if(x==null) return null;
        ObjectState y=new ObjectState();
        y.kind=x.kind;y.name=x.name;y.text=x.text;y.imageUri=x.imageUri;y.fontName=x.fontName;y.spansJson=x.spansJson;
        y.left=x.left;y.top=x.top;y.width=x.width;y.height=x.height;y.color=x.color;
        y.borderType=x.borderType;y.textSize=x.textSize;y.alpha=x.alpha;y.stroke=x.stroke;
        y.locked=x.locked;y.visible=x.visible;y.fillPage=x.fillPage;y.gravity=x.gravity;
        return y;
    }
    void putPrimaryText(PageState p,String value,ObjectState styleSource){
        if(p==null) return;
        ObjectState target=getPrimaryTextState(p);
        if(target==null){
            target=copyObjectState(styleSource);
            if(target==null){
                target=new ObjectState();
                target.kind="text"; target.name="Text"; target.left=0; target.top=0;
                target.width=-1; target.height=-1; target.color=textColor;
                target.textSize=editor==null?TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,DEFAULT_FONT_SIZE_SP,getResources().getDisplayMetrics()):editor.getTextSize();
                target.gravity=Gravity.TOP|Gravity.RIGHT; target.alpha=1f;
                target.visible=true; target.fillPage=true;
            }
            p.objects.add(target);
        }
        target.kind="text";
        target.text=value==null?"":value;
        target.fillPage=true;
    }
    ObjectState snapshotObject(View v){
        ObjectState o=new ObjectState(); FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();
        o.left=lp.leftMargin;o.top=lp.topMargin;o.width=lp.width;o.height=lp.height;o.alpha=v.getAlpha();o.locked=Boolean.TRUE.equals(objectLocks.get(v));o.visible=v.getVisibility()==View.VISIBLE;o.name=designObjectNames.get(v);o.kind="shape";
        if(v instanceof SelectionEditText){SelectionEditText e=(SelectionEditText)v;o.kind="text";o.text=e.getText().toString();o.textSize=e.getTextSize();o.color=e.getCurrentTextColor();o.gravity=e.getGravity();o.fontName=textObjectFontNames.get(e);if(o.fontName==null)o.fontName=currentFontName;o.spansJson=serializeTypefaceSpans(e);o.fillPage=(v==primaryEditor || (lp.width==-1&&lp.height==-1));}
        else if(v instanceof BorderView){BorderView b=(BorderView)v;o.kind="border";o.borderType=b.type;o.stroke=b.strokeMultiplier;}
        else if(v instanceof ImageView){o.kind="image";o.imageUri=imageSources.get(v);}
        else if(v instanceof TextView){TextView t=(TextView)v;o.kind="element";o.text=t.getText().toString();o.textSize=t.getTextSize();o.color=t.getCurrentTextColor();o.gravity=t.getGravity();}
        return o;
    }
    PageState capturePage(){
        PageState p=new PageState(title==null?"Untitled":title.getText().toString(),paperColor,pageW,pageH,borderSafeDp);
        if(paper!=null)for(int i=0;i<paper.getChildCount();i++){View v=paper.getChildAt(i);if(v==selectionOverlay||v==pageSelectionOverlay)continue;if(v instanceof SelectionEditText||designObjects.contains(v))p.objects.add(snapshotObject(v));}
        return p;
    }
    void saveCurrentPageState(){if(editor==null)return;PageState p=capturePage();if(pages.size()==0)pages.add(p);else if(currentPage<pages.size())pages.set(currentPage,p);}
    void clearPageObjectsForRestore(){
        clearSelectionOutline(); for(int i=paper.getChildCount()-1;i>=0;i--){View v=paper.getChildAt(i);if(v!=pageSelectionOverlay)paper.removeViewAt(i);} textObjects.clear();textObjectFontNames.clear();designObjects.clear();designObjectNames.clear();objectLocks.clear();objectVisibility.clear();imageSources.clear();primaryEditor=null;editor=null;selectedTextObject=null;selectedDesignObject=null;selectedImage=null;
    }
    void restoreObject(ObjectState o){
        if("border".equals(o.kind)){BorderView b=new BorderView(this,o.borderType,borderSafeDp);b.strokeMultiplier=o.stroke<=0?1f:o.stroke;b.setTag("border");paper.addView(b,0,new FrameLayout.LayoutParams(-1,-1));designObjects.add(b);designObjectNames.put(b,"Border / Frame");objectLocks.put(b,o.locked);objectVisibility.put(b,o.visible);b.setVisibility(o.visible?View.VISIBLE:View.INVISIBLE);return;}
        if("text".equals(o.kind)){SelectionEditText e=createTextObject(o.text==null?"":o.text,o.left,o.top,o.fillPage);String fn=o.fontName==null||o.fontName.trim().isEmpty()?currentFontName:o.fontName;Typeface tf=typefaces.get(fn);if(tf==null)tf=Typeface.DEFAULT;e.setTypeface(tf);textObjectFontNames.put(e,fn);FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)e.getLayoutParams();lp.width=o.width;lp.height=o.height;lp.leftMargin=o.left;lp.topMargin=o.top;e.setLayoutParams(lp);e.setTextSize(TypedValue.COMPLEX_UNIT_PX,o.textSize>0?o.textSize:e.getTextSize());e.setTextColor(o.color);e.setGravity(o.gravity);e.setAlpha(o.alpha);restoreTypefaceSpans(e,o.spansJson);objectLocks.put(e,o.locked);objectVisibility.put(e,o.visible);e.setVisibility(o.visible?View.VISIBLE:View.INVISIBLE);if(o.fillPage)primaryEditor=e;return;}
        View v;
        if("image".equals(o.kind)){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);try{if(o.imageUri!=null){InputStream in=getContentResolver().openInputStream(Uri.parse(o.imageUri));iv.setImageBitmap(BitmapFactory.decodeStream(in));if(in!=null)in.close();imageSources.put(iv,o.imageUri);}}catch(Exception ignored){}v=iv;}
        else if("element".equals(o.kind)){TextView t=new TextView(this);t.setText(o.text);t.setTextSize(TypedValue.COMPLEX_UNIT_PX,o.textSize);t.setTextColor(o.color);t.setGravity(o.gravity);v=t;}
        else {v=new View(this);v.setBackground(bg(BLUE2,12));}
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(o.width,o.height);lp.leftMargin=o.left;lp.topMargin=o.top;paper.addView(v,lp);registerDesignObject(v,o.name==null?"Design Object":o.name);v.setAlpha(o.alpha);objectLocks.put(v,o.locked);objectVisibility.put(v,o.visible);v.setVisibility(o.visible?View.VISIBLE:View.INVISIBLE);
    }
    void loadPageState(int index){
        if(index<0||index>=pages.size())return;
        changing=true;
        PageState p=pages.get(index);
        currentPage=index; pageW=p.w; pageH=p.h; paperColor=p.color; borderSafeDp=p.safe;
        title.setText(p.title); paper.setBackgroundColor(paperColor);
        clearPageObjectsForRestore();
        for(ObjectState o:p.objects)restoreObject(o);
        if(primaryEditor==null){primaryEditor=createTextObject("",0,0,true);}
        editor=primaryEditor;
        if(editor!=null){String fn=textObjectFontNames.get(editor);if(fn!=null){currentFontName=fn;currentTypeface=typefaces.get(fn);if(currentTypeface==null)currentTypeface=Typeface.DEFAULT;if(fontSpinner!=null){int fi=fontNames.indexOf(fn);if(fi>=0){suppressFontSpinnerCallback=true;fontSpinner.setSelection(fi);suppressFontSpinnerCallback=false;}}}}
        choosePageSilent(); updatePrimaryEditorSafeArea();
        changing=false;
        if(contextBar!=null)showPageTools();
        toast("Page "+(currentPage+1)+" of "+pages.size()+" restored with all objects");
    }

    /** Single safe entry point for explicit page changes. */
    void navigateToPage(int target){
        if(target<0 || target>=pages.size())return;
        if(target==currentPage){showPageTools();return;}
        activatePageMode();
        saveCurrentPageState();
        loadPageState(target);
    }
    void goToPreviousPage(){
        if(currentPage<=0){toast("Already on Page 1");return;}
        navigateToPage(currentPage-1);
    }
    void goToNextPage(){
        if(currentPage>=pages.size()-1){toast("Already on the last page");return;}
        navigateToPage(currentPage+1);
    }

    /** Direct Page 1 ↔ Page 3 jump without hunting through the tool strip. */
    void showPageJumpDialog(){
        if(pages.isEmpty())return;
        final EditText input=new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true); input.setSelectAllOnFocus(true);
        input.setText(String.valueOf(currentPage+1));
        input.setHint("1 - "+pages.size());
        LinearLayout wrap=new LinearLayout(this);
        int pad=dp(20); wrap.setPadding(pad,dp(6),pad,0);
        wrap.addView(input,new LinearLayout.LayoutParams(-1,dp(56)));
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("Go to Page")
                .setMessage("Enter a page number from 1 to "+pages.size())
                .setView(wrap).setNegativeButton("Cancel",null)
                .setPositiveButton("Go",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{
                int page=Integer.parseInt(input.getText().toString().trim())-1;
                if(page<0 || page>=pages.size()){input.setError("Enter 1 to "+pages.size());return;}
                dialog.dismiss(); navigateToPage(page);
            }catch(Exception e){input.setError("Enter a valid page number");}
        }));
        dialog.show(); input.requestFocus(); input.setSelection(input.length());
        input.postDelayed(()->{InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); if(imm!=null)imm.showSoftInput(input,InputMethodManager.SHOW_IMPLICIT);},150);
    }

    void addNewPage(){
        saveCurrentPageState();
        PageState base=pages.isEmpty()?null:pages.get(currentPage);
        PageState blank=new PageState("Untitled Page "+(pages.size()+1),base==null?Color.WHITE:base.color,base==null?595:base.w,base==null?842:base.h,base==null?CONTENT_SAFE_DP:base.safe);
        ObjectState style=base==null?null:getPrimaryTextState(base);
        putPrimaryText(blank,"",style);
        pages.add(currentPage+1,blank);loadPageState(currentPage+1);
    }
    void switchPageDialog(){saveCurrentPageState();String[] names=new String[pages.size()];for(int i=0;i<pages.size();i++)names[i]="Page "+(i+1)+(i==currentPage?" ✓":"");new AlertDialog.Builder(this).setTitle("Multiple Pages • Real Object State").setItems(names,(d,w)->navigateToPage(w)).setNegativeButton("Cancel",null).setPositiveButton("+ New Page",(d,w)->addNewPage()).show();}
    void duplicatePage(){saveCurrentPageState();PageState src=pages.get(currentPage);PageState cp=new PageState(src.title+" Copy",src.color,src.w,src.h,src.safe);for(ObjectState x:src.objects){ObjectState y=new ObjectState();y.kind=x.kind;y.name=x.name;y.text=x.text;y.imageUri=x.imageUri;y.fontName=x.fontName;y.spansJson=x.spansJson;y.left=x.left;y.top=x.top;y.width=x.width;y.height=x.height;y.color=x.color;y.borderType=x.borderType;y.textSize=x.textSize;y.alpha=x.alpha;y.stroke=x.stroke;y.locked=x.locked;y.visible=x.visible;y.fillPage=x.fillPage;y.gravity=x.gravity;cp.objects.add(y);}pages.add(currentPage+1,cp);loadPageState(currentPage+1);toast("Page duplicated with independent objects");}
    void showPageEditDialog(){new AlertDialog.Builder(this).setTitle("Page Edit — Page "+(currentPage+1)+" / "+Math.max(1,pages.size())).setItems(new String[]{"Background Color","Background Transparency","Border / Frame","Page Size & Orientation","Multiple Pages / Switch","+ Add New Page","Duplicate Current Page","Delete Current Page"},(d,w)->{if(w==0)choosePaperColor();else if(w==1)choosePageTransparency();else if(w==2)chooseBorder();else if(w==3)choosePage();else if(w==4)switchPageDialog();else if(w==5)addNewPage();else if(w==6)duplicatePage();else deleteCurrentPage();}).show();}
    void choosePageTransparency(){final String[] a={"100% Opaque","85%","70%","55%","40%"};new AlertDialog.Builder(this).setTitle("Page Transparency").setItems(a,(d,w)->{int alpha=255-w*38;paper.setAlpha(Math.max(.4f,alpha/255f));toast(a[w]+" selected");}).show();}
    void deleteCurrentPage(){if(pages.size()<=1){toast("At least one page is required");return;}pages.remove(currentPage);if(currentPage>=pages.size())currentPage=pages.size()-1;loadPageState(currentPage);}
    void chooseBorder(){String[] a={"No Border","Gold Corner Border","Blue Corner Border","Double Frame","Islamic Green Frame","Elegant Triple Gold","Royal Purple Frame","Modern Black Line","Red Certificate Frame","Teal Geometric","Islamic Arch Frame","Dotted Gold Frame","Classic Double Blue","Leaf Corner Frame","Minimal Gray Frame"};new AlertDialog.Builder(this).setTitle("Professional Border Library • Print Safe").setItems(a,(d,w)->applyBorder(w)).show();}
    void applyBorder(int type){
        if(paper==null)return;
        clearSelectionOutline();
        View old=paper.findViewWithTag("border");
        if(old!=null){
            paper.removeView(old); designObjects.remove(old); designObjectNames.remove(old); objectLocks.remove(old);
            if(selectedDesignObject==old)selectedDesignObject=null;
        }
        if(type==0){ updatePrimaryEditorSafeArea(); activatePageMode(); toast("Border removed"); return; }
        BorderView bv=new BorderView(this,type,borderSafeDp);
        bv.setTag("border"); bv.setClickable(false); bv.setFocusable(false); bv.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        // Border is always layer 0. Content is always above it, therefore border drawing can never hide text/cursor.
        paper.addView(bv,0,new FrameLayout.LayoutParams(-1,-1));
        designObjects.add(bv); designObjectNames.put(bv,"Border / Frame"); objectLocks.put(bv,false);
        updatePrimaryEditorSafeArea();
        selectedDesignObject=bv; selectedTextObject=null; objectSelectionMode=true;
        showSelectionOutline(bv);
        if(contextBar!=null) showSelectedObjectTools();
        toast("Border applied • locked behind content • print-safe area synchronized");
    }
    void showImageTools(){if(selectedImage==null && selectedDesignObject instanceof ImageView)selectedImage=(ImageView)selectedDesignObject;if(selectedImage==null){toast("Select an image first");return;}new AlertDialog.Builder(this).setTitle("Image Tools").setItems(new String[]{"＋ Increase Size","－ Decrease Size","Fit to Page","Original / Medium Size","Bring to Front","Center on Page","Delete Image"},(d,w)->{if(w==0)resizeSelectedImage(1.15f);else if(w==1)resizeSelectedImage(.85f);else if(w==2)fitSelectedImageToPage();else if(w==3)setSelectedImageMedium();else if(w==4){selectedImage.bringToFront();toast("Image brought to front");}else if(w==5)centerSelectedImage();else deleteSelected();}).show();}
    void resizeSelectedImage(float factor){if(selectedImage==null)return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)selectedImage.getLayoutParams();int maxW=Math.max(dp(80),paper.getWidth()-dp(24)),maxH=Math.max(dp(80),paper.getHeight()-dp(24));lp.width=Math.max(dp(60),Math.min(maxW,Math.round(lp.width*factor)));lp.height=Math.max(dp(60),Math.min(maxH,Math.round(lp.height*factor)));selectedImage.setLayoutParams(lp);selectedImage.bringToFront();toast("Image size updated");}
    void fitSelectedImageToPage(){if(selectedImage==null)return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)selectedImage.getLayoutParams();lp.width=Math.max(dp(80),paper.getWidth()-dp(28));lp.height=Math.max(dp(80),paper.getHeight()-dp(28));lp.leftMargin=dp(14);lp.topMargin=dp(14);selectedImage.setLayoutParams(lp);selectedImage.setScaleType(ImageView.ScaleType.FIT_CENTER);selectedImage.bringToFront();toast("Image fitted to page");}
    void setSelectedImageMedium(){if(selectedImage==null)return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)selectedImage.getLayoutParams();lp.width=Math.min(dp(260),Math.max(dp(120),paper.getWidth()-dp(40)));lp.height=Math.min(dp(220),Math.max(dp(100),paper.getHeight()/3));lp.leftMargin=Math.max(dp(8),(paper.getWidth()-lp.width)/2);lp.topMargin=dp(28);selectedImage.setLayoutParams(lp);selectedImage.setScaleType(ImageView.ScaleType.FIT_CENTER);selectedImage.bringToFront();toast("Image size reset");}
    void centerSelectedImage(){if(selectedImage==null)return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)selectedImage.getLayoutParams();lp.leftMargin=Math.max(0,(paper.getWidth()-lp.width)/2);lp.topMargin=Math.max(0,(paper.getHeight()-lp.height)/2);selectedImage.setLayoutParams(lp);selectedImage.bringToFront();toast("Image centered");}
    void makeDraggable(final View v){
        v.setOnTouchListener(new View.OnTouchListener(){float dx,dy,sx,sy,paperX,paperY;boolean moved;
            public boolean onTouch(View q,MotionEvent e){
                if(objectLocked || Boolean.TRUE.equals(objectLocks.get(q))) { toast("Unlock this object first"); return false; } FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)q.getLayoutParams();
                int[] pos=new int[2]; paper.getLocationOnScreen(pos); paperX=pos[0]; paperY=pos[1];
                if(e.getAction()==MotionEvent.ACTION_DOWN){
                    dx=e.getRawX()-paperX-lp.leftMargin;dy=e.getRawY()-paperY-lp.topMargin;sx=e.getRawX();sy=e.getRawY();moved=false;
                    selectDesignObject(q); return true;
                }
                if(e.getAction()==MotionEvent.ACTION_MOVE){
                    float dist=Math.abs(e.getRawX()-sx)+Math.abs(e.getRawY()-sy);if(dist>dp(4))moved=true;
                    lp.leftMargin=(int)(e.getRawX()-paperX-dx);
                    lp.topMargin=(int)(e.getRawY()-paperY-dy);
                    clampObjectToAllowedArea(q,lp);
                    q.setLayoutParams(lp);if(q==selectedDesignObject)showSelectionOutline(q);return true;
                }
                if(e.getAction()==MotionEvent.ACTION_UP){if(!moved){selectDesignObject(q);}return true;} return true;
            }});
    }
    String getDisplayName(Uri uri){Cursor c=getContentResolver().query(uri,null,null,null,null);if(c!=null){try{int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0)return c.getString(i);}finally{c.close();}}return "font_"+System.currentTimeMillis()+".ttf";}
    /** Clear, non-blocking blue selection frame around the exact selected object. */
    void showSelectionOutline(final View target){
        if(paper==null||target==null)return;
        clearSelectionOutline();
        selectionOverlay=new View(this){
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            protected void onDraw(Canvas c){
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
                p.setColor((int)0xFF1976D2L);
                float d=dp(2); c.drawRect(d,d,getWidth()-d,getHeight()-d,p);
            }
        };
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)target.getLayoutParams();
        int w=target.getWidth()>0?target.getWidth():lp.width;
        int h=target.getHeight()>0?target.getHeight():lp.height;
        if(w==FrameLayout.LayoutParams.MATCH_PARENT||w<1)w=Math.max(1,paper.getWidth()-target.getLeft()-Math.max(0,lp.rightMargin));
        if(h==FrameLayout.LayoutParams.MATCH_PARENT||h<1)h=Math.max(1,paper.getHeight()-target.getTop()-Math.max(0,lp.bottomMargin));
        int l=target.getLeft(), t=target.getTop();
        selectionOverlay.layout(l,t,l+Math.max(1,w),t+Math.max(1,h));
        paper.getOverlay().add(selectionOverlay);
        target.post(()->{
            if(selectionOverlay!=null && (target==selectedDesignObject || target==selectedTextObject)){
                try{
                    paper.getOverlay().remove(selectionOverlay);
                    int x=target.getLeft(), y=target.getTop(), r=target.getRight(), b=target.getBottom();
                    selectionOverlay.layout(x,y,Math.max(x+1,r),Math.max(y+1,b));
                    paper.getOverlay().add(selectionOverlay);
                }catch(Exception ignored){}
            }
        });
    }
    void clearSelectionOutline(){if(selectionOverlay!=null&&paper!=null){try{paper.getOverlay().remove(selectionOverlay);}catch(Exception ignored){} selectionOverlay=null;}}
    void showBorderStrokeWidthDialog(){
        View old=paper==null?null:paper.findViewWithTag("border"); if(!(old instanceof BorderView)){toast("Select a border first");return;}
        final BorderView bv=(BorderView)old; final SeekBar sb=new SeekBar(this);sb.setMax(8);sb.setProgress(Math.max(0,Math.min(8,Math.round((bv.strokeMultiplier-.5f)*4))));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);TextView info=text("Line thickness: adjustable",12);box.addView(info);box.addView(sb);
        new AlertDialog.Builder(this).setTitle("Border Line Width").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{bv.strokeMultiplier=.5f+sb.getProgress()/4f;bv.invalidate();toast("Border line width updated");}).show();
    }
    void showBorderSafeWidthDialog(){
        View old=paper==null?null:paper.findViewWithTag("border"); if(!(old instanceof BorderView)){toast("Select a border first");return;}
        final BorderView bv=(BorderView)old;
        final SeekBar sb=new SeekBar(this); int max=(int)(CONTENT_SAFE_DP-MIN_SAFE_DP); sb.setMax(max); sb.setProgress(Math.max(0,Math.round(CONTENT_SAFE_DP-borderSafeDp)));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        TextView info=text("Safe margin: "+(int)borderSafeDp+"dp (you can only reduce inward margin)",12);box.addView(info);box.addView(sb);
        new AlertDialog.Builder(this).setTitle("Border Safe Width").setMessage("Default print-safe margin cannot be increased; it can only be reduced. Writing area updates with the border.").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{borderSafeDp=Math.max(MIN_SAFE_DP,CONTENT_SAFE_DP-sb.getProgress());bv.insetDp=borderSafeDp;bv.invalidate();updatePrimaryEditorSafeArea();if(selectedTextObject!=null)showSelectionOutline(selectedTextObject);else if(selectedDesignObject!=null)showSelectionOutline(selectedDesignObject);toast("Border and writing safe area updated together");}).show();
    }
    void updatePrimaryEditorSafeArea(){
        if(paper==null)return;
        int safe=dp(borderSafeDp+CONTENT_GAP_DP);
        for(SelectionEditText e:textObjects){
            if(e==null||e.getParent()!=paper)continue;
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)e.getLayoutParams();
            if(e==primaryEditor || (lp.width==FrameLayout.LayoutParams.MATCH_PARENT && lp.height==FrameLayout.LayoutParams.MATCH_PARENT)){
                lp.leftMargin=safe; lp.topMargin=safe; lp.rightMargin=safe; lp.bottomMargin=safe;
            }else{
                int w=e.getWidth()>0?e.getWidth():lp.width, h=e.getHeight()>0?e.getHeight():lp.height;
                int maxL=Math.max(safe,paper.getWidth()-safe-Math.max(1,w));
                int maxT=Math.max(safe,paper.getHeight()-safe-Math.max(1,h));
                lp.leftMargin=Math.max(safe,Math.min(maxL,lp.leftMargin));
                lp.topMargin=Math.max(safe,Math.min(maxT,lp.topMargin));
            }
            e.setLayoutParams(lp);
        }
    }
    void toggleSelectedObjectLock(){View v=selectedDesignObject!=null?selectedDesignObject:selectedTextObject;if(v==null){toast("Select an object first");return;}boolean n=!Boolean.TRUE.equals(objectLocks.get(v));objectLocks.put(v,n);toast(n?"Object locked":"Object unlocked");}
    void setAllObjectsLocked(boolean locked){for(SelectionEditText e:textObjects)objectLocks.put(e,locked);for(View v:designObjects)objectLocks.put(v,locked);toast(locked?"All objects locked":"All objects unlocked");}

    /** V36: borders stay inside the printer-safe area to reduce edge clipping. */
    public static class BorderView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);int type;float den;
        float insetDp; float strokeMultiplier=1f; BorderView(Context c,int t,float safe){super(c);type=t;den=c.getResources().getDisplayMetrics().density;insetDp=safe;}
        protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(),h=getHeight();
            float in=Math.max(insetDp*den,Math.min(w,h)*0.018f);
            float in2=in+Math.max(10*den,Math.min(w,h)*0.016f);
            int[] col={
                (int)0xFFC59A32L, // 1 Gold Corner
                (int)0xFF1F5F9FL, // 2 Blue Corner
                (int)0xFFC59A32L, // 3 Double Gold
                (int)0xFF178B54L, // 4 Islamic Green
                (int)0xFFD4A72CL, // 5 Triple Gold
                (int)0xFF7046A5L, // 6 Purple
                (int)0xFF263238L, // 7 Black
                (int)0xFFB43A34L, // 8 Red
                (int)0xFF16808AL, // 9 Teal
                (int)0xFF178B54L, // 10 Arch Green
                (int)0xFFC59A32L, // 11 Dotted Gold
                (int)0xFF1F5F9FL, // 12 Double Blue
                (int)0xFF5F7A3CL, // 13 Leaf
                (int)0xFF64748BL  // 14 Gray
            };
            int ix=Math.max(1,Math.min(type,col.length))-1;
            p.setColor(col[ix]); p.setStyle(Paint.Style.STROKE); p.setPathEffect(null);
            float thin=Math.max(1.2f*den,2.5f*den*strokeMultiplier), thick=Math.max(2*den,4*den*strokeMultiplier);
            if(type==11){
                p.setStrokeWidth(thin); p.setPathEffect(new android.graphics.DashPathEffect(new float[]{8*den,6*den},0));
                c.drawRect(in,in,w-in,h-in,p); p.setPathEffect(null); return;
            }
            if(type==10){
                p.setStrokeWidth(thin); c.drawRect(in,in,w-in,h-in,p);
                float cx=w/2f; c.drawArc(cx-70*den,in-18*den,cx+70*den,in+90*den,180,180,false,p); return;
            }
            if(type==13){
                p.setStrokeWidth(thin); c.drawRect(in,in,w-in,h-in,p);
                float r=10*den; c.drawCircle(in+12*den,in+12*den,r,p); c.drawCircle(w-in-12*den,in+12*den,r,p);
                c.drawCircle(in+12*den,h-in-12*den,r,p); c.drawCircle(w-in-12*den,h-in-12*den,r,p); return;
            }
            if(type==14){ p.setStrokeWidth(thin); c.drawRect(in,in,w-in,h-in,p); return; }
            if(type==3 || type==4 || type==8 || type==12){
                p.setStrokeWidth(thick); c.drawRect(in,in,w-in,h-in,p);
                p.setStrokeWidth(thin); c.drawRect(in2,in2,w-in2,h-in2,p); return;
            }
            if(type==5){
                p.setStrokeWidth(thick); c.drawRect(in,in,w-in,h-in,p);
                p.setStrokeWidth(thin); c.drawRect(in2,in2,w-in2,h-in2,p);
                float q=in2+12*den; c.drawRect(q,q,w-q,h-q,p); return;
            }
            p.setStrokeWidth(thin); c.drawRect(in,in,w-in,h-in,p);
            if(type==1 || type==2 || type==6 || type==9){
                float z=28*den; p.setStrokeWidth(thick);
                c.drawLine(in,in,in+z,in,p); c.drawLine(in,in,in,in+z,p);
                c.drawLine(w-in,in,w-in-z,in,p); c.drawLine(w-in,in,w-in,in+z,p);
                c.drawLine(in,h-in,in+z,h-in,p); c.drawLine(in,h-in,in,h-in-z,p);
                c.drawLine(w-in,h-in,w-in-z,h-in,p); c.drawLine(w-in,h-in,w-in,h-in-z,p);
                if(type==9){ float m=14*den; c.drawLine(in+m,in,w-in-m,h-in,p); c.drawLine(w-in-m,in,in+m,h-in,p); }
            }
        }
    }


    void chooseTextColor(){rememberFormattingSelection();chooseColor("Text Color — 30+ shades",new int[]{Color.BLACK,(int)0xFF182638L,(int)0xFF334155L,(int)0xFF64748BL,(int)0xFF073B73L,(int)0xFF1F5F9FL,(int)0xFF2563EBL,(int)0xFF0EA5E9L,(int)0xFF06B6D4L,(int)0xFF116B4DL,(int)0xFF178B54L,(int)0xFF22C55EL,(int)0xFF65A30DL,(int)0xFFB43A34L,(int)0xFFDC2626L,(int)0xFFF97316L,(int)0xFFD69A21L,(int)0xFFEAB308L,(int)0xFF8B1E3FL,(int)0xFFBE123CL,(int)0xFFE11D48L,(int)0xFFDB2777L,(int)0xFF6A3D9AL,(int)0xFF7046A5L,(int)0xFF7C3AEDL,(int)0xFF4F46E5L,(int)0xFF7C2D12L,(int)0xFF92400EL,(int)0xFF78350FL,(int)0xFFFFFFFFL},c->{int a=formattingStart(),b=formattingEnd();if(a!=b){editor.getText().setSpan(new ForegroundColorSpan(c),Math.min(a,b),Math.max(a,b),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);}else{ textColor=c;editor.setTextColor(c); }});}
    void choosePaperColor(){chooseColor("Page Background",new int[]{Color.WHITE,(int)0xFFFFFDF8L,(int)0xFFF7F0E2L,(int)0xFFEFF6FFL,(int)0xFFF4EFFAL,(int)0xFFF2F5F7L,(int)0xFFFDF2F8L,(int)0xFFF0FDF4L,(int)0xFFFFFBEBL,(int)0xFFEFF6FFL},c->{paperColor=c;paper.setBackgroundColor(c);});}
    interface ColorPick{void pick(int c);} void chooseColor(String title,int[] cs,ColorPick cb){String[] base={"Black","Navy","Slate","Gray","Deep Blue","Blue","Royal Blue","Sky","Cyan","Deep Green","Green","Bright Green","Olive","Red","Crimson","Orange","Gold","Yellow","Maroon","Dark Red","Rose","Pink","Purple","Violet","Indigo","Deep Indigo","Brown","Warm Brown","Dark Brown","White","Cream","Ivory","Blue Mist","Lavender","Soft Gray"};String[] names=new String[cs.length];for(int i=0;i<cs.length;i++)names[i]=i<base.length?base[i]:"Color "+(i+1);new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,w)->cb.pick(cs[w])).show();}
    void choosePage(){new AlertDialog.Builder(this).setTitle("Page Setup").setItems(new String[]{"A4 Portrait","A4 Landscape","A5 Portrait","Letter Portrait"},(d,w)->{if(w==1){pageW=842;pageH=595;}else if(w==2){pageW=420;pageH=595;}else if(w==3){pageW=612;pageH=792;}else{pageW=595;pageH=842;}choosePageSilent();saveCurrentPageState();Toast.makeText(this,"Page updated",Toast.LENGTH_SHORT).show();}).show();}
    void chooseTemplate(){String[] a={"Blank Document","Islamic Notice","Character Certificate","Simple Poster","Islamic Poster","Madrasa Certificate","Elegant Gold Page","Corner Arrow Page","Modern Blue Frame"};new AlertDialog.Builder(this).setTitle("Professional Template Library").setItems(a,(d,w)->{if(editor==null)buildEditor();String t="";paperColor=Color.WHITE;if(w==1){t="اعلان\n\nتمام طلبہ و طالبات کو مطلع کیا جاتا ہے کہ\n\n________________________________\n\nتاریخ: __________";applyBorder(4);}else if(w==2){t="کردار نامہ\n\nیہ تصدیق کی جاتی ہے کہ\n\n________________________________\n\nنے ہمارے ادارے میں اچھے اخلاق اور بہترین کردار کا مظاہرہ کیا ہے۔\n\nدستخط: __________";applyBorder(3);}else if(w==3){t="بسم اللہ الرحمن الرحیم\n\nعنوان یہاں لکھیں\n\nاپنا خوبصورت پیغام یہاں تحریر کریں";applyBorder(2);}else if(w==4){t="بسم اللہ الرحمن الرحیم\n\nاسلامی پوسٹر\n\nاپنا پیغام یہاں تحریر کریں";paperColor=(int)0xFFFFFDF8L;applyBorder(4);}else if(w==5){t="دارالتحفیظ للقرآن الکریم\n\nاعزازی سند\n\nیہ سند __________ کو دی جاتی ہے";paperColor=(int)0xFFF7F0E2L;applyBorder(1);}else if(w==6){t="بسم اللہ الرحمن الرحیم\n\nخوبصورت اردو ڈیزائن\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFFFFCF4L;applyBorder(1);}else if(w==7){t="عنوان\n\nاپنا پیغام یہاں لکھیں";applyBorder(2);}else if(w==8){t="PROFESSIONAL PAGE\n\nاپنا متن یہاں لکھیں";paperColor=(int)0xFFEFF6FFL;applyBorder(2);}else applyBorder(0);paper.setBackgroundColor(paperColor);changing=true;editor.setText(t);changing=false;undoStack.clear();undoStack.add(t);toast("Template loaded");}).show();}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,105);}
    void importFont(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,101);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;try{Uri u=d.getData();if(r==105&&u!=null&&Build.VERSION.SDK_INT>=19){try{getContentResolver().takePersistableUriPermission(u,d.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Exception ignored){}}if(r==101){String original=getDisplayName(u);String lower=original.toLowerCase(Locale.ROOT);if(!(lower.endsWith(".ttf")||lower.endsWith(".otf"))){toast("Please select a TTF or OTF font");return;}File out=new File(fontDir,original.replaceAll("[^a-zA-Z0-9._ -]","_") );copy(u,out);Typeface test=Typeface.createFromFile(out);loadFonts();Toast.makeText(this,"Font imported and activated: "+original,Toast.LENGTH_LONG).show();if(fontSpinner!=null){ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames);fontSpinner.setAdapter(a);int ix=fontNames.indexOf(out.getName());if(ix>=0)fontSpinner.setSelection(ix);}}else if(r==102){writeJson(u);toast("Document saved");}else if(r==103){openJson(u);}else if(r==104){createPdf(u);toast("PDF created successfully");}else if(r==105){InputStream in=getContentResolver().openInputStream(u);pageImage=BitmapFactory.decodeStream(in);if(in!=null)in.close();if(pageImage!=null&&paper!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(pageImage);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);iv.setAdjustViewBounds(true);iv.setAlpha(1f);int iw=Math.min(dp(260),Math.max(dp(140),paper.getWidth()-dp(40)));int ih=Math.min(dp(220),Math.max(dp(120),paper.getHeight()/3));FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(iw,ih);ip.leftMargin=Math.max(dp(10),(paper.getWidth()-iw)/2);ip.topMargin=dp(24);paper.addView(iv,ip);iv.bringToFront();registerDesignObject(iv,"Image");imageSources.put(iv,u.toString());selectedImage=iv;selectedDesignObject=iv;toast("Image added — tap to select, then edit/duplicate/delete");showSelectedObjectTools();}}}catch(Exception e){toast("Operation failed: "+e.getMessage());}}
    void copy(Uri u,File out)throws Exception{InputStream in=getContentResolver().openInputStream(u);FileOutputStream fo=new FileOutputStream(out);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)fo.write(b,0,n);in.close();fo.close();}
    void showFontsDialog(){
        rememberFormattingSelection();
        loadFonts();
        new AlertDialog.Builder(this).setTitle("Available Fonts")
            .setItems(fontNames.toArray(new String[0]),(d,w)->{
                if(w>=0 && w<fontNames.size()){
                    currentFontName=fontNames.get(w);
                    currentTypeface=typefaces.get(currentFontName);
                    if(currentTypeface==null) currentTypeface=Typeface.DEFAULT;
                    applyTypeface();
                    if(fontSpinner!=null){ suppressFontSpinnerCallback=true; fontSpinner.setSelection(w); suppressFontSpinnerCallback=false; }
                    toast("Font applied: "+currentFontName);
                }
            })
            .setPositiveButton("Import Font",(d,w)->importFont()).show();
    }
    void saveDocument(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".json");startActivityForResult(i,102);}String safeName(String s){return s.replaceAll("[^a-zA-Z0-9_\\- ]","_").trim().replaceAll(" +","_");}

    // IMPORTANT: EditText.getTextSize() returns PIXELS, while setTextSize(float)
    // interprets its value as SP. Saving pixels and loading them as SP was the
    // cause of the V21 "save -> open -> text becomes huge" bug.
    float pxToSp(float px){return px/getResources().getDisplayMetrics().scaledDensity;}

    org.json.JSONArray saveTextSpans()throws Exception{
        org.json.JSONArray out=new org.json.JSONArray();
        if(editor==null)return out;
        Editable e=editor.getText();
        for(Object span:e.getSpans(0,e.length(),Object.class)){
            int a=e.getSpanStart(span),b=e.getSpanEnd(span);
            if(a<0||b<=a)continue;
            org.json.JSONObject x=new org.json.JSONObject();x.put("start",a);x.put("end",b);
            if(span instanceof LocalTypefaceSpan){x.put("type","fontRange");x.put("font",((LocalTypefaceSpan)span).fontName);}
            else if(span instanceof WordSpacingSpan){x.put("type","wordSpacing");x.put("value",((WordSpacingSpan)span).extraPx);}
            else if(span instanceof RelativeLineSpacingSpan){x.put("type","lineSpacing");x.put("value",((RelativeLineSpacingSpan)span).multiplier);}
            else if(span instanceof AbsoluteSizeSpan){AbsoluteSizeSpan z=(AbsoluteSizeSpan)span;x.put("type","size");x.put("value",z.getSize());x.put("dip",true);}
            else if(span instanceof ForegroundColorSpan){x.put("type","color");x.put("value",((ForegroundColorSpan)span).getForegroundColor());}
            else if(span instanceof StyleSpan){x.put("type","style");x.put("value",((StyleSpan)span).getStyle());}
            else if(span instanceof UnderlineSpan){x.put("type","underline");}
            else continue;
            out.put(x);
        }
        return out;
    }

    void restoreTextSpans(org.json.JSONArray arr){
        if(arr==null||editor==null)return;
        Editable e=editor.getText();
        for(int i=0;i<arr.length();i++)try{
            org.json.JSONObject x=arr.getJSONObject(i);int a=Math.max(0,x.optInt("start",0)),b=Math.min(e.length(),x.optInt("end",0));if(b<=a)continue;
            String type=x.optString("type","");Object span=null;
            if("fontRange".equals(type)){String fn=x.optString("font","System Urdu");Typeface tf=typefaces.get(fn);if(tf==null)tf=Typeface.DEFAULT;span=new LocalTypefaceSpan(tf,fn);}
            else if("wordSpacing".equals(type))span=new WordSpacingSpan((float)x.optDouble("value",0));
            else if("lineSpacing".equals(type))span=new RelativeLineSpacingSpan((float)x.optDouble("value",1));
            else if("size".equals(type))span=new AbsoluteSizeSpan(x.optInt("value",14),x.optBoolean("dip",true));
            else if("color".equals(type))span=new ForegroundColorSpan(x.optInt("value",textColor));
            else if("style".equals(type))span=new StyleSpan(x.optInt("value",Typeface.NORMAL));
            else if("underline".equals(type))span=new UnderlineSpan();
            if(span!=null){
                int flags=(span instanceof RelativeLineSpacingSpan)?Spannable.SPAN_PARAGRAPH:Spannable.SPAN_EXCLUSIVE_EXCLUSIVE;
                e.setSpan(span,a,b,flags);
            }
        }catch(Exception ignored){}
    }

    org.json.JSONObject objectStateJson(ObjectState x)throws Exception{org.json.JSONObject j=new org.json.JSONObject();j.put("kind",x.kind);j.put("name",x.name);j.put("text",x.text);j.put("imageUri",x.imageUri);j.put("fontName",x.fontName);j.put("spansJson",x.spansJson);j.put("left",x.left);j.put("top",x.top);j.put("width",x.width);j.put("height",x.height);j.put("color",x.color);j.put("borderType",x.borderType);j.put("textSize",x.textSize);j.put("alpha",x.alpha);j.put("stroke",x.stroke);j.put("locked",x.locked);j.put("visible",x.visible);j.put("fillPage",x.fillPage);j.put("gravity",x.gravity);return j;}
    ObjectState objectStateFromJson(org.json.JSONObject j){ObjectState x=new ObjectState();x.kind=j.optString("kind","shape");x.name=j.optString("name",null);x.text=j.optString("text","");x.imageUri=j.optString("imageUri",null);x.fontName=j.optString("fontName",null);x.spansJson=j.optString("spansJson",null);x.left=j.optInt("left");x.top=j.optInt("top");x.width=j.optInt("width",dp(120));x.height=j.optInt("height",dp(80));x.color=j.optInt("color",textColor);x.borderType=j.optInt("borderType");x.textSize=(float)j.optDouble("textSize",0);x.alpha=(float)j.optDouble("alpha",1);x.stroke=(float)j.optDouble("stroke",1);x.locked=j.optBoolean("locked",false);x.visible=j.optBoolean("visible",true);x.fillPage=j.optBoolean("fillPage",false);x.gravity=j.optInt("gravity",Gravity.TOP|Gravity.RIGHT);return x;}
    void writeJson(Uri u)throws Exception{
        saveCurrentPageState();
        org.json.JSONObject o=new org.json.JSONObject();o.put("schemaVersion",51);o.put("documentEngine","object-page-model-richtext-stable-font-and-line-spacing-v51");o.put("sizeUnit","sp");o.put("currentPage",currentPage);o.put("font",currentFontName);o.put("pages",new org.json.JSONArray());
        org.json.JSONArray arr=o.getJSONArray("pages");for(PageState p:pages){org.json.JSONObject q=new org.json.JSONObject();q.put("title",p.title);q.put("color",p.color);q.put("w",p.w);q.put("h",p.h);q.put("safe",p.safe);org.json.JSONArray objs=new org.json.JSONArray();for(ObjectState x:p.objects)objs.put(objectStateJson(x));q.put("objects",objs);arr.put(q);} 
        // Legacy fields retained for backward compatibility.
        o.put("title",title.getText().toString());o.put("text",editor==null?"":editor.getText().toString());o.put("size",editor==null?DEFAULT_FONT_SIZE_SP:pxToSp(editor.getTextSize()));o.put("textSpans",saveTextSpans());o.put("pageW",pageW);o.put("pageH",pageH);o.put("textColor",textColor);o.put("paperColor",paperColor);o.put("bold",bold);o.put("italic",italic);o.put("center",center);
        OutputStream out=getContentResolver().openOutputStream(u);out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));out.close();
    }

    void openDocument(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,103);}
    void openJson(Uri u){try{
        InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[8192];int n;while((n=in.read(z))>0)b.write(z,0,n);in.close();
        org.json.JSONObject o=new org.json.JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));
        buildEditor();
        if(o.optInt("schemaVersion",0)>=45 && o.optJSONArray("pages")!=null){
            pages.clear();org.json.JSONArray pa=o.getJSONArray("pages");for(int pi=0;pi<pa.length();pi++){org.json.JSONObject q=pa.getJSONObject(pi);PageState ps=new PageState(q.optString("title","Untitled Page"),q.optInt("color",Color.WHITE),q.optInt("w",595),q.optInt("h",842),(float)q.optDouble("safe",CONTENT_SAFE_DP));org.json.JSONArray oa=q.optJSONArray("objects");if(oa!=null)for(int oi=0;oi<oa.length();oi++)ps.objects.add(objectStateFromJson(oa.getJSONObject(oi)));pages.add(ps);}loadFonts();currentFontName=o.optString("font","System Urdu");currentTypeface=typefaces.get(currentFontName);if(currentTypeface==null)currentTypeface=Typeface.DEFAULT;currentPage=Math.max(0,Math.min(o.optInt("currentPage",0),pages.size()-1));loadPageState(currentPage);if(fontSpinner!=null){int nix=fontNames.indexOf(currentFontName);if(nix>=0){suppressFontSpinnerCallback=true;fontSpinner.setSelection(nix);suppressFontSpinnerCallback=false;}}toast("Professional document opened with all pages and layers");return;
        }
        title.setText(o.optString("title","Untitled Urdu Document"));
        changing=true;editor.setText(o.optString("text",""));changing=false;

        // V22+: size is stored as SP. V21/older files stored pixels, so convert
        // those legacy values back to SP before applying them.
        float savedSize=(float)o.optDouble("size",DEFAULT_FONT_SIZE_SP);String unit=o.optString("sizeUnit","");
        if(!"sp".equalsIgnoreCase(unit))savedSize=pxToSp(savedSize);
        savedSize=Math.max(12f,Math.min(72f,savedSize));editor.setTextSize(TypedValue.COMPLEX_UNIT_SP,savedSize);
        restoreTextSpans(o.optJSONArray("textSpans"));

        pageW=o.optInt("pageW",595);pageH=o.optInt("pageH",842);textColor=o.optInt("textColor",textColor);paperColor=o.optInt("paperColor",paperColor);
        bold=o.optBoolean("bold",false);italic=o.optBoolean("italic",false);center=o.optBoolean("center",false);
        editor.setTextColor(textColor);paper.setBackgroundColor(paperColor);currentFontName=o.optString("font","System Urdu");
        loadFonts();int ix=fontNames.indexOf(currentFontName);if(ix<0)ix=0;fontSpinner.setSelection(ix);applyTypeface();applyGravity();choosePageSilent();
        editor.post(()->ensureActiveTextFitsPage());toast("Document opened with exact saved layout");
    }catch(Exception e){toast("Open failed: "+e.getMessage());}}
    void choosePageSilent(){
        if(paper==null)return;
        ViewGroup.LayoutParams lp=paper.getLayoutParams();
        lp.width=dp(pageW); lp.height=dp(pageH); paper.setLayoutParams(lp);
        if(stage!=null){stage.setMinimumWidth(dp(pageW)+dp(44)); ViewGroup.LayoutParams slp=stage.getLayoutParams(); if(slp!=null){slp.width=dp(pageW)+dp(44); stage.setLayoutParams(slp);}}
        paper.post(()->ensureActiveTextFitsPage());
    }

    // Keep document content inside the selected paper canvas. The text object itself
    // scrolls vertically when content becomes longer than one physical page, so no
    // characters are clipped or drawn outside the paper.
    void ensureActiveTextFitsPage(){
        if(editor==null || paper==null)return;
        editor.setHorizontallyScrolling(false);
        editor.setMaxWidth(Math.max(1,paper.getWidth()));
        editor.setVerticalScrollBarEnabled(false);
        editor.setPadding(dp(24),dp(24),dp(24),dp(24));
        editor.requestLayout();
        editor.post(()->paginateIfNeeded());
    }

    /** Splits overflowing primary-page text into a real next page instead of letting it disappear below the page. */
    void paginateIfNeeded(){
        if(autoPaginating || changing || editor==null || editor!=primaryEditor || paper==null)return;
        Layout layout=editor.getLayout();
        int available=editor.getHeight()-editor.getPaddingTop()-editor.getPaddingBottom();
        if(layout==null || available<=0 || layout.getHeight()<=available)return;

        int fit=0;
        for(int line=0; line<layout.getLineCount(); line++){
            if(layout.getLineBottom(line)<=available) fit=layout.getLineEnd(line);
            else break;
        }
        if(fit<=0 || fit>=editor.length())return;

        // Prefer a word boundary so Urdu/English words are not cut in the middle.
        CharSequence all=editor.getText();
        int split=fit;
        while(split>0 && split<all.length() && !Character.isWhitespace(all.charAt(split-1))) split--;
        if(split<Math.max(1,fit-80)) split=fit;

        String allSpans=serializeTypefaceSpans(editor);
        int effectiveSplit=split;
        // Keep paragraph separators with the next page, but rebase formatting correctly.
        while(effectiveSplit<all.length() && all.charAt(effectiveSplit)=='\n') effectiveSplit++;
        String kept=all.subSequence(0,split).toString();
        String overflow=all.subSequence(effectiveSplit,all.length()).toString();
        String keptSpans=sliceRichSpans(allSpans,0,split);
        String overflowSpans=sliceRichSpans(allSpans,effectiveSplit,all.length());

        autoPaginating=true;
        changing=true;
        editor.setText(kept);
        restoreTypefaceSpans(editor,keptSpans);
        changing=false;
        saveCurrentPageState();

        int next=currentPage+1;
        // Continue overflow with the same base font AND every selected-range rich format.
        ObjectState styleSource=copyObjectState(getPrimaryTextState(pages.get(currentPage)));
        if(styleSource!=null)styleSource.spansJson=overflowSpans;
        if(next<pages.size() && isPageTextEmpty(pages.get(next))){
            putPrimaryText(pages.get(next),overflow,styleSource);
        }else{
            PageState continued=new PageState(
                    title==null?"Untitled":title.getText().toString(),
                    paperColor,pageW,pageH,borderSafeDp);
            putPrimaryText(continued,overflow,styleSource);
            pages.add(next,continued);
        }
        autoPaginating=false;
        loadPageState(next);
        editor.setSelection(Math.min(editor.length(),overflow.length()));
        editor.requestFocus();
        toast("Page "+next+" filled — continued on Page "+(next+1));
        showPageTools();
    }
    /** V30: dedicated WYSIWYG document/PDF preview before export or printing. */
    void showPdfPreview(){
        if(paper==null)return;
        saveCurrentPageState();
        activatePageMode();
        paper.postDelayed(()->{
            int w=Math.max(1,paper.getWidth()), h=Math.max(1,paper.getHeight());
            Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            Canvas pc=new Canvas(bm); pc.drawColor(paperColor); paper.draw(pc);
            Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
            LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(4),dp(8),dp(4)); bar.setBackgroundColor(BLUE);
            TextView ttl=text("PDF Preview • Page "+(currentPage+1)+" of "+Math.max(1,pages.size()),16); ttl.setTextColor(Color.WHITE); bar.addView(ttl,new LinearLayout.LayoutParams(0,dp(52),1));
            Button close=button("Close"); close.setTextColor(Color.WHITE); close.setOnClickListener(v->d.dismiss()); bar.addView(close,new LinearLayout.LayoutParams(dp(70),dp(48))); root.addView(bar);
            HorizontalScrollView hs=new HorizontalScrollView(this); hs.setFillViewport(true); ScrollView vs=new ScrollView(this); vs.setFillViewport(true);
            ImageView iv=new ImageView(this); iv.setImageBitmap(bm); iv.setAdjustViewBounds(true); iv.setScaleType(ImageView.ScaleType.CENTER); iv.setPadding(dp(12),dp(18),dp(12),dp(18)); vs.addView(iv,new ScrollView.LayoutParams(-2,-2)); hs.addView(vs,new HorizontalScrollView.LayoutParams(-2,-1)); root.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
            LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER); actions.setPadding(dp(6),dp(6),dp(6),dp(6));
            Button pdf=button("Export PDF"); pdf.setOnClickListener(v->{d.dismiss();exportPdf();}); actions.addView(pdf,new LinearLayout.LayoutParams(0,dp(48),1));
            Button pr=button("Print"); pr.setOnClickListener(v->{d.dismiss();printPdf();}); actions.addView(pr,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(actions);
            d.setContentView(root); Window win=d.getWindow(); if(win!=null){win.setLayout(-1,-1); win.setBackgroundDrawable(new ColorDrawable(BG));} d.show(); if(d.getWindow()!=null)d.getWindow().setLayout(-1,-1);
        },80);
    }

    void exportPdf(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".pdf");startActivityForResult(i,104);}void createPdf(Uri uri)throws Exception{OutputStream out=getContentResolver().openOutputStream(uri);writePdfToStream(out);out.close();}
    /**
     * WYSIWYG PDF export: draw the same paper View that the user sees in the editor.
     *
     * The previous code rebuilt text with a second StaticLayout and a fixed margin.
     * That changed line wrapping, Urdu/Hindi shaping, spans and line positions after
     * saving/printing. Here the editor layout itself is drawn and the canvas is scaled
     * from the on-screen paper size to the selected PDF paper size.
     */
    // V29 HQ: 360 DPI gives sharper professional output while keeping memory
    // within a practical range on modern Android phones. One page is rendered at a time.
    static final int PDF_RENDER_DPI=360;

    Bitmap renderPaperHighQuality(int pdfW,int pdfH){
        int bw=Math.max(1,Math.round(pdfW*PDF_RENDER_DPI/72f));
        int bh=Math.max(1,Math.round(pdfH*PDF_RENDER_DPI/72f));
        Bitmap bitmap=Bitmap.createBitmap(bw,bh,Bitmap.Config.ARGB_8888);
        Canvas bitmapCanvas=new Canvas(bitmap);
        bitmapCanvas.drawColor(paperColor);
        float sx=bw/(float)Math.max(1,paper.getWidth());
        float sy=bh/(float)Math.max(1,paper.getHeight());
        bitmapCanvas.save();
        bitmapCanvas.scale(sx,sy);
        paper.draw(bitmapCanvas);
        bitmapCanvas.restore();
        return bitmap;
    }

    void writePdfToStream(OutputStream out)throws Exception{
        saveCurrentPageState();
        PdfDocument doc=new PdfDocument();
        ArrayList<PageState> outPages=new ArrayList<>(pages);
        if(outPages.isEmpty()) outPages.add(capturePage());

        // Keep the user's current page active after export.
        int originalPage=currentPage;
        String originalTitle=title==null?"Untitled":title.getText().toString();

        for(int i=0;i<outPages.size();i++){
            PageState state=outPages.get(i);
            // V45 real object model: restore the complete page object graph before rendering.
            // This avoids the old single PageState.text field and keeps text, images, borders,
            // visibility, locks and layer order consistent in the export.
            loadPageState(i);
            paper.measure(
                    View.MeasureSpec.makeMeasureSpec(dp(state.w),View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(dp(state.h),View.MeasureSpec.EXACTLY));
            paper.layout(0,0,dp(state.w),dp(state.h));

            PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(state.w,state.h,i+1).create();
            PdfDocument.Page pdfPage=doc.startPage(pi);
            Canvas c=pdfPage.getCanvas();
            c.drawColor(state.color);

            // Render the already-laid-out editor at 360 DPI. This preserves the
            // exact Android text shaping, bidi order, line breaks, font, colors and
            // spacing seen on screen, without the low-resolution screen-to-PDF loss.
            boolean hadFocus=editor!=null && editor.hasFocus();
            for(SelectionEditText t:textObjects) t.clearFocus();
            Bitmap hi=renderPaperHighQuality(state.w,state.h);
            Paint quality=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG|Paint.DITHER_FLAG);
            Rect src=new Rect(0,0,hi.getWidth(),hi.getHeight());
            RectF dst=new RectF(0,0,state.w,state.h);
            c.drawBitmap(hi,src,dst,quality);
            hi.recycle();
            if(hadFocus && editor!=null) editor.requestFocus();
            doc.finishPage(pdfPage);
        }

        // Restore the page the user was editing using the real object model.
        if(originalPage>=0 && originalPage<pages.size()){
            loadPageState(originalPage);
            title.setText(originalTitle);
        }
        doc.writeTo(out); doc.close();
    }
    void printPdf(){
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print(title.getText().toString(),new PrintDocumentAdapter(){
            public void onLayout(PrintAttributes o,PrintAttributes n,CancellationSignal cs,LayoutResultCallback cb,Bundle e){
                if(cs.isCanceled()){cb.onLayoutCancelled();return;}
                saveCurrentPageState();
                PrintDocumentInfo info=new PrintDocumentInfo.Builder(safeName(title.getText().toString())+".pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(Math.max(1,pages.size())).build();
                cb.onLayoutFinished(info,true);
            }
            public void onWrite(PageRange[] r,ParcelFileDescriptor d,CancellationSignal cs,WriteResultCallback cb){
                try{writePdfToStream(new FileOutputStream(d.getFileDescriptor()));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}
                catch(Exception e){cb.onWriteFailed(e.getMessage());}
            }
        },buildPrintAttributes());
    }

    PrintAttributes buildPrintAttributes(){
        PrintAttributes.MediaSize media;
        // Match the document paper to prevent the Android print service from
        // silently rotating, shrinking or reflowing the page.
        if((pageW==612 && pageH==792)||(pageW==792 && pageH==612)) media=PrintAttributes.MediaSize.NA_LETTER;
        else if((pageW==420 && pageH==595)||(pageW==595 && pageH==420)) media=PrintAttributes.MediaSize.ISO_A5;
        else media=PrintAttributes.MediaSize.ISO_A4;
        if(pageW>pageH) media=media.asLandscape(); else media=media.asPortrait();
        return new PrintAttributes.Builder()
                .setMediaSize(media)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setResolution(new PrintAttributes.Resolution("habeeb300","High Quality 300 DPI",300,300))
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
    }
    void restoreDraft(){try{SharedPreferences p=getSharedPreferences("draft",0);String s=p.getString("text",null);if(s!=null){title.setText(p.getString("title",title.getText().toString()));changing=true;editor.setText(s);changing=false;undoStack.clear();undoStack.add(s);}}catch(Exception ignored){}}
    void saveDraft(){if(editor!=null){saveCurrentPageState();}if(editor!=null)getSharedPreferences("draft",0).edit().putString("title",title.getText().toString()).putString("text",editor.getText().toString()).apply();}
    void confirmHome(){saveDraft();new AlertDialog.Builder(this).setMessage("Return to home? Your current draft is auto-saved.").setNegativeButton("Cancel",null).setPositiveButton("Home",(d,w)->buildHome()).show();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(editor!=null)confirmHome();else super.onBackPressed();}
    @Override protected void onPause(){saveDraft();super.onPause();}
}

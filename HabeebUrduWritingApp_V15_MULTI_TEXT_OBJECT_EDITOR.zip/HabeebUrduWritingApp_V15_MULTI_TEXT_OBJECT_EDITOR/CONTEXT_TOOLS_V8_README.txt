HABEEB URDU WRITING APP — ADVANCED V8 CONTEXT TOOLS

WHAT IS FIXED
1. Reliable keyboard activation on text tap/focus.
2. Text-focused bottom tool panel: Duplicate, Opacity, Copy, Flip H, Flip V, Lock, Edit, Font, Color, Align, Bold, Italic, Delete.
3. Page-focused bottom customization panel: Add New, Resize Paper, Transparent BG, BG Color, Page Colors, Border, Page Copy, Pages, Template, Image.
4. The bottom panel switches automatically when the text editor receives focus.
5. Page controls are available when Page is selected from the top toolbar or by tapping the empty stage/page area.
6. Pinch-to-resize text remains available.
7. Soft input mode uses adjustResize so the editor can resize around the Android keyboard.

IMPORTANT
This ZIP contains Android source code. Build it with Android Studio or the included GitHub Actions workflow.

VERIFICATION
Static source checks were completed for balanced braces, required helper methods, keyboard hooks, and contextual tool methods. A full Android APK build was not run in this environment because Gradle/Android SDK is not installed here.

# Habeeb Urdu Writing App V13

Professional, user-friendly Urdu document editor.

## Required interaction
1. Tap text: normal cursor/editing.
2. Long press a word: select/highlight that word.
3. As soon as text is selected: bottom Text Tools open automatically.
4. Clear selection/tap page: Page Tools return.

The source was statically reviewed and the ZIP was integrity-tested. Run the included Android project in Android Studio or the configured GitHub Actions workflow for a real device APK build/test.

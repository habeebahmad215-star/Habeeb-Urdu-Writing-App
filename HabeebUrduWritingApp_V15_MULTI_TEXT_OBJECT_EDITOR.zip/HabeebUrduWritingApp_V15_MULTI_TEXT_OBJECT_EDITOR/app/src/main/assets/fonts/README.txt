Optional Urdu fonts can be imported from the app's Font menu as .ttf or .otf files.
Only bundle fonts for which you have redistribution permission.

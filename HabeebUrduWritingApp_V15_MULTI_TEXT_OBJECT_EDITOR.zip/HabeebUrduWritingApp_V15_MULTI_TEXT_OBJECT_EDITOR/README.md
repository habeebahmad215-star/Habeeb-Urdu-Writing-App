# Habeeb Urdu Writing App — Professional Advanced

## New interface
- Compact professional dashboard with small square quick-start cards
- Professional language selector
- Advanced canvas editor with horizontal + vertical navigation
- Font size 1–70, color, bold, italic and alignment
- Urdu RTL writing and imported TTF/OTF font support
- Object select, lock, delete and duplicate
- Whole-page selection, background and border controls
- Templates including certificate, notice, Islamic poster and corner styles
- Page duplicate/copy, image insertion, layers-like tools, undo/redo
- PDF export, printing, JSON save/open and auto-save
- System-bar safe layout so content starts below the front camera/status area

## Build
Requires JDK 17 and Gradle 8.9 with Android SDK 35 installed.
Run: `gradle assembleDebug`

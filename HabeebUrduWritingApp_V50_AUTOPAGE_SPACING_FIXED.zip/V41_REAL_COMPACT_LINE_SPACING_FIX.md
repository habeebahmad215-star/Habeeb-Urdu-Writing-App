V41 REAL LINE SPACING FIX
- New text objects explicitly disable extra font padding.
- Default line height is compacted to 0.88x with -2dp extra to avoid the Urdu/Nastaliq double-spacing appearance.
- Clipboard paste is converted to plain text and normalized so external paragraph/line-height spans cannot create huge gaps.
- Existing per-selection line spacing controls remain available.

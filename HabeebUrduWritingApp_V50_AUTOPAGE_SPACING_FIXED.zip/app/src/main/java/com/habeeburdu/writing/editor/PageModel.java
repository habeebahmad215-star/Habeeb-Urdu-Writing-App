package com.habeeburdu.writing.editor;
import java.util.*;
public final class PageModel {
  public int width,height,backgroundColor;
  public float safeMargin;
  public final List<EditorObject> objects=new ArrayList<>();
}

package com.habeeburdu.writing.editor;
public final class SelectionManager {
  private String selectedId;
  public void select(String id){selectedId=id;}
  public void clear(){selectedId=null;}
  public String getSelectedId(){return selectedId;}
}

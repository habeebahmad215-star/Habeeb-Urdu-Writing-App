package com.habeeburdu.writing;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/** Clean branded launch screen for Habeeb Urdu Writing App. */
public class SplashActivity extends Activity {
    private static final long SPLASH_MS = 1100L;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,14,18));
        getWindow().setNavigationBarColor(Color.rgb(5,14,18));
        getWindow().getDecorView().setSystemUiVisibility(0);

        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,14,18));

        ImageView logo=new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("habeeb_logo","drawable",getPackageName()));
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int side=(int)(getResources().getDisplayMetrics().widthPixels*0.62f);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(side,side,Gravity.CENTER);
        lp.bottomMargin=dp(18);
        root.addView(logo,lp);

        TextView caption=new TextView(this);
        caption.setText("Urdu Writing App");
        caption.setTextColor(Color.rgb(215,190,126));
        caption.setTextSize(15);
        caption.setLetterSpacing(.08f);
        caption.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        cp.topMargin=side+dp(74);
        root.addView(caption,cp);

        setContentView(root);
        new Handler().postDelayed(()->{
            startActivity(new Intent(this,MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_MS);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}

package com.habeeburdu.writing.editor;
/** Single source-of-truth metadata for a canvas object. */
public final class EditorObject {
  public String id,type,name;
  public int x,y,width,height,zIndex;
  public float rotation,opacity=1f;
  public boolean locked,visible=true,selected;
  public EditorObject(String id,String type){this.id=id;this.type=type;}
}

package com.habeeburdu.writing.editor;
import java.util.*;
/** Document model independent from Android Views. */
public final class DocumentModel {
  public final List<PageModel> pages=new ArrayList<>();
  public int currentPage;
}

# V30 PDF Preview + Professional Selection Fix

## Added
- Dedicated Preview button in editor top bar: Save | Preview | PDF | Print.
- WYSIWYG preview of the current document page before export/printing.
- Preview actions for Export PDF and Print.

## Selection UX fix
- After applying Bold, Color, Underline, Font, Word Spacing or Line Spacing, one tap on genuinely empty paper immediately clears the text selection and returns to page mode.
- Added a visible Done action as a reliable alternative.
- The touch test uses the actual Android text layout so taps on visible text continue to behave as text-editing taps.

## Retained
- Default 12sp typing size.
- Manual 12–72 font size range.
- Space and Enter do not auto-increase font size.
- 360 DPI high-quality PDF rendering.

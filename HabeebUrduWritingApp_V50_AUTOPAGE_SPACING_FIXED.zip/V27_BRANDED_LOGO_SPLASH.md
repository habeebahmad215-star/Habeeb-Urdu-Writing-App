# V27 Branded Logo & Splash Update

- Replaced the app's previous logo with the supplied HABEEB Urdu Writing App logo.
- Added the logo as the Android launcher and round app icon source.
- Added a clean branded splash screen before the editor opens.
- Updated the editor header logo to CENTER_INSIDE so the new logo is not cropped.
- Existing V26 12sp default font-size and Space/Enter stability fixes are retained.

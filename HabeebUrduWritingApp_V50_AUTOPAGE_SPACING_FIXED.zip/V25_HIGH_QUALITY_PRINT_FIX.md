# V25 High Quality PDF + Print Fix

- PDF pages now render the actual laid-out editor at 300 DPI (A4 about 2480 x 3508 px).
- Urdu, Hindi and mixed-script shaping/line breaks are captured from the same on-screen layout.
- PDF colors use ARGB_8888 with filtering, antialiasing and dithering for cleaner output.
- Print job now explicitly matches A4/A5/Letter and portrait/landscape orientation.
- Zero print margins are requested to avoid silent shrink/rotate behavior by the Android print pipeline.
- Each page bitmap is created and released one at a time to control memory usage.

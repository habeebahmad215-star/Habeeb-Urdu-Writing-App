# V31 Designer Library & Color Expansion

- Added compact home-page Designer Library: editable Templates, Islamic Posters, Certificates, Shapes, Corners, Elements, Borders, PNG/Images.
- Tapping a library item opens the editor when needed and applies/inserts the selected asset directly on the page.
- Shapes and elements are draggable.
- Expanded text color palette to 30+ professional shades.
- Expanded page background palette.
- Existing V30 PDF Preview and selection fixes retained.

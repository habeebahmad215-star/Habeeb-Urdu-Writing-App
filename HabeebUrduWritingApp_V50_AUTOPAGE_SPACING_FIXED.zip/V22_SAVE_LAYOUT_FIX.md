# V22 Save/Load Exact Layout Fix

Fixed the save/open scaling bug where `EditText.getTextSize()` (pixels) was saved and later passed to `setTextSize(float)` (SP), causing text to become larger after reopening.

## Changes
- Save base font size explicitly in SP.
- Add `sizeUnit: sp` and `schemaVersion: 22`.
- Convert legacy V21/older pixel-size documents back to SP when opening.
- Clamp base font size to 12–72 SP.
- Preserve selected-text spans for size, color, bold/italic and underline.
- Re-run page fitting after load.

Expected result: Save -> close/open -> same base text size and page fit.

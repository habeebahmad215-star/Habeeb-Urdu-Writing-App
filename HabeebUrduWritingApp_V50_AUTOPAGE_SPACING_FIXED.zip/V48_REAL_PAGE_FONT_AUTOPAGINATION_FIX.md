# V48 — Real Page, Font and Auto-Pagination Fix

- New documents start with exactly one page.
- Extra pages are created only by overflow or explicit New Page.
- Previous/Next arrows are always visible and unclipped.
- Page indicator supports direct jump.
- Choosing a font without selection sets the typing font.
- Choosing a font with selected/pasted text changes only that selection.
- Every text object stores its base font.
- Range font spans persist per object.
- Overflow pages inherit font and range formatting.
- New blank pages inherit active page style/font.
- Page switching and Save/Open preserve object fonts.
- Existing 45+ documents remain readable.

V24 WYSIWYG PDF/PRINT FIX

- Removed separate PDF StaticLayout reconstruction with fixed margins.
- PDF now draws the same paper/editor View hierarchy shown on screen.
- Canvas is scaled from the on-screen selected paper dimensions to the selected PDF page dimensions.
- This keeps Urdu/Hindi shaping, bidi layout, font spans, selected font sizes, word spacing, line spacing, padding and line wrapping consistent with the editor for the active page.
- Print uses the same writePdfToStream() pipeline, so PDF and Print share the same renderer.
- Font size remains explicit (12–72); no Enter/new-line auto-resizing is introduced.

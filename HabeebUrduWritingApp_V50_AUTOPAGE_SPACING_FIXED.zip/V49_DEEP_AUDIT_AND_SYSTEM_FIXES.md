# V49 Deep Audit & System Fixes

## Core issues corrected
1. New document now starts with one genuinely blank page; the hint remains, but sample text is not saved as user content.
2. Page navigation controls were rebuilt for narrow phones: explicit `Prev` and `Next` labels plus a flexible center page indicator.
3. The page indicator remains the direct page-jump control.
4. Auto-pagination now measures the actual editable view height rather than the whole paper height, preventing incorrect fit calculations when safe margins are active.
5. Overflow splitting now preserves supported rich formatting across page boundaries instead of converting the overflow to a plain String and losing selected fonts.
6. Object persistence now stores supported per-range formatting in `spansJson`: font ranges, color, style, underline, size, word spacing and line spacing.
7. Existing V47/V48 files remain readable because the restore path accepts the previous font-only span JSON format.
8. The next auto-created page inherits the same base font and the correct rebased rich-format spans unless the user manually changes formatting.
9. Save/open uses schema version 49 while retaining the object/page JSON structure.

## Remaining architecture note
The app still uses a large MainActivity for UI orchestration. The separate `editor/DocumentModel`, `PageModel` and `EditorObject` classes are present but the Android View bridge is not yet fully migrated to them. A complete migration should be done as a controlled refactor with automated Android build/device testing, not by blindly moving methods and risking regressions.

## Important quality boundary
No software patch can honestly guarantee a permanent 5.0 Play Store rating. Ratings depend on real users, device compatibility, stability, privacy, performance and ongoing support. This release focuses on correctness and consistency rather than making an unrealistic rating promise.

# V18 Keyboard + Text Selection Fix

Fixed the main editor issue reported on mobile:

1. Long-press selected text remains highlighted when the Android Back key closes the keyboard.
2. The bottom Text Tools bar is kept active after keyboard dismissal.
3. IME/keyboard insets are applied so the bottom tools move above the keyboard instead of being covered.
4. Tapping the page intentionally exits text-selection mode and restores Page Tools.

Build target remains compileSdk 35, AGP 8.7.3, Gradle 8.9 in GitHub Actions, Java 17.

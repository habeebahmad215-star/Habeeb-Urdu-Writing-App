V46 BUILD FIX — PageState/Object Model Compile Repair

Fixed the five javac errors reported in MainActivity.java:

1) Removed stale pages.get(next).text access.
2) Removed obsolete PageState(String text, title, color, width, height) construction.
3) Removed both stale state.text references during PDF export/restore.
4) Added object-model helpers:
   - getPrimaryTextState(PageState)
   - isPageTextEmpty(PageState)
   - copyObjectState(ObjectState)
   - putPrimaryText(PageState, String, ObjectState)
5) Auto-pagination now carries overflow into a real independent text object.
6) PDF export now restores the complete page object graph before rendering.

This is a source-level compile repair for the V45 real PageState migration.

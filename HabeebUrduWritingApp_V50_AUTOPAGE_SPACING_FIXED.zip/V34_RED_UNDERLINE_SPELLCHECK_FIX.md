# V34 Red Underline Fix

Problem: Android spell-check suggestions were showing red underlines under Urdu text.

Fix: The editor input type now uses TYPE_TEXT_FLAG_NO_SUGGESTIONS with multiline text input. This disables automatic spelling suggestion underlines inside the app editor while keeping normal Urdu text editing and selection.

Verified: MainActivity.java patched and archive recreated successfully.

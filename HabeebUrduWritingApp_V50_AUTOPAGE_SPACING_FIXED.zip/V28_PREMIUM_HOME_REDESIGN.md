# V28 Premium Home Redesign

- Rebuilt home screen with adaptive 2-column cards to prevent cramped and wrapped labels.
- Improved visual hierarchy, spacing, typography and touch targets.
- Larger, cleaner branded header and language button.
- Added compact premium hero message and cleaner Recent Work card.
- Kept existing editor, PDF, print and all document functions unchanged.
- Version bumped to v28.

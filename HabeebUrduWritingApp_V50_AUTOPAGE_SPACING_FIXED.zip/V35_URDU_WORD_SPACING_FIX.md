# V35 Urdu Word Spacing Fix

- Default Urdu word gap is now slightly tighter (-1.5dp equivalent).
- Urdu letter shaping is not changed; only gaps created by spaces are tightened.
- Word Space tool now includes Extra tight, Tight, Default compact, and Normal.
- V34 spell/suggestion underline fix remains enabled.

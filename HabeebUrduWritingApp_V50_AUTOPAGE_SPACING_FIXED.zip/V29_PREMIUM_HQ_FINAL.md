# Habeeb Urdu Writing App — V29 Premium HQ

## Approved direction implemented
- Premium adaptive home dashboard retained and refined.
- Two-column mobile cards remain readable with non-cramped labels.
- Brand header and logo presentation retained.
- Editor keeps a true 12sp default size.
- Font-size controls remain constrained to 12–72.
- SPACE and ENTER do not auto-increase the base font size.
- Selected text tools include Bold, Italic, Underline, Color, Word Spacing and Line Spacing.
- WYSIWYG export path retained so the editor layout is used for PDF rendering.

## High-quality output upgrade
- PDF render resolution increased from 300 DPI to 360 DPI.
- ARGB_8888 rendering, anti-aliasing, bitmap filtering and dithering retained.
- Pages are rendered one at a time to reduce peak memory risk.
- Text, colors, Urdu/Hindi shaping and on-screen line layout follow the editor render path.

## Version
- versionCode: 29
- versionName: 3.6-v29-premium-hq

## Important
360 DPI is intentionally used instead of an unsafe ultra-high fixed DPI so A4 exports remain sharp without making common phones run out of memory.

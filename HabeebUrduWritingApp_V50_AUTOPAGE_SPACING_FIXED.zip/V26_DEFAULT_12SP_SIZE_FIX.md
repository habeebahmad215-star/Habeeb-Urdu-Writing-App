V26 DEFAULT 12SP SIZE FIX

- New document editor starts at exactly 12sp.
- Every new text box starts at exactly 12sp.
- Font size options remain 12sp through 72sp.
- Repeatedly choosing the same size is absolute, never cumulative.
- SPACE and ENTER do not intentionally change the editor's base font size.
- With no selected text, the size button sets the active typing size exactly.
- Saved documents default to 12sp when no valid size is stored.

V42 FINAL REAL SAFE OBJECT MANAGER FIX

Implemented from the user's requested workflow:
- Primary text editing area is a real rectangle inside the print-safe border, so cursor and typing do not enter the outside page area.
- Border is always behind text/images.
- Safe margin defaults to the print-safe value and can only be reduced, never increased.
- Border line thickness has its own editable control.
- Selected text/design objects receive a blue four-sided outline via ViewOverlay.
- Object manager now uses per-object tick boxes; ticking an object selects it and opens its relevant tools.
- Object manager includes Lock All / Unlock All and an individual lock icon for every object.
- Locked objects reject editing/dragging/duplicate/delete operations until unlocked.
- Object selection and border controls are separated to avoid one selection changing a different border setting.

Static verification performed: ZIP structure checked, Java brace balance checked, old BorderView constructor references checked. Full Android build could not be run in this environment because the uploaded project does not include Gradle wrapper and no system Gradle/Android SDK build tool is available.

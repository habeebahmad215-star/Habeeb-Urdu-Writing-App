V23 TEXT SPACING UPDATE

Added selected-text formatting buttons:
- Word Space: Normal, 1, 2, 3, 4, 6, 8, 10, 12
- Line Space: 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.8, 2.0

Both controls appear with Font, Size, Bold, Italic, Underline and Color whenever text is selected.

Formatting is stored with the selected text and restored when the JSON document is reopened.
PDF rendering now uses the selected text spans for the active page and removes the previous hard-coded 1.3 line-spacing multiplier.

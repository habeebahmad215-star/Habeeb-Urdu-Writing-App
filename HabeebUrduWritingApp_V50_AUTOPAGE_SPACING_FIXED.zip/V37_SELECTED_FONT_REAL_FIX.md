# V37 Selected Font Real Fix

## Root cause fixed
The V36 font code correctly supported `LocalTypefaceSpan`, but Android could collapse the highlighted selection when the font Spinner or font dialog took focus. The code then fell back to `EditText.setTypeface(...)`, changing the whole text box.

## V37 fix
- Captures the exact selected range before the font Spinner takes focus.
- Captures the exact selected range before opening the font dialog.
- Keeps that range while Android temporarily collapses visual selection.
- Font application now refuses to change the whole text box when there is no exact selected range.
- Applies `LocalTypefaceSpan` only to the remembered selected range.
- If an old font span crosses the selection boundary, its unselected left/right parts are preserved.
- Programmatic Spinner synchronization is suppressed so it cannot apply the font twice or to the wrong range.

## Verification performed
- Checked there is no `editor.setTypeface(...)` fallback remaining in `applyTypeface()`.
- Verified Spinner touch capture and dialog capture are present.
- Verified font spans are applied only with a non-empty selected range.
- Verified Java brace balance is correct.

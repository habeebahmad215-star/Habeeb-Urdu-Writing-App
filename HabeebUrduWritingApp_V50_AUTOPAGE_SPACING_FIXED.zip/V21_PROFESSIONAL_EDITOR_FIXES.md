# V21 Professional Editor Fixes

- Font size menu expanded from 12 to 72.
- Exact absolute font sizing: repeated taps do not cumulatively shrink or enlarge text.
- Pinch sizing limited to 12–72.
- Page tools show Page X of Y.
- Primary editor overflow is split into a following page instead of remaining hidden below the fixed paper.
- PDF export and print now write all document pages.
- Page workspace/paper separation strengthened for a clearer professional page boundary.

Important: Android compilation still needs to be run in the target CI/device environment.

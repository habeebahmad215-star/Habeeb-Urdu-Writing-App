# V36 Fixes
- Borders moved inside a safe print inset to reduce clipping on non-borderless printers.
- Expanded border library with 14 professional border styles.
- Font changes now apply to the selected text range only when text is selected.
- Size, color, bold, italic and other selected-range tools remain range-specific.
- Font-range spans are saved/restored in JSON documents.

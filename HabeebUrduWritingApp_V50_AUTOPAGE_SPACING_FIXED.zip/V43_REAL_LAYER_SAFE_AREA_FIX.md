# V43 REAL LAYER + SAFE AREA FIX

This update changes the actual Java editor implementation.

## Fixed
- Primary writing/cursor area is inset inside the border by Safe Margin + 8dp content gap.
- Border remains the bottom layer.
- Changing Safe Margin updates and clamps all text objects to the safe writing area.
- Safe Margin UI only permits reducing from the default safe margin.
- Border line width remains a separate setting.

## Added
- Persistent Layers & Objects manager.
- Tick/select one object to edit; other ticks clear automatically.
- Clear blue selection frame around the selected object.
- Individual lock icon for every object.
- Lock All / Unlock All controls.
- Front / Back layer controls.
- Objects and Layers buttons both open the same manager.
- Selected-object toolbar includes Layers, Front and Back.

## Important
The ZIP contains source changes. Live Android emulator/device validation is not available in this environment.

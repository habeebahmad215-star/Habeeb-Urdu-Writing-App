# V20 Page + Font Size Fix

- Selected text size now uses AbsoluteSizeSpan, so tapping 14 repeatedly keeps it at 14sp.
- Previous overlapping RelativeSizeSpan values are removed before applying a new size.
- Text objects wrap inside the selected paper width and remain inside the page canvas.
- Long content remains reachable with vertical scrolling instead of being silently clipped.
- Default document text and safe margins were improved for a cleaner first screen.

# V50 Auto-Page + Uniform Paste Spacing Fix

## Fixed from the reported screenshot
1. Fill-page editors restored after Page navigation now run the overflow check too. Earlier builds only had the main pagination watcher attached to the original editor, allowing text on restored/loaded pages to extend below the paper and be visually clipped.
2. Every fill-page text change schedules a safe re-layout and pagination check, guarded against restore and pagination recursion.
3. Pagination now explicitly waits for a valid laid-out editor safe area before deciding that text fits.
4. Clipboard paste is normalized to plain text and the inserted range is protected from inherited paragraph line-spacing spans.
5. Existing manually formatted line spacing before/after the insertion point is preserved; only the newly pasted range is returned to the document's uniform default line spacing.
6. Paste immediately schedules overflow pagination, so a long paste can create continuation pages instead of leaving text cut at the bottom.

## Important behavior
- New document still starts with one page.
- Additional pages are created only when content truly overflows, or the user explicitly adds a page.
- Long typing and long paste should both continue onto following pages.
- Pasted text is intentionally plain text for uniform professional spacing.

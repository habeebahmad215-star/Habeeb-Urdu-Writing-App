# V44 Professional Editor Rebuild Audit

## Actual code-level changes
1. Border is always inserted at layer 0 and content remains above it.
2. Border selection now registers a real object-lock state and draws the blue selection frame.
3. Applying/removing/changing a border synchronizes the primary writing safe area.
4. Safe margin can only be reduced from the print-safe default and is clamped to the configured minimum.
5. Selected object tools are contextual: border gets Line Width + Safe Margin; other objects get Move + Align + Resize + Duplicate + Delete.
6. Layers/Object Manager includes Lock All, Unlock All, Front, Back, Move and Align controls.
7. Each object row retains its checkbox selection and individual lock control.
8. Text object tools now include Move and Align in addition to Edit, Duplicate, Delete, Front, Size and Lock.
9. Layer-back logic keeps the border behind content instead of accidentally placing objects below the border.
10. Selection-frame sizing handles MATCH_PARENT objects more safely.

## Validation performed here
- ZIP integrity test passed with `unzip -t`.
- Java source brace balance check passed (0).
- Patched methods were checked for presence and duplicate insertion errors.

## Device build validation still required
This source archive does not contain a Gradle wrapper, so a real Android/Gradle APK build was not executable in this environment. Do not call the changes "verified on device" until the project is opened and built in Android Studio/CI.

## Manual acceptance test
1. Add 2 text boxes + 1 image + 1 shape + 1 border.
2. Open Layers; tick every object one by one and confirm blue frame and matching tools.
3. Lock one item and confirm it cannot move/edit; Unlock All restores it.
4. Select a word/phrase, change font and size, confirm only the highlighted range changes.
5. Change Word Space and Line Space only on a selected range; paste several paragraphs and confirm normal default spacing for unformatted text.
6. Select border; change Line Width and Safe Margin; confirm border and writing area move together.
7. Put cursor at all four sides of primary editor; confirm writing remains inside safe area.
8. Use Front/Back and confirm border remains behind all content.
9. Export PDF and compare page preview with output.

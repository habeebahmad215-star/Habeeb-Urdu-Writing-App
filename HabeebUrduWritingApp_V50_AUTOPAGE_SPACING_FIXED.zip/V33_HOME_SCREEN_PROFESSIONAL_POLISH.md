# V33 Home Screen Professional Polish

This update fixes the 12 issues identified from the real mobile screenshots:

1. Header made more compact to reduce wasted vertical space.
2. Header subtitle is responsive and ellipsizes safely instead of overflowing.
3. Card titles no longer use forced single-line clipping; two lines are supported.
4. Long labels were shortened where appropriate (Export PDF, Graphics, All Tools).
5. Hero card uses wrap-content text and supports two lines, preventing vertical clipping.
6. Home hierarchy is clearer: Quick Start, Design Studio, Design Library, Tools, Recent Projects.
7. Designer Library changed from cramped 4-column cards to readable 2-column asset cards.
8. Card radius, borders, elevation and padding are standardized for a consistent visual system.
9. Shadows are reduced to a softer, more controlled elevation.
10. Background/card contrast and section spacing are refined for a cleaner premium dashboard.
11. Recent Work is now Recent Projects and uses real saved-draft information when available.
12. A compact in-app bottom navigation bar was added for Home, Create, Templates, Projects and More.

Functional behavior from V32, including image editing and earlier editor/PDF fixes, remains retained.

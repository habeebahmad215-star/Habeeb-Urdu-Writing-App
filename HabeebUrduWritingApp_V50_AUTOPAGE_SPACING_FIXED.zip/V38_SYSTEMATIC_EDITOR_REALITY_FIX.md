# V38 Systematic Editor Reality Fix

## What was changed in the actual source
1. Border is inserted at layer index 0, behind all text, images and editable objects.
2. Border is non-clickable/non-focusable, so it cannot block text editing.
3. A shared 46dp content-safe margin is used for the main editable text object, preventing text from touching the print-safe border.
4. The editor stage now has an explicit width based on the selected paper width, preventing negative centering/clipping of the page inside HorizontalScrollView.
5. Paper-size changes update the stage width as well.
6. Header is now two rows: document title on its own responsive row, actions on a second row. This prevents the title from being squeezed by Save/Preview/PDF/Print.
7. Bottom context area height was reduced to remove unnecessary blank space.
8. Image dragging now converts raw screen coordinates into paper coordinates, preventing jumpy/misaligned movement when the page is scrolled.
9. Existing V37 exact-selection font logic remains in place; this V38 patch does not restore any whole-editor font fallback.

## Static verification performed
- Java brace balance checked.
- Border insertion verified at index 0.
- Shared safe-area constant verified.
- Stage width update verified in page-size code.
- No whole-editor `setTypeface(currentTypeface)` call introduced.
- ZIP integrity checked with unzip -t.

## Important limitation
This environment does not contain the Android Gradle wrapper/SDK build toolchain, so an APK build was not executed here. The source and archive were statically checked; final device build should still be run in the user's Android build environment.

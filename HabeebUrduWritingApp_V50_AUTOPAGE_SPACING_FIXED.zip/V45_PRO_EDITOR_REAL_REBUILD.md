# V45 Professional Editor Rebuild — Real Code Changes

This version changes the editor workflow instead of only adding labels.

## Implemented foundations
- Page snapshots now carry independent object lists, layer order, lock state, visibility, geometry, opacity, border settings and image source URI.
- Page switch and page duplication restore independent object state instead of only one text string.
- Save/Open schema upgraded to V45 with all page object state while keeping legacy fields.
- All movable content objects are clamped to the safe writing area; the decorative border itself is exempt.
- Image URI permission is requested for later page restoration where the provider supports persistence.
- Layer manager rows now expose selection checkbox, visibility control and per-object lock.
- Duplicate now consistently creates a new independent object instead of duplicating characters inside the same text object.
- Compact Urdu line spacing tightened again for new/pasted text.
- Separate model foundation added under `editor/` for future extraction from MainActivity.

## Important design rule
Safe Margin is an editing/print-content constraint. Border is an independent decorative page object. The border stays behind content; text/cursor are never supposed to draw over it.

## Manual acceptance tests before release
1. Add three text boxes, one image, one shape and a border.
2. Select each from Layers and verify only that selected object gets tools.
3. Lock one object and verify drag/edit is blocked only for it.
4. Hide/show one object and verify export-visible state follows the layer.
5. Switch Page 1 -> Page 2 -> Page 1 and verify all objects, positions and layer states remain.
6. Duplicate a page and verify editing the copy does not alter the original.
7. Drag every non-border object toward each edge and verify it remains inside safe content area.
8. Reduce safe margin and verify objects can use the newly available area; no increase beyond default policy.
9. Select border from Layers and verify Line Width and Safe Margin controls appear.
10. Paste multi-paragraph Urdu and verify compact line spacing without blank double gaps.
11. Save V45 JSON, reopen it, and verify all pages/layers restore.
12. Export PDF and Print Preview; visually verify border remains inside printable region.

V40 REAL OBJECT + BORDER FIX

This package corrects the two concrete failures reported from the V39 build:

1. BORDER INDEX/COLOR MISMATCH
   - Border type numbers are now mapped one-to-one with the displayed library.
   - Blue Corner Border now renders blue.
   - Gold Corner Border now renders gold.
   - Other named borders use their intended color family.
   - The border renderer was rewritten with explicit cases rather than shifted array indexes.

2. OBJECT MANAGER
   - The Objects list no longer lists the same border twice.
   - Selecting a design object opens its own Edit / Duplicate / Front / Larger / Smaller / Delete controls.
   - Selecting a text box from Objects opens object-level Edit / Duplicate / Delete / Front / Size / Done controls even when no text is highlighted.
   - Text selection formatting remains separate from object management.
   - Page mode clears the object-selection state cleanly.

3. RANGE FORMATTING HARDENING
   - Font, size, color, bold/italic, underline, word spacing and line spacing retain the intended selected range when a dialog steals focus.
   - Formatting operations use the remembered exact range instead of silently falling back to all text.

4. BORDER MANAGEMENT
   - A newly chosen border becomes the current selected border in the object manager.
   - Borders remain behind page content for print and do not intercept text/image taps.
   - Border deletion also removes the object registration cleanly.

Verification performed in this environment:
- Source inspected after patch.
- Java brace/structure balance check passed.
- Border labels and renderer type mapping manually cross-checked 1 through 14.
- Duplicate border entry path removed from the Objects list.

Note: This environment does not contain the Android Gradle SDK/Gradle executable, so an APK compile could not be run here. The source project itself is packaged for Android Studio/Gradle build.

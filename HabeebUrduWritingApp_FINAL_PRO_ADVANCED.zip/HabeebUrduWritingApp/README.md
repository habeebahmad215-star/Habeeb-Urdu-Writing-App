# Habeeb Urdu Writing App PRO Designer

Advanced Android Urdu writing and page-designing workspace.

## Main features
- Professional language selector with Urdu RTL, Arabic RTL and multiple Indian languages
- Imported TTF/OTF font support (including Jameel Noori Nastaleeq when the licensed font file is imported)
- Font size slider from 1 to 70
- Zoom plus/minus and canvas navigation in all four directions
- Object select, lock/unlock, delete and duplicate
- Full-page selection, page background, borders, page setup and page copy/duplicate
- Template library including certificate, notice, Islamic poster and corner/arrow style pages
- Images, draggable objects, undo/redo, JSON save/open, PDF export and Android print
- Safe system-bar/cutout layout so the workspace does not run behind a front camera cutout

## Important font note
Jameel Noori Nastaleeq is not redistributed inside this project. Import a legally obtained `.ttf` or `.otf` file using **Fonts → Import Font**. After import it is loaded as a real Android Typeface and can be selected for actual Urdu rendering.

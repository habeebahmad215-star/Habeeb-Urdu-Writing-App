# Habeeb Urdu Writing App

A starter Android project for a professional Urdu Nastaleeq writing and design app.

## Included in v1 starter
- Urdu writing editor
- Font selector with custom .ttf/.otf import
- Font size and basic formatting
- A4/A5/Letter page selection
- Portrait/Landscape
- Save/Open/Edit/Delete documents as JSON files through Android Storage Access Framework
- PDF export using the selected Urdu font
- Android Print support
- Share generated PDF
- Professional blue/gold UI foundation

## Important font licensing
Jameel Noori Nastaleeq, Faiz, Aftab, AlQalam and other fonts should only be bundled when their licenses permit redistribution. Otherwise import the font file from the user's device.

## Open
Open this folder in Android Studio, let Gradle sync, then Run.

Advanced Pro+ update: language selector, improved custom TTF/OTF loading, 1–70 text size, canvas zoom, all-direction scrolling, selectable page, lock/delete/duplicate controls, draggable image objects, professional border presets, page copy, and expanded templates.

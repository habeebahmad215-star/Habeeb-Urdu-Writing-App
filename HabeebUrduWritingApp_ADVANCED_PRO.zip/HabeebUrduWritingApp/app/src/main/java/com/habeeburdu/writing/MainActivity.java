package com.habeeburdu.writing;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.*;
import android.text.*;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Advanced, dependency-free Urdu document designer. */
public class MainActivity extends Activity {
    final int BLUE=0xFF123B67, BLUE2=0xFF1F5F9F, GREEN=0xFF178B54, PURPLE=0xFF7046A5, RED=0xFFB43A34, BG=0xFFF3F6FA;
    LinearLayout root, editorRoot, tools; EditText title, editor; FrameLayout paper;
    Spinner fontSpinner; SeekBar zoomBar, sizeBar; TextView zoomLabel, sizeLabel;
    String currentFontName="System Urdu"; Typeface currentTypeface=Typeface.DEFAULT;
    int pageW=595,pageH=842,textColor=0xFF182638,paperColor=Color.WHITE; boolean bold=false,italic=false,center=false,landscape=false;
    File fontDir; ArrayList<String> fontNames=new ArrayList<>(); HashMap<String,Typeface> typefaces=new HashMap<>();
    Bitmap pageImage; final ArrayList<String> undoStack=new ArrayList<>(), redoStack=new ArrayList<>(); boolean changing=false;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    int sp(float v){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,v,getResources().getDisplayMetrics());}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    TextView text(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(0xFF1D2A3A);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BLUE);getWindow().setNavigationBarColor(BLUE); if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false); fontDir=new File(getFilesDir(),"fonts");fontDir.mkdirs();loadFonts();buildHome();}
    void installInsets(View v){v.setOnApplyWindowInsetsListener((view,insets)->{android.graphics.Insets i=Build.VERSION.SDK_INT>=30?insets.getInsets(WindowInsets.Type.systemBars()):android.graphics.Insets.NONE;view.setPadding(0,i.top,0,i.bottom);return insets;});}
    void loadFonts(){fontNames.clear();typefaces.clear();fontNames.add("System Urdu");typefaces.put("System Urdu",Typeface.DEFAULT);File[] fs=fontDir.listFiles();if(fs!=null)for(File f:fs){try{Typeface t=Typeface.createFromFile(f);fontNames.add(f.getName());typefaces.put(f.getName(),t);}catch(Exception ignored){}}}

    void buildHome(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);installInsets(root);setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.VERTICAL);header.setPadding(dp(20),dp(12),dp(20),dp(12));header.setBackgroundColor(BLUE);
        TextView h=text("✒  Habeeb Urdu Writing App",22);h.setTextColor(Color.WHITE);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);header.addView(h,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView sub=text("Professional Urdu Writing • Design • PDF • Print",13);sub.setTextColor(0xFFDCE9F6);header.addView(sub,new LinearLayout.LayoutParams(-1,dp(26)));root.addView(header);
        ScrollView sv=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(16),dp(16),dp(28));
        TextView welcome=text("اپنے اردو دستاویزات کو خوبصورت اور پروفیشنل انداز میں تیار کریں",16);welcome.setGravity(Gravity.CENTER);welcome.setPadding(dp(8),dp(4),dp(8),dp(14));body.addView(welcome);
        homeCard(body,"✚  New Urdu Document","نیا پروفیشنل دستاویز بنائیں",BLUE2,v->buildEditor());
        homeCard(body,"📂  Open Document","محفوظ شدہ پروجیکٹ کھولیں",GREEN,v->openDocument());
        homeCard(body,"🔤  Nastaleeq Fonts","TTF / OTF فونٹس مینج کریں",PURPLE,v->showFontsDialog());
        homeCard(body,"🧩  Templates","سرٹیفکیٹ، نوٹس اور پوسٹر",0xFF8A5A1F,v->chooseTemplate());
        homeCard(body,"📄  PDF / Print","ہائی کوالٹی ایکسپورٹ اور پرنٹ",RED,v->{buildEditor();});
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(18),dp(18),dp(18),dp(18));info.setBackground(bg(Color.WHITE,16));
        TextView it=text("Advanced Features",18);it.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(it);
        TextView id=text("✓ Urdu RTL writing    ✓ Zoom canvas    ✓ Undo / Redo\n✓ Custom fonts         ✓ Images          ✓ PDF / Print\n✓ Colors & background  ✓ Templates       ✓ Auto-save",14);id.setPadding(0,dp(10),0,0);id.setLineSpacing(dp(4),1f);info.addView(id);LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(-1,-2);ilp.setMargins(0,dp(12),0,0);body.addView(info,ilp);
        sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    void homeCard(LinearLayout p,String title,String sub,int color,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(20),dp(12),dp(20),dp(12));c.setBackground(bg(color,18));c.setOnClickListener(l);TextView a=text(title,18);a.setTextColor(Color.WHITE);TextView b=text(sub,12);b.setTextColor(0xFFE8F0F8);c.addView(a,new LinearLayout.LayoutParams(-1,dp(34)));c.addView(b,new LinearLayout.LayoutParams(-1,dp(25)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(84));lp.setMargins(0,dp(7),0,dp(7));p.addView(c,lp);}

    void buildEditor(){
        editorRoot=new LinearLayout(this);editorRoot.setOrientation(LinearLayout.VERTICAL);editorRoot.setBackgroundColor(BG);installInsets(editorRoot);setContentView(editorRoot);root=editorRoot;
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(5),0,dp(6),0);top.setBackgroundColor(BLUE);
        Button back=button("‹");back.setTextSize(30);back.setTextColor(Color.WHITE);back.setOnClickListener(v->confirmHome());top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(56)));
        title=new EditText(this);title.setSingleLine();title.setText("Untitled Urdu Document");title.setTextColor(Color.WHITE);title.setTextSize(17);title.setBackgroundColor(Color.TRANSPARENT);top.addView(title,new LinearLayout.LayoutParams(0,dp(56),1));
        addTop(top,"Save",v->saveDocument());addTop(top,"PDF",v->exportPdf());addTop(top,"Print",v->printPdf());editorRoot.addView(top);

        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);tools=new LinearLayout(this);tools.setPadding(dp(6),dp(5),dp(6),dp(5));tools.setGravity(Gravity.CENTER_VERTICAL);tools.setBackgroundColor(Color.WHITE);
        fontSpinner=new Spinner(this);ArrayAdapter<String> fa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames);fontSpinner.setAdapter(fa);fontSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){if(editor!=null){currentFontName=fontNames.get(p);currentTypeface=typefaces.get(currentFontName);applyTypeface();}}});tools.addView(fontSpinner,new LinearLayout.LayoutParams(dp(170),dp(48)));
        addTool("B",v->{bold=!bold;applyTypeface();});addTool("I",v->{italic=!italic;applyTypeface();});addTool("↔",v->{center=!center;applyGravity();});addTool("A",v->chooseTextColor());addTool("▣",v->choosePaperColor());addTool("↶",v->undo());addTool("↷",v->redo());addTool("Page",v->choosePage());addTool("Image",v->pickImage());addTool("Template",v->chooseTemplate());addTool("+ Font",v->importFont());
        hsv.addView(tools);editorRoot.addView(hsv,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout controls=new LinearLayout(this);controls.setPadding(dp(12),dp(3),dp(12),dp(4));controls.setGravity(Gravity.CENTER_VERTICAL);controls.setBackgroundColor(0xFFF9FBFD);
        sizeLabel=text("Size 30",12);controls.addView(sizeLabel,new LinearLayout.LayoutParams(dp(62),dp(34)));sizeBar=new SeekBar(this);sizeBar.setMax(62);sizeBar.setProgress(12);sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int p,boolean f){if(editor!=null){int z=18+p;editor.setTextSize(z);sizeLabel.setText("Size "+z);}}});controls.addView(sizeBar,new LinearLayout.LayoutParams(0,dp(34),1));zoomLabel=text("100%",12);zoomLabel.setGravity(Gravity.CENTER);controls.addView(zoomLabel,new LinearLayout.LayoutParams(dp(52),dp(34)));zoomBar=new SeekBar(this);zoomBar.setMax(100);zoomBar.setProgress(40);zoomBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int p,boolean f){float z=.6f+p/100f;if(paper!=null){paper.setScaleX(z);paper.setScaleY(z);zoomLabel.setText((int)(z*100)+"%");}}});controls.addView(zoomBar,new LinearLayout.LayoutParams(dp(110),dp(34)));editorRoot.addView(controls);
        ScrollView vertical=new ScrollView(this);vertical.setFillViewport(true);HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setFillViewport(true);FrameLayout stage=new FrameLayout(this);stage.setBackgroundColor(0xFFE1E6EC);stage.setPadding(dp(22),dp(20),dp(22),dp(40));stage.setForegroundGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        paper=new FrameLayout(this);paper.setBackgroundColor(paperColor);paper.setElevation(dp(3));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(595),dp(842),Gravity.TOP|Gravity.CENTER_HORIZONTAL);stage.addView(paper,pp);
        editor=new EditText(this);editor.setText("الحمد لله رب العالمین\n\nاپنا اردو متن یہاں لکھیں…");editor.setTextSize(30);editor.setTextColor(textColor);editor.setGravity(Gravity.TOP|Gravity.RIGHT);editor.setTextDirection(View.TEXT_DIRECTION_RTL);editor.setPadding(dp(28),dp(32),dp(28),dp(32));editor.setBackgroundColor(Color.TRANSPARENT);editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);editor.setHint("اردو میں لکھنا شروع کریں…");editor.setHintTextColor(0xFF9AA5B1);paper.addView(editor,new FrameLayout.LayoutParams(-1,-1));applyTypeface();setupUndo();
        horizontal.addView(stage,new HorizontalScrollView.LayoutParams(-1,-1));vertical.addView(horizontal);editorRoot.addView(vertical,new LinearLayout.LayoutParams(-1,0,1));
        restoreDraft();
    }
    void addTop(LinearLayout p,String s,View.OnClickListener l){Button b=button(s);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setOnClickListener(l);p.addView(b,new LinearLayout.LayoutParams(dp(58),dp(56)));}
    void addTool(String s,View.OnClickListener l){Button b=button(s);b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(s.length()>5?88:52),dp(46));lp.setMargins(dp(2),0,dp(2),0);tools.addView(b,lp);}
    void applyTypeface(){int style=(bold?Typeface.BOLD:0)|(italic?Typeface.ITALIC:0);editor.setTypeface(Typeface.create(currentTypeface,style));}
    void applyGravity(){editor.setGravity(Gravity.TOP|(center?Gravity.CENTER_HORIZONTAL:Gravity.RIGHT));}
    void setupUndo(){undoStack.clear();redoStack.clear();undoStack.add(editor.getText().toString());editor.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){}public void afterTextChanged(Editable e){if(!changing){String v=e.toString();if(undoStack.isEmpty()||!undoStack.get(undoStack.size()-1).equals(v)){undoStack.add(v);if(undoStack.size()>50)undoStack.remove(0);redoStack.clear();}}}});}
    void undo(){if(editor==null||undoStack.size()<2)return;changing=true;String now=undoStack.remove(undoStack.size()-1);redoStack.add(now);editor.setText(undoStack.get(undoStack.size()-1));editor.setSelection(editor.length());changing=false;}
    void redo(){if(editor==null||redoStack.isEmpty())return;changing=true;String v=redoStack.remove(redoStack.size()-1);undoStack.add(v);editor.setText(v);editor.setSelection(editor.length());changing=false;}

    void chooseTextColor(){chooseColor("Text Color",new int[]{0xFF182638,0xFF073B73,0xFF8B1E3F,0xFF116B4D,0xFF6A3D9A,Color.BLACK},c->{textColor=c;editor.setTextColor(c);});}
    void choosePaperColor(){chooseColor("Page Background",new int[]{Color.WHITE,0xFFFFFDF8,0xFFF7F0E2,0xFFEFF6FF,0xFFF4EFFA,0xFFF2F5F7},c->{paperColor=c;paper.setBackgroundColor(c);});}
    interface ColorPick{void pick(int c);} void chooseColor(String title,int[] cs,ColorPick cb){String[] names={"Black","Blue","Maroon","Green","Purple","Light"};new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,w)->cb.pick(cs[w])).show();}
    void choosePage(){new AlertDialog.Builder(this).setTitle("Page Setup").setItems(new String[]{"A4 Portrait","A4 Landscape","A5 Portrait","Letter Portrait"},(d,w)->{if(w==1){pageW=842;pageH=595;}else if(w==2){pageW=420;pageH=595;}else if(w==3){pageW=612;pageH=792;}else{pageW=595;pageH=842;}if(paper!=null){ViewGroup.LayoutParams lp=paper.getLayoutParams();lp.width=dp(pageW);lp.height=dp(pageH);paper.setLayoutParams(lp);}Toast.makeText(this,"Page updated",Toast.LENGTH_SHORT).show();}).show();}
    void chooseTemplate(){String[] a={"Blank Document","Islamic Notice","Character Certificate","Simple Poster"};new AlertDialog.Builder(this).setTitle("Professional Templates").setItems(a,(d,w)->{if(editor==null)buildEditor();String t="";if(w==1)t="اعلان\n\nتمام طلبہ و طالبات کو مطلع کیا جاتا ہے کہ\n\n________________________________\n\nتاریخ: __________";if(w==2)t="کردار نامہ\n\nیہ تصدیق کی جاتی ہے کہ\n\n________________________________\n\nنے ہمارے ادارے میں اچھے اخلاق اور بہترین کردار کا مظاہرہ کیا ہے۔\n\nدستخط: __________";if(w==3)t="بسم اللہ الرحمن الرحیم\n\nعنوان یہاں لکھیں\n\nاپنا خوبصورت پیغام یہاں تحریر کریں";changing=true;editor.setText(t);changing=false;undoStack.clear();undoStack.add(t);}).show();}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,105);}
    void importFont(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,101);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;try{Uri u=d.getData();if(r==101){String original="custom.ttf";try{original=getContentResolver().getType(u)!=null?"font_"+System.currentTimeMillis()+".ttf":original;}catch(Exception ignored){}File out=new File(fontDir,"font_"+System.currentTimeMillis()+".ttf");copy(u,out);loadFonts();Toast.makeText(this,"Font imported",Toast.LENGTH_SHORT).show();if(fontSpinner!=null){ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fontNames);fontSpinner.setAdapter(a);}}else if(r==102){writeJson(u);toast("Document saved");}else if(r==103){openJson(u);}else if(r==104){createPdf(u);toast("PDF created successfully");}else if(r==105){InputStream in=getContentResolver().openInputStream(u);pageImage=BitmapFactory.decodeStream(in);if(in!=null)in.close();if(pageImage!=null&&paper!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(pageImage);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setAlpha(.35f);paper.addView(iv,0,new FrameLayout.LayoutParams(-1,dp(220),Gravity.TOP));toast("Image added to page");}}}catch(Exception e){toast("Operation failed: "+e.getMessage());}}
    void copy(Uri u,File out)throws Exception{InputStream in=getContentResolver().openInputStream(u);FileOutputStream fo=new FileOutputStream(out);byte[] b=new byte[8192];int n;while((n=in.read(b))>0)fo.write(b,0,n);in.close();fo.close();}
    void showFontsDialog(){loadFonts();new AlertDialog.Builder(this).setTitle("Available Fonts").setItems(fontNames.toArray(new String[0]),(d,w)->{}).setPositiveButton("Import Font",(d,w)->importFont()).show();}
    void saveDocument(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".json");startActivityForResult(i,102);}String safeName(String s){return s.replaceAll("[^a-zA-Z0-9_\\- ]","_").trim().replaceAll(" +","_");}
    void writeJson(Uri u)throws Exception{org.json.JSONObject o=new org.json.JSONObject();o.put("title",title.getText().toString());o.put("text",editor.getText().toString());o.put("font",currentFontName);o.put("size",editor.getTextSize());o.put("pageW",pageW);o.put("pageH",pageH);o.put("textColor",textColor);o.put("paperColor",paperColor);o.put("bold",bold);o.put("italic",italic);o.put("center",center);OutputStream out=getContentResolver().openOutputStream(u);out.write(o.toString(2).getBytes(StandardCharsets.UTF_8));out.close();}
    void openDocument(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,103);}void openJson(Uri u){try{InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[8192];int n;while((n=in.read(z))>0)b.write(z,0,n);in.close();org.json.JSONObject o=new org.json.JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));buildEditor();title.setText(o.optString("title","Untitled Urdu Document"));changing=true;editor.setText(o.optString("text",""));changing=false;editor.setTextSize((float)o.optDouble("size",30));pageW=o.optInt("pageW",595);pageH=o.optInt("pageH",842);textColor=o.optInt("textColor",textColor);paperColor=o.optInt("paperColor",paperColor);bold=o.optBoolean("bold",false);italic=o.optBoolean("italic",false);center=o.optBoolean("center",false);editor.setTextColor(textColor);paper.setBackgroundColor(paperColor);currentFontName=o.optString("font","System Urdu");loadFonts();int ix=fontNames.indexOf(currentFontName);if(ix<0)ix=0;fontSpinner.setSelection(ix);applyTypeface();applyGravity();choosePageSilent();toast("Document opened");}catch(Exception e){toast("Open failed: "+e.getMessage());}}
    void choosePageSilent(){ViewGroup.LayoutParams lp=paper.getLayoutParams();lp.width=dp(pageW);lp.height=dp(pageH);paper.setLayoutParams(lp);}
    void exportPdf(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,safeName(title.getText().toString())+".pdf");startActivityForResult(i,104);}void createPdf(Uri uri)throws Exception{OutputStream out=getContentResolver().openOutputStream(uri);writePdfToStream(out);out.close();}
    void writePdfToStream(OutputStream out)throws Exception{PdfDocument doc=new PdfDocument();PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(pageW,pageH,1).create();PdfDocument.Page p=doc.startPage(pi);Canvas c=p.getCanvas();c.drawColor(paperColor);int margin=36;if(pageImage!=null){Rect src=new Rect(0,0,pageImage.getWidth(),pageImage.getHeight());Rect dst=new Rect(margin,margin,pageW-margin,pageH/3);Paint ip=new Paint(Paint.ANTI_ALIAS_FLAG);ip.setAlpha(90);c.drawBitmap(pageImage,src,dst,ip);}TextPaint tp=new TextPaint(Paint.ANTI_ALIAS_FLAG);tp.setColor(textColor);float scale=getResources().getDisplayMetrics().scaledDensity;tp.setTextSize(Math.max(14,editor.getTextSize()/scale));tp.setTypeface(editor.getTypeface());int width=pageW-margin*2;Layout.Alignment al=center?Layout.Alignment.ALIGN_CENTER:Layout.Alignment.ALIGN_OPPOSITE;StaticLayout sl=new StaticLayout(editor.getText(),tp,width,al,1.2f,0,false);c.save();c.translate(margin,margin);sl.draw(c);c.restore();doc.finishPage(p);doc.writeTo(out);doc.close();}
    void printPdf(){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print(title.getText().toString(),new PrintDocumentAdapter(){public void onLayout(PrintAttributes o,PrintAttributes n,CancellationSignal cs,LayoutResultCallback cb,Bundle e){if(cs.isCanceled()){cb.onLayoutCancelled();return;}PrintDocumentInfo info=new PrintDocumentInfo.Builder(safeName(title.getText().toString())+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build();cb.onLayoutFinished(info,true);}public void onWrite(PageRange[] r,ParcelFileDescriptor d,CancellationSignal cs,WriteResultCallback cb){try{writePdfToStream(new FileOutputStream(d.getFileDescriptor()));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.getMessage());}}},null);}
    void restoreDraft(){try{SharedPreferences p=getSharedPreferences("draft",0);String s=p.getString("text",null);if(s!=null){title.setText(p.getString("title",title.getText().toString()));changing=true;editor.setText(s);changing=false;undoStack.clear();undoStack.add(s);}}catch(Exception ignored){}}
    void saveDraft(){if(editor!=null)getSharedPreferences("draft",0).edit().putString("title",title.getText().toString()).putString("text",editor.getText().toString()).apply();}
    void confirmHome(){saveDraft();new AlertDialog.Builder(this).setMessage("Return to home? Your current draft is auto-saved.").setNegativeButton("Cancel",null).setPositiveButton("Home",(d,w)->buildHome()).show();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(editor!=null)confirmHome();else super.onBackPressed();}
    @Override protected void onPause(){saveDraft();super.onPause();}
}

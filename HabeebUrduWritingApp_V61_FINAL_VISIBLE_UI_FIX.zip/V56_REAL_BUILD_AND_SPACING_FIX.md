V56 REAL BUILD + URDU SPACING FIX

Fixed compilation blocker in MainActivity.java:
- Removed invalid Layout.Alignment.ALIGN_LEFT
- Removed invalid Layout.Alignment.ALIGN_RIGHT
- Replaced with Android-valid ALIGN_NORMAL / ALIGN_OPPOSITE / ALIGN_CENTER mapping.

Fixed Urdu line-overlap root cause:
- Removed unsafe global compression multiplier 0.82f.
- Removed negative global line spacing -3dp.
- New safe baseline is 1.30f with 0 extra spacing.
- Paragraph line-height span now never shrinks below natural font metrics.
- This applies consistently to editor layout, pagination measurement, PDF preview and exported PDF.

Version bumped to 56.

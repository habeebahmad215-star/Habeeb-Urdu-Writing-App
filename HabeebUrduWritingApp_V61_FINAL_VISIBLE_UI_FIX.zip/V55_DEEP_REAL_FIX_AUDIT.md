# V55 Deep Real Fix Audit

This revision changes source code rather than only adding notes.

## Fixed in the editor core
- Native Android paste now reports the inserted range back to the document engine.
- Pasted text is normalized to plain document formatting and cannot inherit an old font-size, font, word-spacing or line-height span at the cursor.
- Existing formatting outside the pasted range is preserved where supported.
- Manual Select All -> Line Space removes all intersecting paragraph line-height spans before applying one deterministic setting.
- The line-height span now supports both compact (<1.0) and expanded (>1.0) values instead of silently refusing to compact.
- Any line-spacing change schedules pagination again.
- Pagination measurement now uses the editor's actual horizontal alignment and RTL/LTR text direction.
- A very large paste continues the overflow chain page-by-page after each continuation page is measured, instead of stopping after the first split.
- Safe-area/page-size changes also trigger a new pagination check.
- The build version was advanced to 5.5 / versionCode 55.

## Architecture checked
- Primary page text state and per-page font persistence
- Rich span serialization and slicing during overflow
- Full-page safe-area restore
- Native paste and custom Paste button paths
- Selected-text font, size, word spacing and line spacing
- Overflow continuation
- PDF/print rendering path

A physical Android build should still be run in the target build environment before release, because this archive does not contain a Gradle wrapper or Android SDK and therefore cannot be compiled inside this inspection environment.

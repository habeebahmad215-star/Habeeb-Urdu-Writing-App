# V61 FINAL VISIBLE UI FIX

This release explicitly replaces the visible editor header with:

Menu | Layers | Align | Move | Undo | Redo | Save

Pages remains available through Menu instead of occupying a top-toolbar slot.

All top tools have a clear symbol and label, equal visual sizing, and Save remains highlighted.

Bottom page tools were resized and kept readable. Audio, Video and AI Image options are not included.

Important: versionCode is 61 so the imported project is visibly distinguishable from V60.

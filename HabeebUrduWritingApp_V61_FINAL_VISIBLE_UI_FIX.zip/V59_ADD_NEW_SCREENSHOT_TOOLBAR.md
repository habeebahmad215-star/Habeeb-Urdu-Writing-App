V59 — Screenshot-matched ADD NEW toolbar update

Implemented:
- ADD NEW opens the large bottom-sheet tool panel instead of immediately creating a page.
- Three-column tool cards with clear icon/sign + label and consistent screenshot-like sizing.
- Included: Gallery Pic, Stock Images, My Folder, Add Text, Tools, Borders, Table, Draw, Pen Tool, Logos, Special Text, Shapes.
- Explicitly excluded: Audio, Video, AI Images.
- Bottom quick controls: Add New Page, Resize Paper, Transparent BG, BG Color.
- Existing page tools and editor controls retained.

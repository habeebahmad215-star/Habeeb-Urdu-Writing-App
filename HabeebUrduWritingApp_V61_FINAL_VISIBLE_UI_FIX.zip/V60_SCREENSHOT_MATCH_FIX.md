# V60 Screenshot Match Fix

- Header order corrected to Menu, Layers, Align, Move, Undo, Redo, Save.
- Align and Move are functional actions, not decorative labels.
- ADD NEW panel top heading removed to match supplied reference; close button retained.
- Existing ADD NEW grid keeps Audio, Video and AI Images excluded.
- Existing text-selection toolbar remains in the screenshot order.
- Existing page toolbar remains ADD NEW + Resize Paper + Transparent BG + BG Color + Page Colors.
